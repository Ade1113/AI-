"""Validate complete outputs and record provenance without altering results."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import sys
import numpy as np
import scipy
import torch
import matplotlib

ROOT = Path(__file__).resolve().parent
R = ROOT / "results"
EXPECTED = {
    "small": 972, "large": 432,
    "small_batch_loss": 972, "large_batch_loss": 432,
    "small_delta_episode": 810, "small_delta_batch": 810,
    "large_time_episode": 432,
}


def main():
    counts = {}
    records = 0
    for stage, total in EXPECTED.items():
        files = sorted((R / stage).glob("[0-9][0-9][0-9][0-9]/complete.json"))
        assert len(files) == total, (stage, len(files), total)
        indices = []
        for p in files:
            meta = json.loads(p.read_text())
            indices.append(meta["index"])
            assert meta["ntrain"] == 500 and meta["ntest"] == 100 and meta["epochs"] == 300
            evaluation = dict(np.load(p.parent / "evaluation.npz"))
            expected_keys = {"LIR", "WNH", "GDSH", "DRL"} if stage in ["small", "large"] else {"DRL"}
            assert set(evaluation) == expected_keys
            for key, costs in evaluation.items():
                assert costs.shape == (100,) and np.isfinite(costs).all() and (costs >= 0).all()
                recorded = meta["costs"][key] if "costs" in meta else meta["cost"]
                assert np.isclose(costs.mean(), recorded, rtol=1e-7)
                if key in ["GDSH", "DRL"]:
                    assert (p.parent / (key + ".pt")).is_file()
                records += len(costs)
        assert indices == list(range(total)), stage
        counts[stage] = total
    for i in range(972):
        d = R / "small" / f"{i:04d}"
        meta = json.loads((d / "dp_step1_cap2.json").read_text())
        costs = np.load(d / "dp_step1_cap2.npz")["cost"]
        assert meta["value"] > 0 and costs.shape == (100,) and np.isfinite(costs).all()
        assert (d / "test_paths.npz").is_file()
    nested_max_diff = 0.
    for variant, source in [("small_delta_episode", "small"), ("small_delta_batch", "small_batch_loss")]:
        for p in (R / variant).glob("*/complete.json"):
            m = json.loads(p.read_text())
            if m["config"]["delta"] != .25:
                continue
            old = np.load(R / source / f"{m['source_index']:04d}" / "evaluation.npz")["DRL"]
            new = np.load(p.parent / "evaluation.npz")["DRL"]
            assert np.allclose(old, new, rtol=2e-6, atol=1e-4)
            nested_max_diff = max(nested_max_diff, float(np.max(np.abs(old-new))))
    for stage in ["small", "large"]:
        for p in (R / stage).glob("*/test_paths.npz"):
            with np.load(p) as z:
                assert len(z["demand"]) == 100 and z["demand"].shape == z["yield"].shape
                assert np.isin(z["yield"], [0, 1]).all()
    ni = dict(np.load(R / "noniid/evaluation.npz"))
    assert all(v.shape == (5000,) and np.isfinite(v).all() for v in ni.values())
    versions = {m.__name__: m.__version__ for m in [np, scipy, torch, matplotlib]}
    source_hashes = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.glob("*.py"))
    }
    manifest = {
        "status": "PASS",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "main_libraries": versions,
        "dp_execution_runtime": json.loads((R / "dp_runtime.json").read_text())
        if (R / "dp_runtime.json").exists() else None,
        "device": "CPU", "torch_threads_per_worker": 1,
        "completed_cases": counts,
        "evaluated_policy_trajectory_costs_excluding_dp_noniid": records,
        "noniid_test_size": 5000,
        "nested_delta_025_max_absolute_cost_difference": nested_max_diff,
        "verification": json.loads((R / "verification.json").read_text()),
        "dp_verification": json.loads((R / "verification_dp.json").read_text()),
        "dependency_compatibility": json.loads((R / "dependency_compatibility.json").read_text())
        if (R / "dependency_compatibility.json").exists() else None,
        "saved_model_replay": json.loads((R / "model_replay.json").read_text()),
        "delivery_source_sha256": source_hashes,
        "scope": "Independent implementation; full core grids, specified sensitivity experiments, numerical DP.",
        "interpretation": "Execution completed; published near-optimality numbers were not reproduced.",
    }
    (R / "execution_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(json.dumps({"status": "PASS", "counts": counts, "cost_records": records}, indent=2))


if __name__ == "__main__":
    main()
