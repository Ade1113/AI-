# T2 随机产出库存问题 Python 独立复现

论文：Yuting Yan, Frank (Youhua) Chen, Zhe Fu, Wenjie Bi,
**Heuristics and deep reinforcement learning for the inventory problem with an all-or-nothing yield pattern and non-zero leadtimes**,
*Computers & Operations Research* 186 (2026), 107305。
[DOI](https://doi.org/10.1016/j.cor.2025.107305)

这是依据论文正文和附录编写的独立实现，未取得作者源代码或原始随机种子。
代码执行真实的库存模拟、可微轨迹训练和数值动态规划。
**完成了全参数主实验，但没有复现原文小规模 DRL 的近最优数量结果。**
请同时阅读生成报告中的实现假设和对照实验，不将“程序运行完成”理解为“论文数值已全部验证”。

## 运行

建议 Python 3.11，CPU，至少 8 GB 内存；加密 DP 建议 16 GB 及以上。
无需 CUDA。以下命令在项目目录运行：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt

# 先执行有手算和独立模拟器参照的验证，以及独立目录中的小型运行。
python run_all.py --mode smoke

# 全参数复现，保留断点。训练和 DP 均为实际计算，耗时明显长于 smoke。
python run_all.py --mode full --workers 4 --dp-workers 1

# 结果齐全后，只重建汇总、图表和 Word。
python run_all.py --mode report
```

Windows 激活环境请使用 `.venv\Scripts\activate`。
可以给 `run_all.py` 传入 `--dp-python` 和 `--docx-python`，分别指定另一个
含 NumPy/SciPy/Numba 或 python-docx 的解释器。程序不依赖作者机器或本次执行机器的绝对路径。
Word 文本首选 Noto Sans CJK SC，拉丁字符首选 Times New Roman；缺少字体时可替换
`docx_layout.py` 和 `make_figures.py` 中的字体名称。

`requirements.txt` 固定了本次主模拟的主要库版本。DP 原始运行使用另一套
Numba 0.67.0 / NumPy 2.5.1 / SciPy 1.18.0 环境；已另外使用文件中指定的
Numba 0.61.2 / NumPy 1.26.4 / SciPy 1.14.1 验证 DP，并重新计算 12 个代表性案例，
其期望成本与原运行相同。它不是跨平台逐位一致的锁文件；
请运行 `tests/verify_dp.py` 检查本机组合。

## 实验范围

| 实验 | 参数组合 | 每组训练 / 测试 | 轮数 |
|---|---:|---:|---:|
| 小规模主实验 | 972 | 500 / 100 | 300 |
| 大规模主实验 | 432 | 500 / 100 | 300 |
| 小规模数值 DP | 972 | 同一 100 条测试路径 | 有限期递推 |
| 批量损失对照 | 972 + 432 | 与主实验相同 | 300 |
| δ 对照 | 5 × 162 × 2 种目标 | 与对应主实验相同 | 300 |
| 增加时间输入 | 432 | 与主实验相同 | 300 |
| 非平稳需求 | 1 个设定，3 个学习模型 | 500 / 100，另查 5,000 条 | 300 |
| GDSH 优化器检查 | 12 个预先分层案例 | 500 / 5,000 | L-BFGS-B 最多 500 次 |

主实验的全参数网格在 `experiments.py`。没有缩减 972 或 432 的参数组合。
默认训练模型使用第 300 轮后的参数，不按测试成本选择最好轮次或种子。
小规模 DP 主步长为 1；12 个事先按 L、p、σ 分层选择的案例加密到 0.5，
并将订单上限系数从 2 增加至 3。精细策略表计算后释放，保存期望值和同样本测试成本。

## 关键定义与明确的实现约定

- 期初收货并支付成功批次的采购成本，然后订货、满足需求、计算期末持有和积压成本。
  第 t 期订单在 t+L 期到达，最后 L 期不下新订单。
- LIR 的膨胀系数为 1。WNH 枚举全部 `2**(L-1)` 个在途产出路径。
- DRL 按正文使用 `[S, I, pipeline]` 共 L+1 个输入；附录 A 写 L，二者存在差异。
  本次除以 S 缩放输入，末层置零，初始策略等于 WNH。这些初始化细节原文没有完整说明。
- 网络隐藏层 8–16–16，ReLU；每条产出路径分别输出两个 logits 并作行 Softmax；
  权重位于 WNH 权重 ±δ 的区间内。它不是跨路径 Softmax。
  保留可能为负的权重区间，只把最终订单截为非负。
- 主损失是每条轨迹先取指数再平均：
  `mean(exp(100*(C-C_WNH)/C_WNH))`。
  对照损失是 `exp(100*(mean(C)-mean(C_WNH))/mean(C_WNH))`。
  两者是不同的目标，结果分别保留。
- GDSH 使用状态无关的非负权重，不限制权重和；以平均成本训练。
  原文没有给出完整优化器细节，本次使用与 DRL 相同的 Adam 学习率及 300 轮。
- 500 条训练轨迹固定使用，100 条测试轨迹单独生成，各策略共享测试随机数。
  同时批处理的模型具有各自独立参数；并行只是提高计算效率。
- 非平稳扩展每个决策期使用独立网络，将当期均值及方差代入式 3 作为 S(t) 的约定；
  原文未给出唯一的非平稳安全库存公式。
- 数值 DP 是有限网格上的近似基准，不是连续状态全局最优的认证。
  原文 DP 的状态和动作网格没有提供；本项目明确记录自己的边界和网格。
- 附录 D.1 批量订货以及无约束网络的运行时间小样本比较没有执行。

## 单独运行

```bash
python run_experiments.py --stage small --workers 4
python run_experiments.py --stage large --workers 4
python prepare_test_paths.py --stage small
python prepare_test_paths.py --stage large
python dynamic_programming.py --workers 1
python dynamic_programming.py --step .5 --workers 1 --indices 80,81,242,243,404,405,566,567,728,729,890,891
python dynamic_programming.py --cap-multiplier 3 --workers 1 --indices 80,81,242,243,404,405,566,567,728,729,890,891

python run_variants.py --stage small --variant batch_loss --workers 4
python run_variants.py --stage large --variant batch_loss --workers 4
python run_variants.py --stage small --variant delta_episode --workers 4
python run_variants.py --stage small --variant delta_batch --workers 4
python run_variants.py --stage large --variant time_episode --workers 4
python run_extensions.py
python audit_optimizer.py
python verify_saved_models.py
python audit_results.py
python summarize.py
python make_figures.py
python build_report.py
```

不要在正式 `results/` 里先运行 `--limit` 后直接扩大规模；程序检查设计文件一致性，
以防把不同轮数、样本数或网格的结果混合。快速调试请使用
`run_experiments.py --output results_debug ...`。已完成的同一设计可安全恢复。

## 输出与溯源

- `results/小组/编号/complete.json`：参数、种子、训练和测试规模、实际成本。
- `evaluation.npz`：每条测试轨迹的策略成本，而非仅汇总均值。
- `DRL.pt` / `GDSH.pt`：最终模型；`*_training.npy`：每轮更新前的平均成本及损失。
- `test_paths.npz`：主实验的精确测试需求和产出路径。
- `dp_step*.json/.npz`：数值 DP 元数据、期望值和同样本策略成本。
- `case_summary.csv`、`table3_comparison.csv`、`dp_refinement.csv`：可核查的明细表。
- `figures/`：300 dpi PNG 和 SVG；`report/`：中文 DOCX。
- `paper_reference.py`：明示为原文的参照数值，只用于比较，从不参与训练或筛选种子。

小规模种子为 `10000000 + index*10`，大规模为 `20000000 + index*10`。
训练、测试及网络种子分别偏移 0、1、2，每条轨迹由 SeedSequence 独立派生。
δ 对照使用对应主案例种子，非平稳扩展使用 40000000 起始的独立种子。

汇总采用固定参数设计的平均成本之比。95% 区间条件于本次训练模型和固定参数网格，
大规模相对差采用配对测试轨迹的 delta 方法；不声称覆盖全部训练随机性。
所有图均从保存的结果生成，不依靠拟合论文截图或填写预设曲线。

## 纯代码包

`python package_code.py` 生成 `dist/T2_code_only.zip`，使用白名单并检查 ZIP 内容与大小。
包中只有 Python 源码、测试、依赖、README 和 `.gitignore`。
不包含论文、数据、运行结果、图片、模型权重、Word 或虚拟环境。
未添加第三方源代码或未经确认的第三方许可文件；引用论文时请保留上面的 DOI。
