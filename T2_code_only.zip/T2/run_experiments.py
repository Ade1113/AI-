"""Run independent models; completed individual cases are safe to resume."""
import argparse,json,os,time
from pathlib import Path
from dataclasses import asdict
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import torch
from inventory import Config,BatchPolicy,numpy_rollout,sample,train,rollout
from experiments import design,seeds

ROOT=Path(__file__).resolve().parent


def worker_init():
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)


def worker(payload):
    stage,items,out,ntrain,ntest,epochs,normalize,time_input=payload
    out=Path(out)
    configs=[Config(**r["config"]) for r in items]
    data=[sample(c,ntrain,r["seeds"]["training"]) for c,r in zip(configs,items)]
    d=np.stack([x[0] for x in data]);y=np.stack([x[1] for x in data])
    tdty=[sample(c,ntest,r["seeds"]["test"]) for c,r in zip(configs,items)]
    td=np.stack([x[0] for x in tdty]);ty=np.stack([x[1] for x in tdty])
    test_d=torch.tensor(td);test_y=torch.tensor(ty)
    records=[{"config":asdict(c),"index":r["index"],"seeds":r["seeds"],
              "stage":stage,"ntrain":ntrain,"ntest":ntest,"epochs":epochs,
              "normalize":normalize,"time_input":time_input}
             for c,r in zip(configs,items)]
    costs={}
    for mode in ["LIR","WNH"]:
        costs[mode]=np.stack([numpy_rollout(c,dd,yy,mode) for c,(dd,yy) in zip(configs,tdty)])
    start=time.monotonic()
    for mode in ["GDSH","DRL"]:
        model,hist,teacher=train(configs,d,y,[r["seeds"]["network"] for r in items],
                                 mode=mode,epochs=epochs,normalize=normalize,time_input=time_input)
        with torch.no_grad(): costs[mode]=rollout(model,test_d,test_y).cpu().numpy()
        for i,r in enumerate(records):
            path=out/f'{r["index"]:04d}';path.mkdir(parents=True,exist_ok=True)
            state={key:(val if key=="bits" else val[i:i+1]).detach().cpu() for key,val in model.state_dict().items()}
            torch.save({"config":r["config"],"state":state,"mode":mode,
                        "normalize":normalize,"time_input":time_input},path/f"{mode}.pt")
            np.save(path/f"{mode}_training.npy",hist[:,i,:])
        del model
    elapsed=time.monotonic()-start
    for i,r in enumerate(records):
        path=out/f'{r["index"]:04d}'
        np.savez_compressed(path/"evaluation.npz",**{key:value[i] for key,value in costs.items()})
        r["costs"]={key:float(v[i].mean()) for key,v in costs.items()}
        r["se"]={key:float(v[i].std(ddof=1)/np.sqrt(ntest)) for key,v in costs.items()}
        r["gap_pct"]={key:float(100*(v[i].mean()/costs["LIR"][i].mean()-1)) for key,v in costs.items()}
        r["group_training_seconds"]=elapsed
        tmp=path/"complete.tmp";tmp.write_text(json.dumps(r,indent=2));tmp.replace(path/"complete.json")
    return {"stage":stage,"indices":[r["index"] for r in records],
            "seconds":round(elapsed,2),"DRL_gap_mean":float(np.mean([r["gap_pct"]["DRL"] for r in records]))}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--stage",choices=["small","large","delta"],default="large")
    p.add_argument("--workers",type=int,default=6)
    p.add_argument("--case-batch",type=int,default=4)
    p.add_argument("--train-trajectories",type=int,default=500)
    p.add_argument("--test-trajectories",type=int,default=100)
    p.add_argument("--epochs",type=int,default=300)
    p.add_argument("--limit",type=int)
    p.add_argument("--raw-inputs",action="store_true")
    p.add_argument("--time-input",action="store_true")
    p.add_argument("--output",type=Path,default=ROOT/"results")
    a=p.parse_args()
    cs=design(a.stage)
    if a.limit is not None:cs=cs[:a.limit]
    out=a.output/a.stage;out.mkdir(parents=True,exist_ok=True)
    metadata={"stage":a.stage,"n_cases":len(cs),"ntrain":a.train_trajectories,
              "ntest":a.test_trajectories,"epochs":a.epochs,
              "normalize":not a.raw_inputs,"time_input":a.time_input,
              "design":[asdict(c) for c in cs]}
    mf=out/"design.json"
    if mf.exists() and json.loads(mf.read_text())!=metadata:
        raise ValueError("Existing results use different settings. Choose another --output.")
    mf.write_text(json.dumps(metadata,indent=2))
    groups=defaultdict(list)
    for i,c in enumerate(cs):
        if not (out/f"{i:04d}"/"complete.json").exists():
            groups[c.L,c.T].append({"index":i,"config":asdict(c),"seeds":seeds(a.stage,i)})
    jobs=[]
    for rows in groups.values():
        for i in range(0,len(rows),a.case_batch):
            jobs.append((a.stage,rows[i:i+a.case_batch],str(out),a.train_trajectories,
                         a.test_trajectories,a.epochs,not a.raw_inputs,a.time_input))
    print(json.dumps({"pending_jobs":len(jobs),"cases":len(cs),"workers":a.workers}),flush=True)
    with ProcessPoolExecutor(max_workers=a.workers,initializer=worker_init) as pool:
        futures=[pool.submit(worker,j) for j in jobs]
        for f in as_completed(futures):print(json.dumps(f.result()),flush=True)
    print("COMPLETE",a.stage,flush=True)


if __name__=="__main__":main()
