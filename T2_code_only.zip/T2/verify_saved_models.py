"""Replay selected complete primary experiments using the saved model files."""
from pathlib import Path
import json
import numpy as np
import torch
from inventory import Config, BatchPolicy, rollout

ROOT = Path(__file__).resolve().parent


def main():
    torch.set_num_threads(1)
    checks = []
    for stage, indices in [
        ("small", [0, 80, 485, 486, 891, 971]),
        ("large", [0, 26, 80, 107, 216, 242, 404, 431]),
    ]:
        for i in indices:
            folder = ROOT / "results" / stage / f"{i:04d}"
            with np.load(folder / "test_paths.npz") as paths:
                demand = torch.tensor(paths["demand"][None])
                yields = torch.tensor(paths["yield"][None])
            observed = dict(np.load(folder / "evaluation.npz"))
            for method in ["DRL", "GDSH"]:
                data = torch.load(folder / (method + ".pt"), weights_only=True)
                model = BatchPolicy([Config(**data["config"])], method,
                                    normalize=data["normalize"], time_input=data["time_input"])
                model.load_state_dict(data["state"])
                with torch.no_grad():
                    costs = rollout(model, demand, yields).numpy()[0]
                diff = float(np.max(np.abs(costs-observed[method])))
                assert np.allclose(costs, observed[method], rtol=2e-6, atol=1e-4), (stage, i, method, diff)
                checks.append({"stage": stage, "index": i, "method": method, "max_abs_difference": diff})
    result = {"status": "PASS", "checks": checks}
    (ROOT / "results/model_replay.json").write_text(json.dumps(result, indent=2))
    print("PASS:", len(checks), "saved-model replays; max absolute difference",
          max(r["max_abs_difference"] for r in checks))


if __name__ == "__main__":
    main()
