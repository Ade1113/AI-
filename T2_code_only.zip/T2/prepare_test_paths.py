"""Export the exact held-out paths for independent DP evaluation."""
import argparse,json
from pathlib import Path
import numpy as np
from inventory import Config,sample
from experiments import seeds

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--stage",choices=["small","large","delta"],default="small")
    a=p.parse_args()
    root=Path(__file__).resolve().parent/"results"/a.stage
    meta=json.loads((root/"design.json").read_text())
    for i,c in enumerate(meta["design"]):
        dest=root/f"{i:04d}";dest.mkdir(exist_ok=True)
        path=dest/"test_paths.npz"
        if path.exists():continue
        d,y=sample(Config(**c),meta["ntest"],seeds(a.stage,i)["test"])
        np.savez_compressed(path,demand=d,**{"yield":y})
    print("Exported exact held-out paths",a.stage,len(meta["design"]))
