"""Inventory dynamics and differentiable policy search for Yan et al. (2026).

No data or implementation from the authors is bundled. Pipeline entries are
stored oldest first. Receipts are tested and paid for on arrival; costs use
end-of-period inventory. A period-t order arrives at the start of t+L.
"""
from dataclasses import dataclass, asdict
from itertools import product
from math import sqrt
import numpy as np
from scipy.special import ndtri
import torch
from torch import nn


@dataclass(frozen=True)
class Config:
    L: int = 2
    T: int = 50
    p: float = .7
    co: float = 2.
    h: float = 1.
    b: float = 9.
    mu: float = 10.
    sd: float = 2.
    distribution: str = "normal"
    scale: float = 1.6
    alpha: float = .99
    delta: float | None = None
    noniid: bool = False

    @property
    def variance(self):
        return self.mu*self.scale if self.distribution == "gamma" else self.sd**2

    @property
    def radius(self):
        return self.delta if self.delta is not None else (.0884 if self.L == 5 else .25)

    def target(self, t=0):
        """Equation (3), using the specified distribution moments."""
        mu = self.mu
        var = self.variance
        if self.noniid:
            mu += (-5., -1., 0., 1., 5.)[t % 5]
            var += 1.
        if not .5 < self.p <= 1:
            raise ValueError("Equation (3) requires p > 0.5 in this implementation")
        variance = (self.L+1)*var + max(self.L,1)*(1-self.p)/(2*self.p-1)*(mu*mu+var)
        return (self.L+1)*mu + ndtri(self.b/(self.b+self.h))*sqrt(variance)


def outcomes(L):
    return np.asarray(list(product([0., 1.], repeat=L-1)), dtype=np.float64)


def teacher_weights(c):
    y = outcomes(c.L)
    k = y.sum(axis=1)
    return c.p**k * (1-c.p)**(c.L-1-k)


def sample(c, n, seed):
    """Distinct deterministic child seed for every independent trajectory."""
    d = np.empty((n, c.T), dtype=np.float32)
    y = np.empty_like(d)
    for i, ss in enumerate(np.random.SeedSequence(seed).spawn(n)):
        rng = np.random.default_rng(ss)
        if c.distribution == "gamma":
            a = rng.gamma(c.mu/c.scale, c.scale, c.T)
        else:
            a = rng.normal(c.mu, c.sd, c.T)
        if c.noniid:
            a += rng.normal(np.resize([-5., -1., 0., 1., 5.], c.T), 1., c.T)
        d[i] = np.maximum(a, 0)
        y[i] = rng.binomial(1, c.p, c.T)
    return d, y


def numpy_rollout(c, demand, yields, method="WNH", weights=None, return_paths=False):
    """Independent NumPy simulator for heuristics and correctness checks."""
    n = len(demand)
    inv = np.zeros(n)
    queue = np.zeros((n, c.L))
    costs = np.zeros(n)
    B = outcomes(c.L)
    w = teacher_weights(c) if weights is None else np.asarray(weights)
    log = {k: [] for k in ["inventory", "order", "receipt", "cost", "ending"]}
    for t in range(c.T):
        receipt = yields[:, t]*queue[:, 0]
        inv = inv + receipt
        if t < c.T-c.L:
            if method == "LIR":
                q = np.maximum(c.target(t)-inv-c.p*queue[:, 1:].sum(axis=1), 0)
            else:
                features = np.maximum(c.target(t)-inv[:, None]-queue[:, 1:]@B.T, 0)
                q = np.maximum(features@w, 0)
        else:
            q = np.zeros(n)
        ending = inv-demand[:, t]
        cost = c.co*receipt+c.h*np.maximum(ending, 0)+c.b*np.maximum(-ending, 0)
        costs += c.alpha**t*cost
        if return_paths:
            for key, value in zip(log, [inv, q, receipt, cost, ending]):
                log[key].append(value.copy())
        inv = ending
        queue = np.column_stack([queue[:, 1:], q])
    if return_paths:
        return costs, {k: np.stack(v, axis=1) for k, v in log.items()}
    return costs


class BatchPolicy(nn.Module):
    """Independent parameter sets batched for efficiency; no cross-case learning."""
    def __init__(self, configs, mode="DRL", seeds=None, normalize=True,
                 time_input=False, dtype=torch.float32, device="cpu"):
        super().__init__()
        self.configs = list(configs)
        self.mode = mode
        self.normalize = normalize
        self.time_input = time_input
        self.L, self.T = configs[0].L, configs[0].T
        assert all(c.L == self.L and c.T == self.T for c in configs)
        self.register_buffer("bits", torch.tensor(outcomes(self.L), dtype=dtype, device=device))
        self.register_buffer("teacher", torch.tensor(np.stack([teacher_weights(c) for c in configs]), dtype=dtype, device=device))
        self.register_buffer("radius", torch.tensor([c.radius for c in configs], dtype=dtype, device=device)[:, None, None])
        k = 2**(self.L-1)
        if mode == "GDSH":
            self.weights = nn.Parameter(self.teacher.clone())
        elif mode == "DRL":
            if seeds is None: seeds = list(range(len(configs)))
            dims = [self.L+1+int(time_input), 8, 16, 16, 2*k]
            self.ws = nn.ParameterList()
            self.bs = nn.ParameterList()
            generators = [torch.Generator().manual_seed(int(s)) for s in seeds]
            for layer, (di, do) in enumerate(zip(dims[:-1], dims[1:])):
                # Teacher-centred initialization: output logits are exactly zero.
                # This initialization and input scaling were unspecified in the paper.
                ws, bs = [], []
                for gen in generators:
                    if layer == len(dims)-2:
                        ws.append(torch.zeros(di, do, dtype=dtype))
                        bs.append(torch.zeros(1, do, dtype=dtype))
                    else:
                        ws.append(torch.empty(di, do, dtype=dtype).uniform_(-1/sqrt(di), 1/sqrt(di), generator=gen))
                        bs.append(torch.empty(1, do, dtype=dtype).uniform_(-1/sqrt(di), 1/sqrt(di), generator=gen))
                self.ws.append(nn.Parameter(torch.stack(ws).to(device)))
                self.bs.append(nn.Parameter(torch.stack(bs).to(device)))

    def forward(self, inventory, pipeline, target, t):
        if self.mode == "LIR":
            prob = inventory.new_tensor([c.p for c in self.configs])[:, None]
            return torch.relu(target-inventory-prob*pipeline.sum(dim=-1))
        ideal = torch.relu(target[..., None]-inventory[..., None]-pipeline@self.bits.T)
        if self.mode == "WNH":
            w = self.teacher[:, None, :]
        elif self.mode == "GDSH":
            w = self.weights[:, None, :]
        else:
            x = torch.cat([target[..., None], inventory[..., None], pipeline], dim=-1)
            if self.normalize:
                x = x/target[..., None]
            if self.time_input:
                x = torch.cat([x, torch.full_like(x[..., :1], t/max(self.T-1, 1))], dim=-1)
            for i, (w, b) in enumerate(zip(self.ws, self.bs)):
                x = torch.bmm(x, w)+b
                if i < len(self.ws)-1:
                    x = torch.relu(x)
            logits = x.reshape(*x.shape[:-1], -1, 2)
            # Two-class row-wise softmax, exactly as Eqs. (9)-(10).
            prob = torch.softmax(logits, dim=-1)
            w = self.teacher[:, None, :] + self.radius*(prob[..., 1]-prob[..., 0])
        # The stated weight boxes may contain negative weights. Enforce q >= 0
        # at the action level, without silently changing the specified boxes.
        return torch.relu((ideal*w).sum(dim=-1))


class SeparateTimePolicy(nn.Module):
    """Appendix D.2: separate neural-network parameters for each decision time."""
    def __init__(self,configs,seeds,normalize=True,device="cpu"):
        super().__init__()
        self.configs=list(configs)
        self.L,self.T=configs[0].L,configs[0].T
        self.nets=nn.ModuleList([
            BatchPolicy(configs,"DRL",[int(s)+100_000*t for s in seeds],
                        normalize=normalize,device=device)
            for t in range(self.T-self.L)])

    def forward(self,inventory,pipeline,target,t):
        return self.nets[t](inventory,pipeline,target,t)


def rollout(policy, demand, yields, return_paths=False):
    """Backpropagation through the complete sampled inventory trajectory."""
    configs = policy.configs
    B, n, T = demand.shape
    inv = demand.new_zeros(B, n)
    queue = demand.new_zeros(B, n, policy.L)
    total = demand.new_zeros(B, n)
    co = demand.new_tensor([c.co for c in configs])[:, None]
    h = demand.new_tensor([c.h for c in configs])[:, None]
    b = demand.new_tensor([c.b for c in configs])[:, None]
    alpha = demand.new_tensor([c.alpha for c in configs])[:, None]
    log = {k: [] for k in ["inventory", "order", "receipt", "cost", "ending"]}
    for t in range(T):
        receipt = yields[:, :, t]*queue[:, :, 0]
        inv = inv+receipt
        target = demand.new_tensor([c.target(t) for c in configs])[:, None].expand(B, n)
        q = policy(inv, queue[:, :, 1:], target, t) if t < T-policy.L else torch.zeros_like(inv)
        ending = inv-demand[:, :, t]
        cost = co*receipt+h*torch.relu(ending)+b*torch.relu(-ending)
        total = total+alpha**t*cost
        if return_paths:
            for key, val in zip(log, [inv, q, receipt, cost, ending]):
                log[key].append(val.detach().cpu().numpy())
        inv = ending
        queue = torch.cat([queue[:, :, 1:], q[..., None]], dim=-1)
    if return_paths:
        return total, {k: np.stack(v, axis=-1) for k, v in log.items()}
    return total


def train(configs, demand, yields, seeds, mode="DRL", epochs=300,
          normalize=True, time_input=False, device="cpu", callback=None,
          loss_aggregation="episode",separate_time=False):
    model = (SeparateTimePolicy(configs,seeds,normalize,device)
             if separate_time and mode=="DRL"
             else BatchPolicy(configs, mode, seeds, normalize, time_input, device=device))
    d = torch.tensor(demand, device=device)
    y = torch.tensor(yields, device=device)
    with torch.no_grad():
        teacher = rollout(BatchPolicy(configs, "WNH", device=device), d, y)
    opt = torch.optim.Adam(model.parameters(), lr=.003)
    history = []
    for epoch in range(epochs):
        opt.zero_grad(set_to_none=True)
        cost = rollout(model, d, y)
        if mode == "DRL":
            if loss_aggregation == "episode":
                # Literal mean of the paper's per-episode exponential loss.
                loss_by_case = torch.exp(100*(cost-teacher)/teacher).mean(dim=1)
            elif loss_aggregation == "batch":
                # Separate sensitivity experiment, not silently substituted.
                loss_by_case = torch.exp(100*(cost.mean(dim=1)-teacher.mean(dim=1))/teacher.mean(dim=1))
            else:
                raise ValueError(loss_aggregation)
        else:
            loss_by_case = cost.mean(dim=1)
        if not torch.isfinite(loss_by_case).all():
            raise FloatingPointError(f"Non-finite {mode} objective at epoch {epoch}")
        # Sum over independent problems. Mean over cases would alter Adam's
        # epsilon effect when changing the execution batch size.
        loss_by_case.sum().backward()
        opt.step()
        if mode == "GDSH":
            with torch.no_grad():
                model.weights.clamp_(min=0)
        for group in opt.param_groups:
            group["lr"] = max(.0001, .003*.98**(epoch+1))
        history.append(np.stack([cost.detach().mean(dim=1).cpu().numpy(),
                                 loss_by_case.detach().cpu().numpy()], axis=-1))
        if callback and (epoch+1) % 25 == 0:
            callback(epoch+1, history[-1])
    return model, np.stack(history), teacher.detach().cpu().numpy()
