"""Create a GitHub-ready source archive with a strict 20 MB size limit."""
from pathlib import Path
import zipfile
import hashlib
import json

ROOT = Path(__file__).resolve().parent
CODE = [
    "inventory.py", "experiments.py", "run_experiments.py", "run_variants.py",
    "run_extensions.py", "dynamic_programming.py", "prepare_test_paths.py",
    "paper_reference.py", "summarize.py", "make_figures.py", "docx_layout.py",
    "build_report.py", "run_all.py", "package_code.py", "audit_results.py", "audit_optimizer.py",
    "verify_saved_models.py",
    "tests/verify.py", "tests/verify_dp.py", "requirements.txt", "README.md", ".gitignore",
]


def main():
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    path = out / "T2_code_only.zip"
    for name in CODE:
        assert (ROOT / name).is_file(), name
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in CODE:
            z.write(ROOT / name, "T2/" + name)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == {"T2/" + n for n in CODE}
    assert path.stat().st_size < 20_000_000
    print(json.dumps({"path": str(path), "bytes": path.stat().st_size,
                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "files": len(CODE)}, indent=2))


if __name__ == "__main__":
    main()
