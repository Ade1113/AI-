"""Publication-style figures from saved simulation outputs, never fitted curves."""
from pathlib import Path
import json
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from inventory import Config,BatchPolicy
from summarize import load
from paper_reference import FIGURE4

ROOT=Path(__file__).resolve().parent
R=ROOT/"results";F=ROOT/"figures"
F.mkdir(exist_ok=True)
plt.rcParams.update({
    "font.family":["Times New Roman","DejaVu Serif"],
    "font.size":10,"axes.titlesize":12,"axes.labelsize":11,
    "axes.edgecolor":"#999999","axes.linewidth":.65,
    "axes.spines.top":False,"axes.spines.right":False,
    "axes.axisbelow":True,"grid.color":"#DDDDDD","grid.linewidth":.65,
    "legend.fontsize":9,"legend.frameon":False,
    "svg.fonttype":"none","savefig.facecolor":"white"})
BLUE="#4472C4";ORANGE="#ED7D31";CYAN="#00A6D2";GRAY="#777777";GREEN="#447744"


def save(fig,name):
    fig.savefig(F/(name+".png"),dpi=300,bbox_inches="tight",pad_inches=.1)
    fig.savefig(F/(name+".svg"),bbox_inches="tight",pad_inches=.1)
    plt.close(fig)


def caption(fig,text):
    fig.text(.5,.01,text,ha="center",fontsize=11)


def load_policy(path):
    d=torch.load(path,map_location="cpu",weights_only=True)
    m=BatchPolicy([Config(**d["config"])],d["mode"],
                   normalize=d.get("normalize",True),time_input=d.get("time_input",False))
    m.load_state_dict(d["state"]);m.eval()
    return m


def surface(path,iv,pv):
    m=load_policy(path);c=m.configs[0]
    pp,ii=np.meshgrid(pv,iv)
    inventory=torch.tensor(ii.reshape(1,-1),dtype=torch.float32)
    pipeline=torch.tensor(pp.reshape(1,-1,1),dtype=torch.float32)
    target=torch.full_like(inventory,c.target())
    with torch.no_grad():q=m(inventory,pipeline,target,0).numpy().reshape(ii.shape)
    return q


def main(summary=None,small_only=False):
    torch.set_num_threads(1)
    S=json.loads((R/"summary.json").read_text()) if summary is None else summary
    methods=["LIR","WNH","GDSH","DRL"]
    fig,ax=plt.subplots(figsize=(7.6,4.3));fig.subplots_adjust(left=.1,bottom=.23,top=.9,right=.98)
    x=np.arange(4);width=.34
    for i,(L,col) in enumerate([(2,BLUE),(3,ORANGE)]):
        entries=S["small"][str(L)]["gaps_to_expected_dp"]
        val=[entries[k]["mean"] for k in methods];err=[entries[k]["ci95"] for k in methods]
        pos=x+(i-.5)*width
        ax.bar(pos,val,width,color=col,label=f"L = {L}",zorder=3)
        ax.errorbar(pos,val,yerr=err,fmt="none",ecolor="#333333",capsize=2,lw=.7,zorder=4)
        ax.scatter(pos,[FIGURE4[f"L{L}"][k] for k in methods],marker="D",s=26,
                   facecolors="white",edgecolors="#333333",lw=.8,zorder=5,label="Paper values" if i==0 else None)
        for xx,v,e in zip(pos,val,err):ax.text(xx,v+e+.08,f"{v:.2f}%",ha="center",fontsize=8)
    ax.set_xticks(x,methods);ax.set(ylabel="Cost gap to numerical DP",title="Small-size inventory problems")
    ax.yaxis.set_major_formatter(PercentFormatter(100));ax.grid(axis="y")
    ax.set_ylim(bottom=min(0,ax.get_ylim()[0]),top=ax.get_ylim()[1]+.35)
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.1),ncol=3)
    caption(fig,"Figure 4(a)");save(fig,"figure04a")

    fig,ax=plt.subplots(figsize=(7.6,4.3));fig.subplots_adjust(left=.1,bottom=.30,top=.9,right=.98)
    for key,label,col,marker in [("delta_episode","DRL: episode loss",BLUE,"o"),
                                ("delta_batch","DRL: batch loss audit",ORANGE,"s")]:
        rows=S["delta"][key];xx=[r["delta"] for r in rows];yy=[r["mean"] for r in rows]
        ax.errorbar(xx,yy,yerr=[r["ci95"] for r in rows],color=col,marker=marker,lw=1.4,ms=4,capsize=2,label=label)
    ax.axhline(S["delta_wnh"]["mean"],color=GRAY,lw=1.2,label="WNH")
    ax.plot(FIGURE4["delta"],FIGURE4["DRL_delta"],color="black",ls=":",marker="^",ms=4,lw=1,label="Paper DRL")
    ax.set(xlabel=r"$\delta$",ylabel="Cost gap to numerical DP",title="Range hyperparameter, L = 2 and p = 0.7")
    ax.yaxis.set_major_formatter(PercentFormatter(100));ax.grid(axis="y")
    ax.set_xticks(FIGURE4["delta"])
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.19),ncol=2)
    caption(fig,"Figure 4(b)");save(fig,"figure04b")

    # Additional two-panel export follows the published arrangement closely.
    # Only new simulation values appear in this version.
    fig,axs=plt.subplots(1,2,figsize=(9.3,4.3))
    fig.subplots_adjust(left=.075,right=.99,bottom=.25,top=.88,wspace=.25)
    x=np.arange(4)
    for j,(L,color) in enumerate([(2,BLUE),(3,ORANGE)]):
        yy=[S["small"][str(L)]["gaps_to_expected_dp"][k]["mean"] for k in methods]
        pos=x+(j-.5)*.34
        axs[0].bar(pos,yy,width=.34,color=color,label=f"L = {L}")
        for xx,v in zip(pos,yy):
            axs[0].text(xx,v+.05,f"{v:.2f}%",ha="center",fontsize=7)
    axs[0].set_xticks(x,methods);axs[0].set_title("Cost gap to DP")
    axs[0].set_ylim(0,max(S["small"][str(L)]["gaps_to_expected_dp"][k]["mean"]
                           for L in [2,3] for k in methods)*1.15)
    rows=S["delta"]["delta_episode"]
    xx=[r["delta"] for r in rows];yy=[r["mean"] for r in rows]
    axs[1].plot(xx,yy,color=BLUE,lw=1.4,label="DRL")
    axs[1].axhline(S["delta_wnh"]["mean"],color=ORANGE,lw=1.4,label="WNH")
    axs[1].set(xlabel=r"$\delta$",title="Cost gap to DP (L = 2)",xticks=xx,ylim=(0,max(yy+[S["delta_wnh"]["mean"]])*1.15))
    for xx0,v in zip(xx,yy):axs[1].text(xx0,v-.2,f"{v:.2f}%",ha="center",fontsize=7)
    for j,ax in enumerate(axs):
        ax.yaxis.set_major_formatter(PercentFormatter(100))
        ax.grid(axis="y")
        ax.legend(loc="upper center",bbox_to_anchor=(.5,-.13),ncol=2,fontsize=8)
        ax.text(.5,-.29,"(a)" if j==0 else "(b)",transform=ax.transAxes,ha="center")
        ax.spines["top"].set_visible(True);ax.spines["right"].set_visible(True)
    caption(fig,"Figure 4");save(fig,"figure04_combined")
    if small_only:
        return

    lr,lc=load("large",432);_,lb=load("large_batch_loss",432)
    lc["DRL_batch"]=lb["DRL"]
    for names,labels,fn,cap in [
        (["DRL","GDSH"],["DRL: episode loss","GDSH"],"figure05","Figure 5"),
        (["DRL","DRL_batch"],["DRL: episode loss","DRL: batch loss audit"],"figure05_audit","Figure 5 implementation audit")]:
        fig,axs=plt.subplots(1,2,figsize=(9,4.2),sharey=True)
        fig.subplots_adjust(left=.09,right=.99,bottom=.21,top=.89,wspace=.13)
        for ax,k,label in zip(axs,names,labels):
            gap=100*(lc[k].mean(axis=1)/lc["LIR"].mean(axis=1)-1)
            ax.scatter(np.arange(1,433),gap,s=9,color=CYAN,alpha=.9)
            ax.axhline(0,color=GRAY,lw=.8)
            ax.set(title=label,xlabel="Problem instance",xlim=(0,440),xticks=[1,108,216,324,432])
            ax.yaxis.set_major_formatter(PercentFormatter(100));ax.grid()
        axs[0].set_ylabel("Cost gap to LIR")
        caption(fig,cap);save(fig,fn)

    fig,axs=plt.subplots(1,2,figsize=(9,4.2),sharey=True)
    fig.subplots_adjust(left=.09,right=.99,bottom=.24,top=.9,wspace=.15)
    original=[[-6.33,-3.91,-4.07,-4.55,-3.92,-3.42,-2.41,-1.23,-.21],
              [-6.78,-3.9,-3.55,-4.16,-3.71,-3.49,-2.55,-1.32,-.38]]
    for i,(ax,dist) in enumerate(zip(axs,["normal","gamma"])):
        rows=[r for r in S["subgroups"] if r["distribution"]==dist and r["parameter"]=="p"]
        xx=[r["value"] for r in rows]
        for key,label,col,ls in [("DRL","DRL: episode",BLUE,"-"),
                                 ("DRL_batch","DRL: batch audit",ORANGE,"--"),
                                 ("GDSH","GDSH",GREEN,"-.")]:
            ax.plot(xx,[r[key+"_gap"] for r in rows],color=col,ls=ls,marker="o",ms=3,lw=1.2,label=label)
        ax.plot(xx,original[i],color=GRAY,ls=":",marker="^",ms=3,label="Paper DRL")
        ax.set(title=dist.capitalize()+" demand",xlabel="Yield probability p")
        ax.yaxis.set_major_formatter(PercentFormatter(100));ax.grid(axis="y")
    axs[0].set_ylabel("Cost gap to LIR")
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="lower center",bbox_to_anchor=(.5,.045),ncol=4)
    caption(fig,"Yield sensitivity");save(fig,"yield_sensitivity")

    # The two Appendix B cases are fixed in advance by the published caption.
    ids=[]
    for dist,var in [("normal",2.),("gamma",3.2)]:
        ids.append(next(i for i,r in enumerate(lr) if r["config"]["distribution"]==dist
                        and r["config"]["L"]==2 and r["config"]["T"]==50
                        and r["config"]["p"]==.55 and abs(r["config"]["b"]-9)<1e-9
                        and r["config"]["sd" if dist=="normal" else "scale"]==var))
    surfaces={}
    for row,i in enumerate(ids):
        c=Config(**lr[i]["config"])
        iv=np.linspace(-290,70,121);pv=np.linspace(0,100 if row==0 else 300,121)
        pp,ii=np.meshgrid(pv,iv)
        lir=np.maximum(c.target()-ii-c.p*pp,0)
        wnh=(1-c.p)*np.maximum(c.target()-ii,0)+c.p*np.maximum(c.target()-ii-pp,0)
        surfaces[row]={"I":iv,"pipeline":pv,"LIR":lir,"WNH":wnh,
                       "DRL":surface(R/"large"/f"{i:04d}"/"DRL.pt",iv,pv),
                       "DRL_batch":surface(R/"large_batch_loss"/f"{i:04d}"/"DRL.pt",iv,pv)}
    np.savez_compressed(R/"policy_surfaces.npz",**{f"row{row}_{k}":v for row,d in surfaces.items() for k,v in d.items()})
    for k,fn,cap in [("DRL","figureB01","Figure B.1"),("DRL_batch","figureB01_audit","Figure B.1 batch-loss audit")]:
        fig,axs=plt.subplots(2,3,figsize=(9.3,6.4),layout="constrained")
        for row in [0,1]:
            s=surfaces[row];hi=max(float(s[x].max()) for x in ["LIR","WNH",k])
            for col,mode in enumerate(["LIR","WNH",k]):
                ax=axs[row,col]
                im=ax.imshow(s[mode],origin="lower",extent=[s["pipeline"][0],s["pipeline"][-1],s["I"][0],s["I"][-1]],
                             aspect="auto",interpolation="nearest",cmap="RdBu_r",vmin=0,vmax=hi)
                ax.set(title=f"({chr(97+row*3+col)}) "+["LIR","WNH","DRL"][col],xlabel="Pipeline order")
                if col==0:ax.set_ylabel(("Normal" if row==0 else "Gamma")+"\nInventory level")
            fig.colorbar(im,ax=axs[row,:],label="Order quantity",shrink=.85,pad=.02)
        fig.suptitle(cap,fontsize=12)
        save(fig,fn)
    fig,axs=plt.subplots(2,2,figsize=(8.0,6.2),layout="constrained")
    for row in [0,1]:
        s=surfaces[row]
        vals=[s[k]-s["DRL"] for k in ["LIR","WNH"]]
        bound=max(float(np.abs(v).max()) for v in vals)
        for col,(k,v) in enumerate(zip(["LIR","WNH"],vals)):
            ax=axs[row,col]
            im=ax.imshow(v,origin="lower",extent=[0,s["pipeline"][-1],s["I"][0],s["I"][-1]],
                         aspect="auto",cmap="RdBu_r",vmin=-bound,vmax=bound,interpolation="nearest")
            ax.set(title=f"({chr(97+row*2+col)}) "+k+" minus DRL",xlabel="Pipeline order")
            if col==0:ax.set_ylabel(("Normal" if row==0 else "Gamma")+"\nInventory level")
        fig.colorbar(im,ax=axs[row,:],label="Order difference",shrink=.85,pad=.02)
    fig.suptitle("Figure B.2",fontsize=12);save(fig,"figureB02")

    fig,axs=plt.subplots(1,2,figsize=(9,4.2))
    fig.subplots_adjust(left=.09,right=.99,bottom=.23,top=.88,wspace=.25)
    for row,(ax,i) in enumerate(zip(axs,ids)):
        teacher=np.load(R/"large"/f"{i:04d}"/"DRL_training.npy")[0,0]
        for parent,file,label,col,ls in [
            ("large","GDSH_training.npy","GDSH",GREEN,"-."),
            ("large","DRL_training.npy","DRL: episode",BLUE,"-"),
            ("large_batch_loss","training.npy","DRL: batch audit",ORANGE,"--")]:
            arr=np.load(R/parent/f"{i:04d}"/file)
            ax.plot(np.arange(len(arr)),100*(arr[:,0]/teacher-1),color=col,ls=ls,lw=1.3,label=label)
        ax.set(title=["Normal demand","Gamma demand"][row],xlabel="Training epoch")
        ax.yaxis.set_major_formatter(PercentFormatter(100));ax.grid(axis="y")
    axs[0].set_ylabel("Training cost gap to WNH")
    handles,labels=axs[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="lower center",bbox_to_anchor=(.5,.045),ncol=3)
    caption(fig,"Training diagnostics");save(fig,"learning")
    (R/"figure_manifest.json").write_text(json.dumps({"appendix_B_indices":ids,
                    "png_count":len(list(F.glob("*.png"))),"dpi":300},indent=2))
    print("Saved figures",len(list(F.glob("*.png"))))


if __name__=="__main__":main()
