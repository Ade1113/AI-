"""Pre-specified 12-case GDSH optimizer diagnostic, separate from main results."""
from pathlib import Path
from dataclasses import asdict
import json
import numpy as np
from scipy.optimize import minimize
import torch
from inventory import Config, BatchPolicy, sample, rollout
from experiments import seeds

ROOT = Path(__file__).resolve().parent
INDICES = [80, 81, 242, 243, 404, 405, 566, 567, 728, 729, 890, 891]


def main():
    torch.set_num_threads(1)
    design = json.loads((ROOT / "results/small/design.json").read_text())["design"]
    out = ROOT / "results/optimizer_audit"
    out.mkdir(exist_ok=True)
    rows = []
    for i in INDICES:
        c = Config(**design[i])
        ss = seeds("small", i)
        d, y = sample(c, 500, ss["training"])
        dt, yt = (torch.tensor(v[None], dtype=torch.float64) for v in [d, y])
        m = BatchPolicy([c], "GDSH", dtype=torch.float64)

        def objective(w):
            with torch.no_grad():
                m.weights.copy_(torch.tensor(w[None], dtype=torch.float64))
            m.zero_grad(set_to_none=True)
            loss = rollout(m, dt, yt).mean()
            loss.backward()
            return loss.item(), m.weights.grad.numpy().ravel().copy()

        opt = minimize(objective, m.weights.detach().numpy().ravel().copy(), jac=True,
                       method="L-BFGS-B", bounds=[(0, None)] * m.weights.numel(),
                       options={"maxiter": 500, "maxls": 40, "ftol": 1e-12, "gtol": 1e-6})
        objective(opt.x)
        saved = torch.load(ROOT / "results/small" / f"{i:04d}" / "GDSH.pt", weights_only=True)
        adam = BatchPolicy([c], "GDSH", dtype=torch.float64)
        adam.load_state_dict(saved["state"])
        costs = {}
        with torch.no_grad():
            train_adam = float(rollout(adam, dt, yt).mean())
            for tag, n, seed in [("primary", 100, ss["test"]), ("audit", 5000, ss["audit_test"])]:
                dd, yy = sample(c, n, seed)
                td, ty = (torch.tensor(v[None], dtype=torch.float64) for v in [dd, yy])
                for name, policy in [("GDSH_lbfgs", m), ("GDSH_adam", adam)]:
                    costs[name + "_" + tag] = rollout(policy, td, ty).numpy()[0]
        dp = json.loads((ROOT / "results/small" / f"{i:04d}" / "dp_step1_cap2.json").read_text())
        row = {"index": i, "config": asdict(c), "ntrain": 500, "ntest_audit": 5000,
               "train_adam": train_adam, "train_lbfgs": float(opt.fun),
               "test": {k: float(v.mean()) for k, v in costs.items()},
               "dp_expected": dp["value"], "success": bool(opt.success), "message": str(opt.message),
               "iterations": int(opt.nit), "function_evaluations": int(opt.nfev),
               "weights": opt.x.tolist(), "seeds": ss}
        (out / f"{i:04d}.json").write_text(json.dumps(row, indent=2))
        np.savez_compressed(out / f"{i:04d}.npz", **costs)
        rows.append(row)
        print(i, "training", train_adam, opt.fun, "audit", row["test"], flush=True)
    (out / "summary.json").write_text(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
