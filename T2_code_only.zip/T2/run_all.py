"""Portable orchestration, with a separate quick smoke-test output directory."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REFINEMENTS = "80,81,242,243,404,405,566,567,728,729,890,891"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["full", "smoke", "report"], default="smoke")
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--dp-workers", type=int, default=1)
    p.add_argument("--dp-python", default=sys.executable,
                   help="Optional separate Python interpreter with NumPy, SciPy, Numba")
    p.add_argument("--docx-python", default=sys.executable,
                   help="Optional separate Python interpreter with python-docx")
    a = p.parse_args()
    if min(a.workers, a.dp_workers) < 1:
        p.error("Worker counts must be positive")
    env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"}

    def run(script, *args, python=sys.executable):
        cmd = [python, str(ROOT / script), *map(str, args)]
        print("RUN", script, *args, flush=True)
        subprocess.run(cmd, cwd=ROOT, env=env, check=True)

    if a.mode != "report":
        run("tests/verify.py")
        run("tests/verify_dp.py", python=a.dp_python)
    if a.mode == "smoke":
        run("run_experiments.py", "--stage", "small", "--workers", "1",
            "--limit", "2", "--epochs", "3", "--train-trajectories", "16",
            "--test-trajectories", "16", "--output", ROOT / "results_smoke")
        print("Smoke check complete. This is not a reproduction result.")
        return
    if a.mode == "full":
        for stage in ["small", "large"]:
            run("run_experiments.py", "--stage", stage, "--workers", a.workers)
            run("prepare_test_paths.py", "--stage", stage)
        info = subprocess.run(
            [a.dp_python, "-c", "import sys,json,numpy,scipy,numba; "
             "print(json.dumps({'python':sys.version,'libraries':"
             "{m.__name__:m.__version__ for m in [numpy,scipy,numba]}},indent=2))"],
            cwd=ROOT, env=env, text=True, capture_output=True, check=True)
        (ROOT / "results/dp_runtime.json").write_text(info.stdout)
        run("dynamic_programming.py", "--workers", a.dp_workers, python=a.dp_python)
        run("dynamic_programming.py", "--workers", "1", "--step", ".5",
            "--indices", REFINEMENTS, python=a.dp_python)
        run("dynamic_programming.py", "--workers", "1", "--cap-multiplier", "3",
            "--indices", REFINEMENTS, python=a.dp_python)
        for stage, variant in [
            ("small", "batch_loss"), ("large", "batch_loss"),
            ("small", "delta_episode"), ("small", "delta_batch"),
            ("large", "time_episode"),
        ]:
            run("run_variants.py", "--stage", stage, "--variant", variant,
                "--workers", a.workers)
        run("run_extensions.py")
        run("audit_optimizer.py")
        run("verify_saved_models.py")
        run("audit_results.py")
    run("summarize.py")
    run("make_figures.py")
    run("build_report.py", python=a.docx_python)
    print("Complete. Review results/summary.json and report/.")


if __name__ == "__main__":
    main()
