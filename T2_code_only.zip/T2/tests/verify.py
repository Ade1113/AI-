"""Meaningful dynamics, gradient, and independence checks."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from inventory import *
from experiments import design


def main():
    torch.set_num_threads(1)
    checks=[]
    assert len(design("small")) == 972 and len(design("large")) == 432
    checks.append("published factorial design sizes")
    c=Config(L=3,T=10)
    assert np.isclose(teacher_weights(c).sum(),1)
    assert np.isclose(c.target(),4*10+ndtri(.9)*np.sqrt(4*4+3*.3/.4*104))
    checks.append("target stock formula and Bernoulli-path probabilities")
    d,y=sample(c,16,12345)
    d2,y2=sample(c,16,12345)
    assert np.array_equal(d,d2) and np.array_equal(y,y2)
    assert not np.array_equal(d,sample(c,16,12346)[0])
    checks.append("reproducible and separate random trajectories")
    for mode in ["LIR","WNH"]:
        policy=BatchPolicy([c],mode,dtype=torch.float64)
        tc,paths=rollout(policy,torch.tensor(d[None],dtype=torch.float64),
                         torch.tensor(y[None],dtype=torch.float64),True)
        nc,npaths=numpy_rollout(c,d,y,mode,return_paths=True)
        assert np.allclose(tc.detach().numpy()[0],nc,rtol=1e-12)
        for key in paths: assert np.allclose(paths[key][0],npaths[key],atol=1e-10)
        assert np.all(paths["receipt"][...,:c.L]==0)
        assert np.all(paths["order"][...,-c.L:]==0)
    checks.append("NumPy and PyTorch dynamics agree, including leadtime and terminal orders")
    class Fixed(torch.nn.Module):
        def __init__(self):
            super().__init__();self.configs=[Config(T=4)];self.L=2
        def forward(self,inventory,pipeline,target,t):
            return torch.full_like(inventory,[5.,6.][t])
    tc,paths=rollout(Fixed(),torch.tensor([[[1.,2.,3.,4.]]],dtype=torch.float64),
                     torch.tensor([[[1.,1.,1.,0.]]],dtype=torch.float64),True)
    assert np.allclose(paths["inventory"][0,0],[0,-1,2,-1])
    assert np.allclose(tc.item(),9+.99*27+.99**2*19+.99**3*45)
    checks.append("hand-calculated arrival payment and holding/backlog costs")
    c=Config(T=8)
    d,y=sample(c,10,555)
    dt=torch.tensor(d[None],dtype=torch.float64);yt=torch.tensor(y[None],dtype=torch.float64)
    model=BatchPolicy([c],"GDSH",dtype=torch.float64)
    with torch.no_grad():model.weights.copy_(torch.tensor([[.32,.73]]))
    loss=rollout(model,dt,yt).mean();loss.backward()
    grad=model.weights.grad.detach().numpy().copy()
    for j in range(2):
        vals=[]
        for step in [1e-5,-1e-5]:
            with torch.no_grad():model.weights[0,j]+=step
            vals.append(rollout(model,dt,yt).mean().item())
            with torch.no_grad():model.weights[0,j]-=step
        assert np.isclose(grad[0,j],(vals[0]-vals[1])/2e-5,rtol=2e-5,atol=2e-5)
    checks.append("full-trajectory autograd agrees with central finite differences")
    net=BatchPolicy([c],"DRL",seeds=[37],dtype=torch.float64)
    base=BatchPolicy([c],"WNH",dtype=torch.float64)
    assert torch.allclose(rollout(net,dt,yt),rollout(base,dt,yt),atol=1e-10)
    checks.append("neural policy initializes exactly at WNH")
    data=np.stack([d,d]);yy=np.stack([y,y])
    batch,hist,_=train([c,c],data,yy,[37,38],epochs=3)
    single,hist1,_=train([c],data[:1],yy[:1],[37],epochs=3)
    for key,val in single.state_dict().items():
        if key != "bits":assert torch.allclose(val,batch.state_dict()[key][:1],atol=1e-7)
    checks.append("independently batched models match single-model training")
    out=Path(__file__).resolve().parents[1]/"results/verification.json"
    out.parent.mkdir(exist_ok=True,parents=True)
    msg={"status":"PASS","checks":checks}
    out.write_text(json.dumps(msg,indent=2));print(json.dumps(msg,indent=2))


if __name__=="__main__":main()
