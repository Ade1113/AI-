"""Independent numerical-DP checks; does not import the neural-network code."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from dynamic_programming import solve,bellman,demand_expectation,demand_pmf,evaluate


def main():
    checks=[]
    x=np.arange(9,dtype=float).reshape(9,1,1)
    for prob in [np.array([.25,.75]),np.array([.1,.2,.7])]:
        assert np.allclose(demand_expectation(x,prob)[:,0,0],np.arange(9)-np.arange(len(prob))@prob)
    checks.append("demand convolution direction and boundary extrapolation")
    dg,prob=demand_pmf(6.,2.,1.)
    assert np.isclose(prob.sum(),1) and np.all(prob>=0)
    checks.append("discretized normal probability mass conserved")
    c={'L':2,'T':4,'mu':1.,'sd':0.,'h':1.,'b':9.,'co':2.,'p':1.,'alpha':.99}
    meta,pol=solve(c)
    expected=9+.99*18+.99**2*6+.99**3*2
    assert np.isclose(meta['value'],expected,atol=1e-10)
    costs,clips,hits=evaluate(pol,np.ones((2,4)),np.ones((2,4)),2,1.,meta["bound"],2.,1.,9.,.99)
    assert np.allclose(costs,expected) and clips==0
    checks.append("DP and simulator agree with hand-computed deterministic optimum")
    rng=np.random.default_rng(338)
    for L in [2,3]:
        middle=1 if L==2 else 8
        for kind in ["convex","nonconvex"]:
            ev=rng.normal(size=(20,middle,8))
            if kind=="convex":ev=np.cumsum(np.cumsum(np.abs(ev),axis=-1),axis=-1)
            holding=rng.random(20)
            v,p,_=bellman(ev,holding,.7,.95,.3,True,L)
            vb,pb,_=bellman(ev,holding,.7,.95,.3,True,L,True)
            assert np.allclose(v,vb,rtol=0,atol=1e-12)
            assert np.array_equal(p,pb)
    checks.append("convexity-checked binary search and fallback match exhaustive action search")
    c.update(L=3,T=5,mu=1.,sd=.5,p=.7)
    a,_=solve(c);b,_=solve(c,force_exhaustive=True)
    assert np.isclose(a["value"],b["value"],atol=1e-10)
    checks.append("full stochastic L=3 recursion matches exhaustive DP")
    out=Path(__file__).resolve().parents[1]/"results/verification_dp.json"
    out.parent.mkdir(parents=True,exist_ok=True)
    msg={"status":"PASS","checks":checks};out.write_text(json.dumps(msg,indent=2))
    print(json.dumps(msg,indent=2))


if __name__=="__main__":main()
