"""Finite-horizon numerical DP on explicitly documented inventory/action grids.

This solver does not import the learning implementation. Normal demand is
discretized by CDF bin masses; tail probability is retained in endpoint bins.
The expected purchase payment is moved to the ordering date with alpha**L.
This is equivalent in expectation to paying for successful receipts on arrival.
"""
from pathlib import Path
import argparse,json,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.special import ndtr,ndtri
from scipy.ndimage import convolve1d
from numba import njit


def target(c):
    p,L,mu,sd=c["p"],c["L"],c["mu"],c["sd"]
    return (L+1)*mu+ndtri(c["b"]/(c["b"]+c["h"]))*np.sqrt(
        (L+1)*sd**2+L*(1-p)/(2*p-1)*(mu*mu+sd*sd))


def demand_pmf(mu,sd,step):
    if sd == 0:
        grid=np.arange(int(round(mu/step))+1)*step
        prob=np.zeros(len(grid));prob[-1]=1.
        return grid,prob
    top=int(np.ceil((mu+6*sd)/step))
    grid=np.arange(top+1)*step
    edges=(grid[:-1]+.5*step-mu)/sd
    cdf=ndtr(edges)
    prob=np.diff(np.r_[0.,cdf,1.])
    return grid,prob


def demand_expectation(v,prob):
    n=len(prob)-1
    if n == 0:return v.copy()
    extra=v[:1]-np.arange(n,0,-1).reshape((-1,)+(1,)*(v.ndim-1))*(v[1:2]-v[:1])
    padded=np.concatenate([extra,v],axis=0)
    out=convolve1d(padded,prob,axis=0,origin=-(len(prob)//2),mode="nearest")
    return out[n:]


@njit(cache=True)
def value_at(ev,i,j,k):
    n=ev.shape[0]
    if i<n:return ev[i,j,k]
    return ev[n-1,j,k]+(i-n+1)*(ev[n-1,j,k]-ev[n-2,j,k])


@njit(cache=True)
def bellman(ev,holding,p,alpha,purchase,allow,L,force_exhaustive=False):
    ni,m1,m=ev.shape
    out=np.empty_like(ev)
    policy=np.zeros(ev.shape,np.uint16)
    convex=np.ones((ni,m1),np.bool_)
    for i in range(ni):
        for j in range(m1):
            for k in range(1,m-1):
                if ev[i,j,k+1]-2*ev[i,j,k]+ev[i,j,k-1] < -1e-8:
                    convex[i,j]=False
                    break
    fallback=0
    for i in range(ni):
        for a in range(m):
            # For L=2 the preceding middle dimension has length one.
            for b in range(m1):
                jj=b if L==3 else 0
                i2=i+a
                if not allow:
                    best=0
                elif not force_exhaustive and i2<ni and convex[i,jj] and convex[i2,jj]:
                    lo,hi=0,m-1
                    while lo<hi:
                        mid=(lo+hi)//2
                        f0=purchase*mid+alpha*((1-p)*ev[i,jj,mid]+p*ev[i2,jj,mid])
                        f1=purchase*(mid+1)+alpha*((1-p)*ev[i,jj,mid+1]+p*ev[i2,jj,mid+1])
                        if f1>=f0:hi=mid
                        else:lo=mid+1
                    best=lo
                else:
                    fallback+=1
                    best=0
                    bestv=alpha*((1-p)*ev[i,jj,0]+p*value_at(ev,i2,jj,0))
                    for q in range(1,m):
                        val=purchase*q+alpha*((1-p)*ev[i,jj,q]+p*value_at(ev,i2,jj,q))
                        if val<bestv:
                            bestv=val;best=q
                vv=holding[i]+purchase*best+alpha*((1-p)*ev[i,jj,best]+p*value_at(ev,i2,jj,best))
                if L==3:
                    out[i,a,b]=vv;policy[i,a,b]=best
                else:
                    out[i,0,a]=vv;policy[i,0,a]=best
    return out,policy,fallback


def solve(c,step=1.,cap_multiplier=2.,force_exhaustive=False):
    if c["L"] not in [2,3]:raise ValueError("This numerical DP supports L=2 or L=3")
    dg,prob=demand_pmf(c["mu"],c["sd"],step)
    cap=np.ceil(max(cap_multiplier*target(c),c["mu"]*4)/step)*step
    bound=np.ceil(max(c["T"]*dg[-1],cap)/step)*step
    grid=np.arange(-bound,bound+step/2,step)
    m=int(round(cap/step))+1
    mid=m if c["L"]==3 else 1
    holding=np.maximum(grid[:,None]-dg,0)@(prob*c["h"])+np.maximum(dg-grid[:,None],0)@(prob*c["b"])
    v=np.zeros((len(grid),mid,m))
    policies=[None]*c["T"]
    fallbacks=[]
    start=time.monotonic()
    for t in reversed(range(c["T"])):
        ev=demand_expectation(v,prob)
        v,pol,fall=bellman(ev,holding,c["p"],c["alpha"],
                          c["alpha"]**c["L"]*c["co"]*c["p"]*step,
                          t<c["T"]-c["L"],c["L"],force_exhaustive)
        policies[t]=pol
        fallbacks.append(fall)
    iz=int(round(bound/step))
    return {"value":float(v[iz,0,0]),"step":step,"cap":float(cap),"bound":float(bound),
            "states_per_period":int(v.size),"seconds":time.monotonic()-start,
            "exhaustive_fallback_states":int(sum(fallbacks)),
            "demand_grid_mean":float(dg@prob),"demand_tail_cap":float(dg[-1])},np.stack(policies)


@njit(cache=True)
def evaluate(policy,d,y,L,step,bound,co,h,b,alpha):
    n,T=d.shape
    ni,m1,m=policy.shape[1:]
    costs=np.zeros(n)
    clip_count=0
    cap_hits=0
    for s in range(n):
        inv=0.
        pipe=np.zeros(L)
        for t in range(T):
            arrival=y[s,t]*pipe[0]
            inv+=arrival
            q=0.
            if t<T-L:
                x=(inv+bound)/step
                u=pipe[1]/step
                w=pipe[2]/step if L==3 else 0.
                if x<0 or x>ni-1 or u>m-1 or w>m-1:clip_count+=1
                x=min(max(x,0),ni-1.000000001)
                u=min(max(u,0),m-1.000000001)
                w=min(max(w,0),m-1.000000001) if L==3 else 0.
                ix,iu,iw=int(x),int(u),int(w)
                fx,fu,fw=x-ix,u-iu,w-iw
                for a in range(2):
                    for aa in range(2):
                        if L==2:
                            q+=((1-fx) if a==0 else fx)*((1-fu) if aa==0 else fu)*policy[t,ix+a,0,iu+aa]
                        else:
                            for bb in range(2):
                                q+=((1-fx) if a==0 else fx)*((1-fu) if aa==0 else fu)*((1-fw) if bb==0 else fw)*policy[t,ix+a,iu+aa,iw+bb]
                q*=step
                if q>=(m-1)*step-1e-7:cap_hits+=1
            inv-=d[s,t]
            costs[s]+=alpha**t*(co*arrival+h*max(inv,0)+b*max(-inv,0))
            for j in range(L-1):pipe[j]=pipe[j+1]
            pipe[L-1]=q
    return costs,clip_count,cap_hits


def run_one(payload):
    index,c,root,step,mult=payload
    root=Path(root);dest=root/f"{index:04d}"
    tag=f"dp_step{step:g}_cap{mult:g}"
    jf=dest/(tag+".json")
    if jf.exists():return {"index":index,"cached":True}
    meta,policy=solve(c,step,mult)
    paths=np.load(dest/"test_paths.npz")
    costs,clipped,cap_hits=evaluate(policy,paths["demand"],paths["yield"],c["L"],step,meta["bound"],
                                   c["co"],c["h"],c["b"],c["alpha"])
    meta.update(index=index,test_cost=float(costs.mean()),clipped_test_states=int(clipped),
                capped_test_orders=int(cap_hits),config=c)
    np.savez_compressed(dest/(tag+".npz"),cost=costs)
    jf.write_text(json.dumps(meta,indent=2))
    return {"index":index,"L":c["L"],"step":step,"value":meta["value"],
            "test":meta["test_cost"],"seconds":round(meta["seconds"],2),"clips":int(clipped)}


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--results",type=Path,default=Path(__file__).resolve().parent/"results/small")
    p.add_argument("--step",type=float,default=1.)
    p.add_argument("--cap-multiplier",type=float,default=2.)
    p.add_argument("--workers",type=int,default=2)
    p.add_argument("--indices",type=str)
    a=p.parse_args()
    design=json.loads((a.results/"design.json").read_text())["design"]
    ids=range(len(design)) if a.indices is None else [int(i) for i in a.indices.split(",")]
    jobs=[(i,design[i],str(a.results),a.step,a.cap_multiplier) for i in ids]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for f in as_completed([pool.submit(run_one,j) for j in jobs]):
            print(json.dumps(f.result()),flush=True)
