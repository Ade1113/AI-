"""Explicit, paired implementation sensitivity experiments."""
from pathlib import Path
from dataclasses import asdict,replace
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,time
import numpy as np
import torch
from inventory import Config,sample,train,rollout
from experiments import seeds
from run_experiments import worker_init

ROOT=Path(__file__).resolve().parent


def worker(payload):
    stage,variant,rows,out,aggregation,time_input,normalize=payload
    out=Path(out)
    cs=[Config(**r["config"]) for r in rows]
    training=[sample(c,500,seeds(stage,r["source_index"])["training"]) for c,r in zip(cs,rows)]
    testing=[sample(c,100,seeds(stage,r["source_index"])["test"]) for c,r in zip(cs,rows)]
    d=np.stack([x[0] for x in training]);y=np.stack([x[1] for x in training])
    td=torch.tensor(np.stack([x[0] for x in testing]));ty=torch.tensor(np.stack([x[1] for x in testing]))
    start=time.monotonic()
    model,hist,_=train(cs,d,y,[seeds(stage,r["source_index"])["network"] for r in rows],
                       epochs=300,normalize=normalize,time_input=time_input,
                       loss_aggregation=aggregation)
    with torch.no_grad():costs=rollout(model,td,ty).cpu().numpy()
    for i,r in enumerate(rows):
        dest=out/f'{r["index"]:04d}';dest.mkdir(parents=True,exist_ok=True)
        state={key:(v if key=="bits" else v[i:i+1]).detach().cpu() for key,v in model.state_dict().items()}
        torch.save({"config":asdict(cs[i]),"state":state,"mode":"DRL",
                    "normalize":normalize,"time_input":time_input},dest/"DRL.pt")
        np.save(dest/"training.npy",hist[:,i])
        np.savez_compressed(dest/"evaluation.npz",DRL=costs[i])
        meta={**r,"stage":stage,"variant":variant,"aggregation":aggregation,
              "time_input":time_input,"normalize":normalize,"cost":float(costs[i].mean()),
              "se":float(costs[i].std(ddof=1)/10),"ntrain":500,"ntest":100,"epochs":300,
              "seeds":seeds(stage,r["source_index"])}
        (dest/"complete.json").write_text(json.dumps(meta,indent=2))
    return {"variant":variant,"indices":[r["index"] for r in rows],
            "seconds":round(time.monotonic()-start,2)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--stage",choices=["small","large"],default="small")
    p.add_argument("--variant",choices=["batch_loss","delta_episode","delta_batch","time_episode","time_batch","raw_inputs"],default="batch_loss")
    p.add_argument("--workers",type=int,default=6)
    p.add_argument("--case-batch",type=int,default=4,
                   help="Independent models computed together; does not change training samples")
    p.add_argument("--limit",type=int)
    a=p.parse_args()
    if a.case_batch < 1 or a.workers < 1:
        p.error("Batch size and workers must be positive")
    source=ROOT/"results"/a.stage
    configs=json.loads((source/"design.json").read_text())["design"]
    rows=[]
    if a.variant.startswith("delta"):
        for radius in [.05,.25,.45,.65,1.]:
            for i,c in enumerate(configs):
                if c["L"]==2 and c["p"]==.7:
                    rows.append({"index":len(rows),"source_index":i,"config":{**c,"delta":radius}})
    else:
        for i,c in enumerate(configs):rows.append({"index":i,"source_index":i,"config":c})
    if a.limit is not None:rows=rows[:a.limit]
    out=ROOT/"results"/f"{a.stage}_{a.variant}"
    out.mkdir(parents=True,exist_ok=True)
    agg="batch" if a.variant in ["batch_loss","delta_batch","time_batch"] else "episode"
    ti=a.variant.startswith("time")
    norm=a.variant!="raw_inputs"
    meta={"stage":a.stage,"variant":a.variant,"aggregation":agg,"time_input":ti,"normalize":norm,"rows":rows}
    mf=out/"design.json"
    if mf.exists() and json.loads(mf.read_text())!=meta:raise ValueError("Variant configuration mismatch")
    mf.write_text(json.dumps(meta,indent=2))
    groups=defaultdict(list)
    for r in rows:
        if not (out/f'{r["index"]:04d}'/"complete.json").exists():
            groups[r["config"]["L"],r["config"]["T"]].append(r)
    jobs=[]
    for group in groups.values():
        for i in range(0,len(group),a.case_batch):
            jobs.append((a.stage,a.variant,group[i:i+a.case_batch],str(out),agg,ti,norm))
    print(json.dumps({"variant":a.variant,"pending":len(jobs)}),flush=True)
    with ProcessPoolExecutor(max_workers=a.workers,initializer=worker_init) as pool:
        for f in as_completed([pool.submit(worker,j) for j in jobs]):print(json.dumps(f.result()),flush=True)
    print("COMPLETE",a.stage,a.variant,flush=True)


if __name__=="__main__":main()
