"""Appendix D.2 seasonal demand experiment, with a separate audit sample."""
from pathlib import Path
from dataclasses import asdict
import json
import numpy as np
import torch
from inventory import Config,sample,numpy_rollout,train,rollout


if __name__=="__main__":
    torch.set_num_threads(1)
    c=Config(T=100,L=2,p=.7,noniid=True)
    root=Path(__file__).resolve().parent/"results/noniid"
    root.mkdir(parents=True,exist_ok=True)
    if (root/"complete.json").exists():
        print("Already complete")
    else:
        d,y=sample(c,500,40_000_000)
        td,ty=sample(c,5000,40_000_001)
        costs={mode:numpy_rollout(c,td,ty,mode) for mode in ["LIR","WNH"]}
        for name,mode,aggregation in [("GDSH","GDSH","episode"),
                                       ("DRL","DRL","episode"),
                                       ("DRL_batch","DRL","batch")]:
            model,hist,_=train([c],d[None],y[None],[40_000_002],mode=mode,
                               loss_aggregation=aggregation,separate_time=mode=="DRL")
            out=[]
            with torch.no_grad():
                for i in range(0,len(td),500):
                    out.append(rollout(model,torch.tensor(td[None,i:i+500]),
                                       torch.tensor(ty[None,i:i+500])).numpy()[0])
            costs[name]=np.concatenate(out)
            np.save(root/f"{name}_training.npy",hist[:,0,:])
            torch.save({"config":asdict(c),"state":model.state_dict(),"separate_time":mode=="DRL",
                        "mode":mode,"normalize":True},root/f"{name}.pt")
            print(name,float(costs[name].mean()),flush=True)
        np.savez_compressed(root/"evaluation.npz",**costs)
        meta={"config":asdict(c),"ntrain":500,"ntest_primary":100,"ntest_audit":5000,
              "epochs":300,"seeds":{"training":40_000_000,"test":40_000_001,"network":40_000_002},
              "target_convention":"Substitute current-period mean and variance in Equation (3); the paper does not specify a unique non-IID safety-stock formula.",
              "primary_costs":{k:float(v[:100].mean()) for k,v in costs.items()},
              "audit_costs":{k:float(v.mean()) for k,v in costs.items()}}
        (root/"complete.json").write_text(json.dumps(meta,indent=2))
