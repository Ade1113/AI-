"""Aggregate actual held-out costs; preserve all implementation variants."""
from pathlib import Path
import json,csv
import numpy as np
from paper_reference import *

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"results"


def load(stage,expected=None):
    files=sorted((OUT/stage).glob("[0-9][0-9][0-9][0-9]/complete.json"))
    if expected is not None:assert len(files)==expected,(stage,len(files),expected)
    rows=[json.loads(f.read_text()) for f in files]
    arrays=[dict(np.load(f.parent/"evaluation.npz")) for f in files]
    return rows,{k:np.stack([a[k] for a in arrays]) for k in arrays[0]}


def mean_stat(x):
    """CI conditional on the fixed parameter design and fitted networks."""
    x=np.asarray(x)
    if x.ndim==1:return {"mean":float(x.mean()),"ci95":None}
    se=np.sqrt(np.sum(np.var(x,axis=1,ddof=1)/x.shape[1]))/len(x)
    return {"mean":float(x.mean()),"ci95":float(1.96*se)}


def gap_stat(x,base):
    x=np.asarray(x);base=np.asarray(base)
    ratio=x.mean()/base.mean()
    if base.ndim==2:
        z=x-ratio*base
    else:
        z=x
    se=np.sqrt(np.sum(np.var(z,axis=1,ddof=1)/x.shape[1]))/len(x)
    return {"mean":float(100*(ratio-1)),"ci95":float(196*se/base.mean())}


def write_csv(name,rows):
    if not rows:return
    with (OUT/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    sr,sc=load("small",972)
    lr,lc=load("large",432)
    _,sb=load("small_batch_loss",972)
    _,lb=load("large_batch_loss",432)
    sc["DRL_batch"]=sb["DRL"];lc["DRL_batch"]=lb["DRL"]
    dpfiles=[OUT/"small"/f"{i:04d}"/"dp_step1_cap2.json" for i in range(972)]
    assert all(p.exists() for p in dpfiles),"Numerical DP incomplete"
    dp=[json.loads(p.read_text()) for p in dpfiles]
    dpe=np.array([r["value"] for r in dp])
    dps=np.stack([np.load(p.with_suffix(".npz"))["cost"] for p in dpfiles])
    summary={"small":{},"large":{},"subgroups":[],"delta":{},"dp_checks":{}}
    for L in [2,3]:
        mask=np.array([r["config"]["L"]==L for r in sr])
        summary["small"][str(L)]={
            "n":int(mask.sum()),"dp_expected":float(dpe[mask].mean()),
            "dp_test":mean_stat(dps[mask]),
            "costs":{k:mean_stat(v[mask]) for k,v in sc.items()},
            "gaps_to_expected_dp":{k:gap_stat(v[mask],dpe[mask]) for k,v in sc.items()},
            "gaps_to_test_dp":{k:gap_stat(v[mask],dps[mask]) for k,v in sc.items()}}
    summary["large"]={
        "n":len(lr),"costs":{k:mean_stat(v) for k,v in lc.items()},
        "gaps_to_lir":{k:gap_stat(v,lc["LIR"]) for k,v in lc.items()},
        "fraction_better_lir":{k:float(np.mean(v.mean(axis=1)<lc["LIR"].mean(axis=1))) for k,v in lc.items()}}
    case_rows=[]
    for stage,rows,costs in [("small",sr,sc),("large",lr,lc)]:
        for i,r in enumerate(rows):
            rec={"stage":stage,"index":i,**r["config"],**{k:float(v[i].mean()) for k,v in costs.items()}}
            if stage=="small":rec.update(dp_expected=dpe[i],dp_test=float(dps[i].mean()))
            else:rec.update(dp_expected="",dp_test="")
            case_rows.append(rec)
    write_csv("case_summary.csv",case_rows)
    for dist,original in [("normal",NORMAL_COST),("gamma",GAMMA_COST)]:
        for (key,val),ref in zip(ROW_KEYS,original):
            mask=[]
            for r in lr:
                c=r["config"]
                selected=(key=="all" or (abs(c["b"]/(c["b"]+c["h"])-val)<1e-9 if key=="ratio" else c[key]==val))
                mask.append(c["distribution"]==dist and selected)
            mask=np.array(mask)
            rec={"distribution":dist,"parameter":key,"value":val,"n":int(mask.sum())}
            for k,v in lc.items():
                rec[k]=float(v[mask].mean())
                rec[k+"_gap"]=gap_stat(v[mask],lc["LIR"][mask])["mean"]
            for k,x in zip(["LIR","WNH","DRL","GDSH"],ref):rec["paper_"+k]=x
            summary["subgroups"].append(rec)
    write_csv("table3_comparison.csv",summary["subgroups"])
    for variant in ["delta_episode","delta_batch"]:
        rows,cost=load("small_"+variant,810)
        summary["delta"][variant]=[]
        for radius in FIGURE4["delta"]:
            ids=[i for i,r in enumerate(rows) if r["config"]["delta"]==radius]
            source=[rows[i]["source_index"] for i in ids]
            z=cost["DRL"][ids]
            stat=gap_stat(z,dpe[source])
            summary["delta"][variant].append({"delta":radius,"n":len(ids),"cost":float(z.mean()),**stat})
    delta_sources=[i for i,r in enumerate(sr) if r["config"]["L"]==2 and r["config"]["p"]==.7]
    summary["delta_wnh"]=gap_stat(sc["WNH"][delta_sources],dpe[delta_sources])
    refinements=[]
    for p in sorted((OUT/"small").glob("*/dp_step0.5_cap2.json")):
        r=json.loads(p.read_text());coarse=dp[r["index"]]
        refinements.append({"index":r["index"],"L":r["config"]["L"],"p":r["config"]["p"],
                            "sd":r["config"]["sd"],"coarse":coarse["value"],"fine":r["value"],
                            "change_pct":100*(r["value"]/coarse["value"]-1)})
    capchecks=[]
    for p in sorted((OUT/"small").glob("*/dp_step1_cap3.json")):
        r=json.loads(p.read_text());coarse=dp[r["index"]]
        capchecks.append({"index":r["index"],"change_pct":100*(r["value"]/coarse["value"]-1)})
    summary["dp_checks"]={"refinements":refinements,"capacity":capchecks,
        "test_state_clips":sum(r["clipped_test_states"] for r in dp),
        "test_order_cap_hits":sum(r["capped_test_orders"] for r in dp),
        "max_refinement_pct":max(abs(r["change_pct"]) for r in refinements) if refinements else None,
        "max_capacity_pct":max(abs(r["change_pct"]) for r in capchecks) if capchecks else None}
    write_csv("dp_refinement.csv",refinements)
    for variant in ["time_episode","time_batch"]:
        folder=OUT/("large_"+variant)
        if folder.exists():
            rr,cc=load("large_"+variant)
            ids=[r["source_index"] for r in rr]
            summary[variant]={"n":len(rr),"cost":mean_stat(cc["DRL"]),
                             "gap_to_lir":gap_stat(cc["DRL"],lc["LIR"][ids]),
                             "gap_to_drl":gap_stat(cc["DRL"],lc["DRL"][ids])}
    summary["counts"]={name:len(list((OUT/name).glob("*/complete.json")))
                       for name in ["small","large","small_batch_loss","large_batch_loss",
                                    "small_delta_episode","small_delta_batch",
                                    "large_time_episode","large_time_batch"]}
    summary["training_runs"]=2*(972+432)+sum(n for name,n in summary["counts"].items() if name not in ["small","large"])
    if (OUT/"noniid/complete.json").exists():
        nr=json.loads((OUT/"noniid/complete.json").read_text())
        nc=dict(np.load(OUT/"noniid/evaluation.npz"))
        summary["noniid"]={"metadata":nr,
            "costs":{k:mean_stat(v[None,:]) for k,v in nc.items()},
            "gaps_to_lir":{k:gap_stat(v[None,:],nc["LIR"][None,:]) for k,v in nc.items()}}
        summary["training_runs"]+=3
    if (OUT/"optimizer_audit/summary.json").exists():
        rows=json.loads((OUT/"optimizer_audit/summary.json").read_text())
        summary["optimizer_audit"]=rows
        summary["training_runs"]+=len(rows)
    (OUT/"summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps({"large":summary["large"],"counts":summary["counts"],"training_runs":summary["training_runs"]},indent=2))


if __name__=="__main__":main()
