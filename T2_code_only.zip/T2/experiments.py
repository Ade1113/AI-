"""Published factorial designs and deterministic training/evaluation seeds."""
from itertools import product
from dataclasses import asdict, replace
from inventory import Config


def design(stage):
    rows = []
    if stage == "small":
        for L,p,co,h,b,mu,sd in product([2,3],[.7,.8,.9],[1.5,2.5,3.5],
                                      [.5,1.,1.5],[4.,5.,6.],[6.,8.,10.],[1.,2.]):
            rows.append(Config(L=L,T=10,p=p,co=co,h=h,b=b,mu=mu,sd=sd,alpha=.95))
    elif stage == "large":
        for dist,v,T,L,ratio,p in product(["normal","gamma"],[0,1],[50,100],[2,5],
                                        [.85,.9,.95],[.55,.6,.65,.7,.75,.8,.85,.9,.95]):
            rows.append(Config(L=L,T=T,p=p,b=ratio/(1-ratio),distribution=dist,
                               sd=[2.,5.][v],scale=[1.6,3.2][v]))
    elif stage == "delta":
        for delta,co,h,b,mu,sd in product([.05,.25,.45,.65,1.],
                                         [1.5,2.5,3.5],[.5,1.,1.5],[4.,5.,6.],
                                         [6.,8.,10.],[1.,2.]):
            rows.append(Config(T=10,alpha=.95,p=.7,co=co,h=h,b=b,mu=mu,sd=sd,delta=delta))
    else:
        raise ValueError(stage)
    return rows


def seeds(stage, index):
    prefix = {"small":10_000_000,"large":20_000_000,"delta":30_000_000,
              "audit":40_000_000}[stage]+index*10
    return {"training":prefix,"test":prefix+1,"network":prefix+2,
            "audit_test":prefix+3}
