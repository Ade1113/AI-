"""Plain academic Word layout; all numerical content comes from the builder."""
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


class Report:
    def __init__(self, title):
        self.doc = Document()
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21), Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(1.9)
        sec.left_margin = sec.right_margin = Cm(2)
        for el in list(sec._sectPr.findall(qn("w:docGrid"))):
            sec._sectPr.remove(el)
        for name in ["Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Caption"]:
            st = self.doc.styles[name]
            st.font.name = "Times New Roman"
            st.font.color.rgb = RGBColor(0, 0, 0)
            fonts = st.element.rPr.rFonts
            for key, val in [("eastAsia", "Noto Sans CJK SC"), ("ascii", "Times New Roman"),
                             ("hAnsi", "Times New Roman")]:
                fonts.set(qn("w:" + key), val)
            for key in list(fonts.attrib):
                if "theme" in key.lower():
                    del fonts.attrib[key]
            pp = st.element.get_or_add_pPr()
            for border in list(pp.findall(qn("w:pBdr"))):
                pp.remove(border)
            snap = OxmlElement("w:snapToGrid")
            snap.set(qn("w:val"), "0")
            pp.append(snap)
        normal = self.doc.styles["Normal"]
        normal.font.size = Pt(10.5)
        normal.paragraph_format.line_spacing = 1.2
        normal.paragraph_format.space_after = Pt(6)
        normal.paragraph_format.first_line_indent = Pt(0)
        for name, size in [("Title", 22), ("Subtitle", 12), ("Heading 1", 15),
                           ("Heading 2", 12), ("Caption", 9)]:
            self.doc.styles[name].font.size = Pt(size)
        cap = self.doc.styles["Caption"]
        cap.font.italic = cap.font.bold = False
        cap.paragraph_format.space_after = Pt(7)
        for name in ["Heading 1", "Heading 2"]:
            self.doc.styles[name].paragraph_format.space_before = Pt(8)
            self.doc.styles[name].paragraph_format.space_after = Pt(8)
        footer = sec.footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)
        self.doc.core_properties.title = title
        self.doc.core_properties.subject = "Yan et al. 2026 独立计算复现及结果检阅"
        self.doc.core_properties.author = "Python 复现实验"

    def p(self, text, style=None):
        return self.doc.add_paragraph(text, style=style)

    def h(self, text):
        return self.doc.add_heading(text, 1)

    def page(self, title):
        par = self.h(title)
        par.paragraph_format.page_break_before = True

    def pic(self, path, width=6.35, note=None):
        par = self.doc.add_paragraph()
        par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        par.paragraph_format.space_after = Pt(2)
        par.paragraph_format.keep_with_next = bool(note)
        par.add_run().add_picture(str(path), width=Inches(width))
        if note:
            self.p(note, "Caption")

    def table(self, headers, rows, widths=None, size=9):
        t = self.doc.add_table(rows=1, cols=len(headers))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        widths = widths or [6.65 / len(headers)] * len(headers)
        for col, width in zip(t.columns, widths):
            col.width = Inches(width)
        for i, val in enumerate(headers):
            t.rows[0].cells[i].text = str(val)
        for row in rows:
            cells = t.add_row().cells
            for i, val in enumerate(row):
                cells[i].text = str(val)
        for ir, row in enumerate(t.rows):
            pr = row._tr.get_or_add_trPr()
            pr.append(OxmlElement("w:cantSplit"))
            if ir == 0:
                pr.append(OxmlElement("w:tblHeader"))
            for i, cell in enumerate(row.cells):
                cell.width = Inches(widths[i])
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                cp = cell._tc.get_or_add_tcPr()
                borders = OxmlElement("w:tcBorders")
                for edge in ["top", "left", "bottom", "right"]:
                    el = OxmlElement("w:" + edge)
                    for key, val in [("val", "single"), ("sz", "4"), ("color", "D9D9D9")]:
                        el.set(qn("w:" + key), val)
                    borders.append(el)
                cp.append(borders)
                fill = OxmlElement("w:shd")
                fill.set(qn("w:fill"), "E8E8E8" if ir == 0 else "FFFFFF")
                cp.append(fill)
                margins = OxmlElement("w:tcMar")
                for edge in ["top", "bottom", "left", "right"]:
                    el = OxmlElement("w:" + edge)
                    el.set(qn("w:w"), "70")
                    el.set(qn("w:type"), "dxa")
                    margins.append(el)
                cp.append(margins)
                for par in cell.paragraphs:
                    par.paragraph_format.space_after = Pt(0)
                    par.paragraph_format.space_before = Pt(0)
                    par.paragraph_format.line_spacing = Pt(size + 4)
                    par.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
                    for run in par.runs:
                        run.font.size = Pt(size)
                        run.font.bold = ir == 0
        spacer = self.doc.add_paragraph()
        spacer.paragraph_format.line_spacing = Pt(2)
        spacer.paragraph_format.space_after = Pt(4)
        spacer.add_run().font.size = Pt(1)
        return t

    def save(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.doc.save(path)
