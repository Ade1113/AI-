"""Additional diagnostics and rematching; no source-paper curves are fitted."""
from pathlib import Path
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,sys,time
import numpy as np
from numba import njit
from model import *

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"results"


@njit(cache=True,nogil=True)
def rematch(q,seed,payoff,steps=40000,alpha=.15,delta=.95):
    np.random.seed(seed)
    m=q.shape[-1];ns=m*m
    pol=np.empty((2,ns),np.int64);mx=np.empty((2,ns))
    for i in range(2):
        for s in range(ns):
            pol[i,s]=np.argmax(q[i,s]);mx[i,s]=q[i,s,pol[i,s]]
    s=np.random.randint(ns)
    out=np.zeros(steps//100)
    for t in range(steps):
        a=pol[0,s];b=pol[1,s];nxt=a*m+b
        v0=payoff[nxt,0]+delta*mx[0,nxt]
        v1=payoff[nxt,1]+delta*mx[1,nxt]
        q[0,s,a]=(1-alpha)*q[0,s,a]+alpha*v0
        q[1,s,b]=(1-alpha)*q[1,s,b]+alpha*v1
        pol[0,s]=np.argmax(q[0,s]);pol[1,s]=np.argmax(q[1,s])
        mx[0,s]=q[0,s,pol[0,s]];mx[1,s]=q[1,s,pol[1,s]]
        out[t//100]+=(payoff[nxt,0]+payoff[nxt,1])/200
        s=nxt
    return out


def diagnostics_group(group):
    cfg=Config(**json.loads((group/"config.json").read_text())["config"])
    env=environment(cfg)
    files=sorted(group.glob("[0-9]*.json"))
    def one(f):
        dest=f.with_suffix(".diagnostic")
        if dest.exists():return
        old=json.loads(f.read_text())
        if not old["converged"]:return
        if group.name=="baseline":
            d=np.load(f.with_suffix(".npz"));pol,cyc=d["policy"],d["cycle"]
        else:
            q,pol,state,steps,ok,trace=train(old["seed"],env["payoff"],env["q0"],env["powers"],
                cfg.memory,cfg.alpha,cfg.beta,cfg.delta,cfg.stable_periods,cfg.max_steps,
                cfg.no_explore,cfg.init=="random",0,1000)
            assert steps==old["steps"],"Determinism failed"
            nxt,_=transition(pol,env["powers"],cfg.memory);cyc=cycle_from(nxt,state)
        dest.write_text(json.dumps(one_step_diagnostics(pol,cyc,env,cfg)))
    with ThreadPoolExecutor(max_workers=4) as ex:
        for f in ex.map(one,files):pass
    print("diagnostics",group.name,len(files),flush=True)


def baseline_extra():
    group=OUT/"baseline";c=Config();env=environment(c)
    files=sorted(group.glob("*.npz"))
    paths_small=[];paths5=[];reference_paths=[];reference_stats=[];basins=[];distances=[];table=[]
    qlist=[];example=None
    for ix,f in enumerate(files):
        d=np.load(f);pol=d["policy"];cyc=d["cycle"];qlist.append(d["q"])
        paths_small.append(impulse(pol,cyc,env,c,"one_tick")[0])
        paths5.append(impulse(pol,cyc,env,c,"nash5")[0])
        rp,rg,ric,rr,rl=impulse(pol,cyc,env,c,2)
        reference_paths.append(rp)
        reference_stats.append([rg,ric,rr])
        nxt,ja=transition(pol,env["powers"],1)
        reachable=0;dd=[]
        cycset=set(cyc.tolist())
        for st in range(225):
            seen=set();s=st;dist=0
            while s not in seen and s not in cycset:
                seen.add(s);s=int(nxt[s]);dist+=1
            if s in cycset:
                reachable+=1;dd.append(dist)
        basins.append(reachable);distances.extend(dd)
        # Deterministic illustrative selection, not chosen to mimic the source curve.
        if example is None and len(cyc)==1 and reachable==225 and pol[0,cyc[0]]==pol[1,cyc[0]]:
            example=ix
        if len(cyc)==1 and pol[0,cyc[0]]==pol[1,cyc[0]]:
            s=int(cyc[0]);pre=pol[:,s];pidx=int(pre[0])
            vl=evaluate_policy(env["mean_payoff"][ja],nxt,c.delta)
            for dev in range(pidx):
                state=dev*15+int(pre[1]);aa=pol[:,state]
                value=env["mean_payoff"][state,0]+.95*vl[state,0]
                gain=(value-vl[s,0])/vl[s,0]
                table.append([ix,pidx,dev,
                    env["prices"][1,aa[1]]/env["prices"][1,pre[1]]-1,
                    env["prices"][0,aa[0]]/env["prices"][0,dev]-1,gain,int(gain<=1e-10)])
    np.savez_compressed(OUT/"baseline_extra.npz",small=np.array(paths_small),five=np.array(paths5),
                        reference=np.array(reference_paths),reference_stats=np.array(reference_stats),
                        basins=basins,distances=distances,deviation_table=np.array(table),example=example)
    # Circular rematching with a seeded permutation; no self-pair is possible.
    rng=np.random.default_rng(20261020);perm=rng.permutation(len(files))
    partner=np.empty(len(files),int);partner[perm]=np.roll(perm,-1)
    def one(i):
        q=np.stack([qlist[i][0],qlist[partner[i]][1]])
        return rematch(q,60_000_000+i,env["mean_payoff"])
    with ThreadPoolExecutor(max_workers=6) as ex:
        curves=np.array(list(ex.map(one,range(len(files)))))
    np.savez_compressed(OUT/"rematch.npz",profit=curves,partner=partner)
    print("baseline extra + rematching",len(files),flush=True)


if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("--mode",choices=["baseline","grid"],default="baseline")
    args=p.parse_args()
    if args.mode=="baseline":
        diagnostics_group(OUT/"baseline");baseline_extra()
    else:
        for g in sorted(OUT.glob("grid_*")):
            if not g.is_dir():continue
            meta=json.loads((g/"config.json").read_text())
            if len(list(g.glob("[0-9]*.json")))==meta["sessions"]:
                diagnostics_group(g)
