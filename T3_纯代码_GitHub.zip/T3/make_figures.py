"""Paper-style plots from freshly simulated results, with machine-readable tables."""
from pathlib import Path
import json,csv,sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib import font_manager as fm
from model import *

ROOT=Path(__file__).resolve().parent;OUT=ROOT/"results";FIG=ROOT/"figures"
FIG.mkdir(exist_ok=True)
for font in ["/System/Library/Fonts/Supplemental/Arial.ttf",
             "/System/Library/Fonts/Supplemental/Times New Roman.ttf"]:
    if Path(font).exists():fm.fontManager.addfont(font)
plt.rcParams.update({
    "font.family":"Arial","font.size":11,"axes.labelsize":13,
    "axes.spines.top":False,"axes.spines.right":False,
    "axes.linewidth":.8,"xtick.direction":"out","ytick.direction":"out",
    "xtick.major.size":6,"ytick.major.size":6,"legend.fontsize":10,
    "legend.fancybox":False,"legend.edgecolor":"black","legend.framealpha":1,
    "savefig.facecolor":"white","svg.fonttype":"none","pdf.fonttype":42})
RED="#ed1c24";BLUE="#008dcc";GRAY="#777777"


def load_group(name):
    g=OUT/name
    rs=[]
    for f in sorted(g.glob("[0-9]*.json")):
        r=json.loads(f.read_text())
        if f.with_suffix(".diagnostic").exists():r.update(json.loads(f.with_suffix(".diagnostic").read_text()))
        rs.append(r)
    return rs


def mean_ci(rs,key):
    a=np.array([r[key] for r in rs if r.get("converged",True) and r.get(key) is not None],float)
    return (float(a.mean()),float(1.96*a.std(ddof=1)/np.sqrt(len(a)))) if len(a)>1 else (float(a[0]),0)


def save(fig,name):
    fig.savefig(FIG/(name+".png"),dpi=300,bbox_inches="tight",pad_inches=.09)
    fig.savefig(FIG/(name+".svg"),bbox_inches="tight",pad_inches=.09)
    plt.close(fig)


def caption(fig,text):
    fig.text(.5,.005,text,ha="center",va="bottom",fontfamily="Times New Roman",fontsize=12)


def ir_plot(path,name,label,nash,monopoly):
    fig,ax=plt.subplots(figsize=(7.9,4.55))
    fig.subplots_adjust(left=.12,right=.98,bottom=.22,top=.96)
    x=np.arange(16)
    ax.plot(x,path[:16,0],color=RED,marker="s",ms=4.8,lw=1.7,
            dashes=(9,5),label="Deviating agent",zorder=3)
    ax.plot(x,path[:16,1:].mean(axis=1),color=BLUE,marker="^",ms=6,lw=1.7,
            dashes=(9,5),label="Nondeviating agent",zorder=4)
    ax.axhline(nash,color=GRAY,ls=(0,(1,2.5)),lw=1.6,label="Nash price")
    ax.axhline(monopoly,color=GRAY,ls=(0,(3,2,1,2)),lw=1.6,label="Monopoly price")
    ax.axhline(path[0].mean(),color="#666666",lw=1.7,label="Long-run price")
    ax.set(xlabel="Time",ylabel="Price",xticks=[0,1,5,10,15],xlim=(-.6,15.6))
    ax.set_ylim(min(nash-.018,path[:16].min()-.03),monopoly+.025)
    ax.legend(loc="lower right",bbox_to_anchor=(.91,.07),borderpad=.7,handlelength=2.5)
    caption(fig,label)
    save(fig,name)


def heatmap(grid,title,name,label,vmin=None,vmax=None,cmap="viridis"):
    fig,ax=plt.subplots(figsize=(7.0,4.8));fig.subplots_adjust(bottom=.20,left=.13,right=.88)
    im=ax.imshow(grid,origin="lower",aspect="auto",interpolation="nearest",
                 extent=(.02,2,.025,.25),vmin=vmin,vmax=vmax,cmap=cmap)
    ax.set(xlabel=r"$\beta \times 10^5$",ylabel=r"$\alpha$",xticks=[.02,.5,1,1.5,2],
           yticks=[.025,.05,.1,.15,.2,.25])
    fig.colorbar(im,ax=ax,label=title,pad=.04)
    caption(fig,label)
    save(fig,name)


def write_csv(name,rows,fieldnames=None):
    if not rows:return
    if fieldnames is None:fieldnames=list(rows[0])
    with (OUT/name).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fieldnames,extrasaction="ignore");w.writeheader();w.writerows(rows)


def main():
    base=load_group("baseline");cfg=Config();env=environment(cfg)
    paths=np.array([np.load(f)["path"] for f in sorted((OUT/"baseline").glob("*.npz"))])
    extra=np.load(OUT/"baseline_extra.npz")
    summary={"baseline":{},"groups":{}}
    for key in ["gain","price","steps","equilibrium","q_loss_on","q_loss_all","value_loss",
                "one_step_equilibrium","one_step_q_loss_on","one_step_q_loss_all",
                "deviation_gain","ic","punishment_ratio","punishment_length"]:
        mu,ci=mean_ci(base,key);summary["baseline"][key]={"mean":mu,"ci95_halfwidth":ci}
    summary["baseline"].update(n=len(base),converged=sum(r["converged"] for r in base),
                              all_basin_fraction=float(np.mean(extra["basins"]==225)),
                              mean_basin=float(np.mean(extra["basins"])),
                              mean_return_distance=float(extra["distances"].mean()),
                              graph_session=int(extra["example"]))
    summary["benchmarks"]={k:env[k].tolist() for k in ["pn","pm","pi_n","pi_m","prices"]}
    write_csv("baseline_sessions.csv",base)
    reference=extra["reference"]
    write_csv("figure4_data.csv",[{"time":i,"deviating":reference[:,i,0].mean(),
              "nondeviating":reference[:,i,1].mean(),
              "deviating_se":reference[:,i,0].std(ddof=1)/np.sqrt(len(paths)),
              "nondeviating_se":reference[:,i,1].std(ddof=1)/np.sqrt(len(paths)),
              "literal_best_response_deviator":paths[:,i,0].mean(),
              "literal_best_response_other":paths[:,i,1].mean()} for i in range(41)])
    ir_plot(reference.mean(axis=0),"figure04","Figure 4",env["pn"].mean(),env["pm"].mean())
    ir_plot(paths.mean(axis=0),"figure04_literal","Figure 4 alternative",env["pn"].mean(),env["pm"].mean())
    summary["figure4_reference"]={"shock_price":float(env["prices"][0,2]),
        "deviation_gain":float(extra["reference_stats"][:,0].mean()),
        "ic":float(extra["reference_stats"][:,1].mean()),"punishment_ratio":float(extra["reference_stats"][:,2].mean()),
        "time2_deviator":float(reference[:,2,0].mean()),"time2_other":float(reference[:,2,1].mean())}
    ir_plot(extra["small"].mean(axis=0),"figure06","Figure 6",env["pn"].mean(),env["pm"].mean())
    ir_plot(extra["five"].mean(axis=0),"figureA08","Figure A8",env["pn"].mean(),env["pm"].mean())

    # Figure 5: constant-price sessions only; means, IQR, and min/max.
    const=np.array([r["cycle_length"]==1 for r in base])
    fig,axs=plt.subplots(1,2,figsize=(9,3.9),sharey=True)
    fig.subplots_adjust(left=.09,right=.98,bottom=.23,top=.88,wspace=.13)
    for i,ax in enumerate(axs):
        x=np.arange(11);a=paths[const,:11,i]-paths[const,0,i,None]
        lo,q1,q3,hi=np.percentile(a,[0,25,75,100],axis=0)
        ax.vlines(x,lo,hi,color=GRAY,ls="--",lw=.8)
        ax.bar(x,q3-q1,bottom=q1,width=.5,color="#c6c6c6",edgecolor="black",lw=.6)
        ax.plot(x,a.mean(axis=0),color="black",lw=1.3)
        ax.axhline(0,color=GRAY,lw=.7);ax.set(xlabel="Time",xticks=range(0,11,2),ylim=(-.57,.30))
        ax.set_title(["Deviating agent","Nondeviating agent"][i],fontsize=12)
    axs[0].set_ylabel("Price change")
    caption(fig,"Figure 5");save(fig,"figure05")

    # Grid diagnostics. Missing cells cannot be silently interpolated.
    grid_names=sorted(g.name for g in OUT.glob("grid_*") if g.is_dir())
    ngrid=int(np.sqrt(len(grid_names)))
    grids={k:np.full((ngrid,ngrid),np.nan) for k in ["gain","equilibrium","one_step_equilibrium","punishment_ratio"]}
    rows=[]
    for name in grid_names:
        meta=json.loads((OUT/name/"config.json").read_text());rs=load_group(name)
        assert len(rs)==meta["sessions"],name+" incomplete"
        assert all("one_step_equilibrium" in r for r in rs),name+" diagnostics incomplete"
        ia=int(name.split("_")[1][1:]);ib=int(name.split("_")[2][1:])
        row={"alpha":meta["config"]["alpha"],"beta":meta["config"]["beta"],"n":len(rs)}
        for k in grids:
            if k in rs[0]:
                grids[k][ia,ib]=mean_ci(rs,k)[0];row[k]=grids[k][ia,ib]
        rows.append(row)
    if rows:
        heatmap(grids["gain"],r"Profit gain $\Delta$","figure01","Figure 1",.65,.95)
        heatmap(grids["one_step_equilibrium"],"One-period deviation stability","figure02","Figure 2",0,1)
        heatmap(grids["punishment_ratio"],r"Price ratio $p_{2,2}/p_{2,0}$","figure07","Figure 7",.8,1)
        heatmap(grids["equilibrium"],"Dynamic best-response equilibrium","figure02_audit","Figure 2 supplement",0,1)
        write_csv("grid_summary.csv",rows)
        summary["grid"]={"cells":len(rows),"sessions":sum(r["n"] for r in rows),
                         "gain_min":float(np.nanmin(grids["gain"])),"gain_max":float(np.nanmax(grids["gain"]))}

    # Discount sweep.
    ds=[]
    for group in sorted(g for g in OUT.glob("discount_*") if g.is_dir() and (g/"config.json").exists()):
        rs=load_group(group.name);mu,ci=mean_ci(rs,"gain")
        ds.append(dict(delta=float(group.name.split("_")[1]),gain=mu,ci=ci,n=len(rs)))
    fig,ax=plt.subplots(figsize=(7.4,4.4));fig.subplots_adjust(left=.13,bottom=.23,top=.96)
    if ds:
        x=np.array([r["delta"] for r in ds]);y=np.array([r["gain"] for r in ds]);ci=np.array([r["ci"] for r in ds])
        ax.plot(x,y,color=RED,lw=1.5,marker="s",ms=4);ax.fill_between(x,y-ci,y+ci,color=RED,alpha=.12,lw=0)
    ax.set(xlabel=r"$\delta$",ylabel=r"$\Delta$",xlim=(0,1),ylim=(0,1))
    caption(fig,"Figure 3");save(fig,"figure03")
    write_csv("discount_summary.csv",ds)

    # Figures 8 and 9: one seeded example with a full basin.
    idx=int(extra["example"]);d=np.load(OUT/"baseline"/f"{idx:04}.npz")
    pol=d["policy"];cyc=d["cycle"];nxt,ja=transition(pol,env["powers"],1)
    import networkx as nx
    g=nx.DiGraph();g.add_nodes_from(range(225));g.add_edges_from(enumerate(nxt.tolist()))
    central=nx.betweenness_centrality(g);sizes=np.array([16+900*central[j] for j in range(225)])
    profits=(env["mean_payoff"].mean(axis=1)-env["pi_n"].mean())/(env["pi_m"].mean()-env["pi_n"].mean())
    pos=nx.spring_layout(g,seed=20261020,iterations=150,k=.20)
    fig,ax=plt.subplots(figsize=(7.4,5.5));fig.subplots_adjust(bottom=.12,top=.97)
    nx.draw_networkx_edges(g,pos,ax=ax,arrows=True,arrowstyle="-|>",arrowsize=5,width=.45,edge_color="#777777")
    nx.draw_networkx_nodes(g,pos,ax=ax,node_size=sizes,node_color=profits,cmap="Greys",vmin=-.1,vmax=1,edgecolors="black",linewidths=.3)
    nx.draw_networkx_nodes(g,pos,ax=ax,nodelist=cyc.tolist(),node_shape="s",node_size=90,node_color="black")
    ax.set_axis_off();caption(fig,"Figure 8");save(fig,"figure08")
    aa=env["actions"];xy=env["prices"][np.arange(2)[None,:],aa]
    to=env["prices"][np.arange(2)[None,:],pol.T]
    delta=to-xy;norm=np.linalg.norm(delta,axis=1);v=delta/(norm[:,None]+1e-12)*.026
    fig,ax=plt.subplots(figsize=(6.6,5.7));fig.subplots_adjust(left=.14,bottom=.20,top=.97,right=.97)
    ax.quiver(xy[:,0],xy[:,1],v[:,0],v[:,1],angles="xy",scale_units="xy",scale=1,color="#888888",width=.0025)
    ax.scatter(xy[:,0],xy[:,1],s=sizes*.5,c=profits,cmap="Greys",vmin=-.1,vmax=1,edgecolors="black",linewidths=.25)
    ax.scatter(xy[cyc,0],xy[cyc,1],s=85,c="black",marker="s")
    ax.set(xlabel="Price of agent 1",ylabel="Price of agent 2",xlim=(1.4,2),ylim=(1.4,2),aspect="equal")
    caption(fig,"Figure 9");save(fig,"figure09")

    # Figure 10: original 100-period moving average sampled every 1000 periods.
    traces=np.array([np.load(f)["trace"] for f in sorted((OUT/"baseline").glob("*.npz"))])
    gain_trace=(traces-env["pi_n"].mean())/(env["pi_m"].mean()-env["pi_n"].mean())
    t=np.arange(1,1501)*1000
    benchmark=[]
    for ti in t:
        eps=np.exp(-cfg.beta*ti);prob=np.full(15,eps/15);prob[1]+=1-eps
        pi=np.sum(prob[:,None]*prob[None,:]*env["mean_payoff"].mean(axis=1).reshape(15,15))
        benchmark.append((pi-env["pi_n"].mean())/(env["pi_m"].mean()-env["pi_n"].mean()))
    fig,ax=plt.subplots(figsize=(7.6,4.3));fig.subplots_adjust(left=.12,bottom=.22,top=.95,right=.97)
    ax.plot(t,gain_trace.mean(axis=0),color=RED,lw=1.4,label="Q-learning")
    ax.plot(t,benchmark,color=BLUE,ls="--",lw=1.3,label="Exploration benchmark")
    ax.set(xlabel="Time",ylabel=r"$\Delta$",xlim=(0,1500000),ylim=(0,1),xticks=[0,500000,1000000,1500000])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{int(v):,}"))
    ax.legend(loc="lower right")
    caption(fig,"Figure 10");save(fig,"figure10")
    write_csv("learning_trace.csv",[dict(time=int(tt),gain=float(gg),exploration_benchmark=float(bb)) for tt,gg,bb in zip(t,gain_trace.mean(axis=0),benchmark)])
    summary["baseline"]["fraction_stopped_by_1_5m"]=float(np.mean([r["steps"]<=1500000 for r in base]))

    rem=np.load(OUT/"rematch.npz")
    rg=(rem["profit"]-env["pi_n"].mean())/(env["pi_m"].mean()-env["pi_n"].mean())
    fig,ax=plt.subplots(figsize=(7.6,4.3));fig.subplots_adjust(left=.12,bottom=.22,top=.95,right=.97)
    ax.plot(np.arange(1,401)*100,rg.mean(axis=0),color=RED,lw=1.4)
    ax.set(xlabel="Time",ylabel=r"$\Delta$",xlim=(0,40000),ylim=(0,1),xticks=[0,10000,20000,30000,40000])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{int(v):,}"))
    caption(fig,"Figure 11");save(fig,"figure11")
    summary["rematch"]={"first100":float(rg[:,0].mean()),"last100":float(rg[:,-1].mean())}
    write_csv("rematch_trace.csv",[dict(time=int(t),gain=float(v)) for t,v in zip(np.arange(1,401)*100,rg.mean(axis=0))])

    # All robustness results including convergence denominator.
    groups=[]
    for g in sorted(OUT.iterdir()):
        if not g.is_dir() or not (g/"config.json").exists():continue
        rs=load_group(g.name)
        if not rs:continue
        meta=json.loads((g/"config.json").read_text())
        rec=dict(name=g.name,n=len(rs),planned=meta["sessions"],converged=sum(r["converged"] for r in rs))
        for key in ["gain","price","steps","ic","punishment_ratio"]:
            mu,ci=mean_ci(rs,key);rec[key]=mu;rec[key+"_ci"]=ci
        summary["groups"][g.name]=rec
        if not g.name.startswith(("grid_","discount_")):groups.append(rec)
    write_csv("robustness_summary.csv",groups)
    asym=[]
    for name in ["baseline","cost_0.875","cost_0.75","cost_0.625","cost_0.5","cost_0.25",
                 "quality_2.125","quality_2.25","quality_2.375","quality_2.5","quality_2.75"]:
        cfg_a=Config(**json.loads((OUT/name/"config.json").read_text())["config"])
        ea=environment(cfg_a);rs=load_group(name)
        qn=demand(ea["pn"],ea["a"],cfg_a.mu)
        ratios=[(r["profits"][0]/ea["pi_n"][0])/(r["profits"][1]/ea["pi_n"][1]) for r in rs]
        asym.append(dict(name=name,c2=cfg_a.c2,a2=cfg_a.a2,
                         nash_share2=float(qn[1]/qn.sum()),gain=mean_ci(rs,"gain")[0],
                         profit_ratio=float(np.mean(ratios))))
    summary["asymmetry"]=asym;write_csv("table4_asymmetry.csv",asym)
    # Selected robustness panels; all values in CSV and report.
    fig,axs=plt.subplots(2,2,figsize=(9,6.5));fig.subplots_adjust(left=.09,right=.98,bottom=.14,top=.96,hspace=.45,wspace=.3)
    panels=[("cost_",lambda v:float(v),r"$c_2$"),("shock_",lambda v:float(v),r"$a_0^H$"),
            ("mu_",lambda v:float(v),r"$\mu$"),("players_",lambda v:float(v),"Number of firms")]
    for ax,(prefix,parse,xlab) in zip(axs.flat,panels):
        pairs=[(parse(k[len(prefix):]),v) for k,v in summary["groups"].items() if k.startswith(prefix)]
        default={"cost_":1.,"shock_":0.,"mu_":.25,"players_":2.}[prefix]
        pairs.append((default,summary["groups"]["baseline"]));pairs.sort(key=lambda z:z[0])
        ax.errorbar([p[0] for p in pairs],[p[1]["gain"] for p in pairs],
                    yerr=[p[1]["gain_ci"] for p in pairs],color=RED,marker="s",ms=4,lw=1.2,capsize=2)
        ax.set(xlabel=xlab,ylabel=r"$\Delta$",ylim=(.4,1))
    caption(fig,"Robustness checks");save(fig,"robustness")
    mus=np.array([.01,.05,.1,.15,.2,.25,.3,.35,.4,.45,.5])
    original=np.array([.805,.827,.829,.835,.839,.849,.859,.853,.859,.860,.856])
    vals=[summary["groups"]["baseline"] if x==.25 else summary["groups"][f"mu_{x}"] for x in mus]
    fig,ax=plt.subplots(figsize=(7.5,4.1));fig.subplots_adjust(left=.12,bottom=.18,top=.95,right=.97)
    ax.errorbar(mus,[v["gain"] for v in vals],yerr=[v["gain_ci"] for v in vals],
                color=RED,marker="s",lw=1.4,ms=4,capsize=2,label="Python replication")
    ax.plot(mus,original,color=BLUE,marker="^",ls="--",lw=1.2,ms=5,label="Paper Table A10")
    ax.set(xlabel=r"$\mu$",ylabel=r"$\Delta$",ylim=(.7,.95));ax.legend(loc="lower right")
    save(fig,"product_differentiation")
    # Original Table 1 categories, from baseline only.
    categories={"1-Sym.":[r for r in base if r["cycle_length"]==1 and r["symmetric"]],
                "1-Asym.":[r for r in base if r["cycle_length"]==1 and not r["symmetric"]],
                "1":[r for r in base if r["cycle_length"]==1],
                "2":[r for r in base if r["cycle_length"]==2],
                ">=3":[r for r in base if r["cycle_length"]>=3],"All":base}
    t1=[]
    for name,rs in categories.items():
        t1.append(dict(category=name,n=len(rs),frequency=len(rs)/len(base),
                      gain=mean_ci(rs,"gain")[0],gain_sd=float(np.std([r["gain"] for r in rs],ddof=1)),
                      one_step_stability=mean_ci(rs,"one_step_equilibrium")[0],
                      one_step_q_loss_on=mean_ci(rs,"one_step_q_loss_on")[0],
                      one_step_q_loss_all=mean_ci(rs,"one_step_q_loss_all")[0]))
    write_csv("table1_replication.csv",t1);summary["table1"]=t1
    dev=extra["deviation_table"]
    t23=[]
    sym_count=len(set(dev[:,0]))
    for pidx in sorted(set(dev[:,1].astype(int))):
        rowset=dev[dev[:,1]==pidx]
        for didx in sorted(set(rowset[:,2].astype(int))):
            ss=rowset[rowset[:,2]==didx]
            t23.append(dict(pre_price=float(env["prices"][0,pidx]),deviation_price=float(env["prices"][0,didx]),
                            n=len(ss),frequency=len(ss)/sym_count,nondeviator_price_change=float(ss[:,3].mean()),
                            deviator_price_change=float(ss[:,4].mean()),discounted_gain=float(ss[:,5].mean()),
                            unprofitable_fraction=float(ss[:,6].mean())))
    write_csv("tables2_3_replication.csv",t23)
    summary["totals"]={"sessions":sum(r["n"] for r in summary["groups"].values()),
                       "converged":sum(r["converged"] for r in summary["groups"].values()),
                       "training_periods":int(sum(r["steps"]*r["n"] for r in summary["groups"].values()))}
    (OUT/"summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:summary[k] for k in ["baseline","grid","rematch","totals"]},indent=2))

if __name__=="__main__":main()
