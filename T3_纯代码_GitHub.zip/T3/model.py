"""Independent Python implementation of Calvano et al. (AER 2020).

All learning code is Python, accelerated with Numba. No fitted/digitized data
are used for simulation. State encoding: latest joint action is least significant.
"""
from dataclasses import dataclass, asdict
from functools import lru_cache
import numpy as np
from scipy.optimize import root, minimize
from numba import njit


@dataclass(frozen=True)
class Config:
    n: int = 2
    m: int = 15
    memory: int = 1
    alpha: float = .15
    beta: float = 4e-6
    delta: float = .95
    mu: float = .25
    xi: float = .1
    c2: float = 1.
    a2: float = 2.
    shock: float = 0.
    shock_benchmark: str = "expected"
    init: str = "uniform_opponent"
    no_explore: bool = False
    low_price: float = 0.
    stable_periods: int = 100_000
    max_steps: int = 1_000_000_000


def demand(p, a, mu, a0=0.):
    u = np.r_[(a - p) / mu, a0 / mu]
    e = np.exp(u - u.max())
    return e[:-1] / e.sum()


@lru_cache(maxsize=256)
def environment(cfg):
    n, m = cfg.n, cfg.m
    a, c = np.full(n, 2.), np.ones(n)
    a[1], c[1] = cfg.a2, cfg.c2
    shocks = np.array([-cfg.shock, 0., cfg.shock]) if cfg.shock else np.array([0.])
    def profits(p):
        return np.mean([(p-c)*demand(p,a,cfg.mu,z) for z in shocks], axis=0)
    def foc_n(p):
        return np.mean([demand(p,a,cfg.mu,z) *
                        (1-(p-c)*(1-demand(p,a,cfg.mu,z))/cfg.mu)
                        for z in shocks], axis=0)
    sol = root(foc_n, c + .5)
    if not sol.success or np.max(np.abs(foc_n(sol.x))) > 1e-8:
        sol = root(foc_n, c + cfg.mu * n/(n-1))
    if not sol.success or np.max(np.abs(foc_n(sol.x))) > 1e-8:
        raise RuntimeError("Nash benchmark did not converge")
    pn = sol.x
    res = minimize(lambda p: -profits(p).sum(), c + .95,
                   method="BFGS", options={"gtol":1e-10})
    pm = res.x
    # Per-firm price grids, equation (6) / action-space definition in section II.B.
    prices = np.array([np.linspace(pn[i]-cfg.xi*(pm[i]-pn[i]),
                                   pm[i]+cfg.xi*(pm[i]-pn[i]), m) for i in range(n)])
    if cfg.low_price:
        prices = np.array([np.linspace(cfg.low_price, prices[i,-1], m) for i in range(n)])
    joint = m**n
    actions = np.array(np.unravel_index(np.arange(joint),(m,)*n)).T.copy()
    powers = m**np.arange(n-1,-1,-1)
    price_profiles = prices[np.arange(n)[None,:], actions]
    payoff = np.empty((len(shocks), joint, n))
    for iz,z in enumerate(shocks):
        utilities = (a[None,:]-price_profiles)/cfg.mu
        e = np.exp(utilities)
        payoff[iz] = (price_profiles-c)*e/(e.sum(axis=1)[:,None]+np.exp(z/cfg.mu))
    mean_payoff = payoff.mean(axis=0)
    q0 = np.empty((n,m))
    for i in range(n):
        for ai in range(m):
            q0[i,ai] = mean_payoff[actions[:,i]==ai,i].mean()/(1-cfg.delta)
    if cfg.init=="nash":
        na = np.argmin(abs(prices-pn[:,None]),axis=1)
        for i in range(n):
            for ai in range(m):
                aa=na.copy(); aa[i]=ai
                q0[i,ai]=mean_payoff[int(aa@powers),i]/(1-cfg.delta)
    elif cfg.init in ("constant5","constant10"):
        q0[:]=5. if cfg.init=="constant5" else 10.
    if cfg.shock and cfg.shock_benchmark=="baseline":
        from dataclasses import replace
        be=environment(replace(cfg,shock=0.,shock_benchmark="expected"))
        prices=be["prices"].copy()
        price_profiles=prices[np.arange(n)[None,:],actions]
        for iz,z in enumerate(shocks):
            e=np.exp((a[None,:]-price_profiles)/cfg.mu)
            payoff[iz]=(price_profiles-c)*e/(e.sum(axis=1)[:,None]+np.exp(z/cfg.mu))
        return dict(prices=prices,payoff=payoff,mean_payoff=payoff.mean(axis=0),
                    actions=actions,powers=powers,q0=be["q0"].copy(),
                    pn=be["pn"].copy(),pm=be["pm"].copy(),
                    pi_n=be["pi_n"].copy(),pi_m=be["pi_m"].copy(),a=a,c=c)
    return dict(prices=prices, payoff=payoff, mean_payoff=mean_payoff,
                actions=actions, powers=powers, q0=q0, pn=pn,pm=pm,
                pi_n=profits(pn),pi_m=profits(pm),a=a,c=c)


@njit(cache=True, nogil=True)
def train(seed, payoff, q0, powers, memory, alpha, beta, delta,
          stable_periods, max_steps, no_explore, random_init,
          trace_end=1_500_000, trace_stride=1000):
    np.random.seed(seed)
    n,m=q0.shape
    joint=payoff.shape[1]
    ns=joint**memory
    q=np.empty((n,ns,m))
    greedy=np.empty((n,ns),np.int64)
    maxima=np.empty((n,ns))
    for i in range(n):
        for s in range(ns):
            for a in range(m):
                q[i,s,a]=10*np.random.random() if random_init else q0[i,a]
            ga=np.argmax(q[i,s])
            greedy[i,s]=ga
            maxima[i,s]=q[i,s,ga]
    state=np.random.randint(ns)
    stable=0
    actions=np.empty(n,np.int64)
    targets=np.empty(n)
    trace=np.full(trace_end//trace_stride,np.nan)
    trace_sum=0.
    converged=False
    for t in range(max_steps):
        eps=0. if no_explore else np.exp(-beta*t)
        ja=0
        for i in range(n):
            actions[i]=np.random.randint(m) if np.random.random()<eps else greedy[i,state]
            ja+=actions[i]*powers[i]
        nxt=0 if memory==0 else (state*joint+ja)%ns
        z=np.random.randint(payoff.shape[0]) if payoff.shape[0]>1 else 0
        # Cache every target before changing either player's table (simultaneous update).
        for i in range(n):
            targets[i]=payoff[z,ja,i]+delta*maxima[i,nxt]
        changed=False
        for i in range(n):
            aa=actions[i]
            q[i,state,aa]=(1-alpha)*q[i,state,aa]+alpha*targets[i]
            old=greedy[i,state]
            # Only the current state can change; this is equivalent to comparing all states.
            ga=np.argmax(q[i,state])
            greedy[i,state]=ga
            maxima[i,state]=q[i,state,ga]
            if old!=ga: changed=True
        stable=0 if changed else stable+1
        if t<trace_end and t%trace_stride >= trace_stride-100:
            trace_sum+=np.mean(payoff[z,ja])
        if t<trace_end and (t+1)%trace_stride==0:
            trace[t//trace_stride]=trace_sum/100.
            trace_sum=0.
        state=nxt
        if stable>=stable_periods:
            converged=True
            break
    return q,greedy,state,t+1,converged,trace


@njit(cache=True, nogil=True)
def transition(policy,powers,memory):
    ns=policy.shape[1]
    m=powers[-2]
    joint=m**policy.shape[0]
    out=np.empty(ns,np.int64)
    action=np.empty(ns,np.int64)
    for s in range(ns):
        ja=0
        for i in range(policy.shape[0]): ja+=policy[i,s]*powers[i]
        action[s]=ja
        out[s]=0 if memory==0 else (s*joint+ja)%ns
    return out,action


def cycle_from(next_state, start):
    seen={}
    walk=[]
    s=int(start)
    while s not in seen:
        seen[s]=len(walk); walk.append(s); s=int(next_state[s])
    return np.array(walk[seen[s]:],dtype=np.int64)


@njit(cache=True, nogil=True)
def evaluate_policy(reward, nxt, delta, tol=1e-11):
    value=np.zeros(reward.shape)
    for _ in range(10000):
        vnew=reward+delta*value[nxt]
        if np.max(np.abs(vnew-value))<tol:
            return vnew
        value=vnew
    return value


@njit(cache=True, nogil=True)
def best_response(policy, i, payoff, powers, memory, delta, tol=1e-10):
    ns=policy.shape[1]; m=powers[-2]; joint=m**policy.shape[0]
    rr=np.empty((ns,m)); nn=np.empty((ns,m),np.int64)
    for s in range(ns):
        other=0
        for j in range(policy.shape[0]):
            if j!=i: other+=policy[j,s]*powers[j]
        for a in range(m):
            ja=other+a*powers[i]
            rr[s,a]=payoff[ja,i]
            nn[s,a]=0 if memory==0 else (s*joint+ja)%ns
    v=np.zeros(ns)
    qstar=rr.copy()
    for _ in range(10000):
        vn=np.empty(ns)
        for s in range(ns):
            best=-1e100
            for a in range(m):
                qstar[s,a]=rr[s,a]+delta*v[nn[s,a]]
                if qstar[s,a]>best: best=qstar[s,a]
            vn[s]=best
        diff=np.max(np.abs(vn-v))
        v=vn
        if diff<tol: break
    return v,qstar


def one_step_diagnostics(policy,cycle,env,cfg):
    """One-period deviation followed by return to learned strategy.

    Kept separate from unrestricted dynamic best response. Numerical agreement
    with paper Table 1 does not prove identity with unavailable original code.
    """
    nxt,ja=transition(policy,env["powers"],cfg.memory)
    vl=evaluate_policy(env["mean_payoff"][ja],nxt,cfg.delta)
    ns=policy.shape[1]
    all_gap=[]; on_gap=[]; eq=True
    for i in range(cfg.n):
        others=ja[:,None]-policy[i,:,None]*env["powers"][i]
        acts=others+np.arange(cfg.m)[None,:]*env["powers"][i]
        ns2=np.zeros_like(acts) if cfg.memory==0 else (np.arange(ns)[:,None]*cfg.m**cfg.n+acts)%ns
        q=env["mean_payoff"][acts,i]+cfg.delta*vl[ns2,i]
        mx=q.max(axis=1)
        gap=np.maximum(0.,mx-vl[:,i])/np.maximum(abs(mx),1e-12)
        eq=eq and bool(gap[cycle].max()<1e-8)
        all_gap.append(gap.mean());on_gap.append(gap[cycle].mean())
    return dict(one_step_equilibrium=eq,one_step_q_loss_on=float(np.mean(on_gap)),
                one_step_q_loss_all=float(np.mean(all_gap)))


def impulse(policy,cycle,env,cfg,kind="best",horizon=40):
    """Average cycle phases within session; equal session weights outside.

    Agent 0 is the designated deviator. At t=0 the on-path action is played.
    At t=1 agent 0 deviates against the rival's PREDEVIATION price, as specified
    in paper footnote 30. The other player follows its policy even on a cycle.
    """
    prices,powers,profits=env["prices"],env["powers"],env["mean_payoff"]
    nxt,ja=transition(policy,powers,cfg.memory)
    vals=evaluate_policy(profits[ja],nxt,cfg.delta)
    path=np.zeros((horizon+1,cfg.n))
    gains=[]; ratios=[]; lengths=[]
    for st in cycle:
        state=int(st)
        pre=policy[:,state].copy()
        path[0]+=prices[np.arange(cfg.n),pre]
        state=int(nxt[state])
        aa=policy[:,state].copy()
        other=int(aa@powers-aa[0]*powers[0])
        if kind=="best":
            previous_other=int(pre@powers-pre[0]*powers[0])
            dev=int(np.argmax(profits[previous_other+np.arange(cfg.m)*powers[0],0]))
        elif kind=="one_tick":
            dev=max(0,int(aa[0])-1)
        elif kind=="nash5":
            dev=int(np.argmin(abs(prices[0]-env["pn"][0])))
        else:
            dev=int(kind)
        aa[0]=dev
        dev_joint=int(aa@powers)
        dev_state=0 if cfg.memory==0 else (state*cfg.m**cfg.n+dev_joint)%policy.shape[1]
        vdev=profits[dev_joint,0]+cfg.delta*vals[dev_state,0]
        gains.append((vdev-vals[state,0])/vals[state,0])
        path[1]+=prices[np.arange(cfg.n),aa]
        state=dev_state
        length=-1
        for t in range(2,horizon+1):
            aa=policy[:,state].copy()
            if kind=="nash5" and t<=5: aa[0]=dev
            path[t]+=prices[np.arange(cfg.n),aa]
            if t==2:
                ratios.append(np.mean(prices[np.arange(1,cfg.n),aa[1:]]/
                                      prices[np.arange(1,cfg.n),pre[1:]]))
            if length<0 and state in cycle: length=t-1
            state=0 if cfg.memory==0 else (state*cfg.m**cfg.n+int(aa@powers))%policy.shape[1]
        lengths.append(length)
    return path/len(cycle),np.mean(gains),np.mean(np.array(gains)<=1e-10),np.mean(ratios),lengths


def analyze(policy,state,env,cfg,full=True):
    nxt,ja=transition(policy,env["powers"],cfg.memory)
    cyc=cycle_from(nxt,state)
    rewards=env["mean_payoff"][ja[cyc]]
    pi=rewards.mean(axis=0)
    gain=(pi.mean()-env["pi_n"].mean())/(env["pi_m"].mean()-env["pi_n"].mean())
    p=env["prices"][np.arange(cfg.n)[:,None],policy[:,cyc]].mean(axis=1)
    out=dict(cycle_length=len(cyc),symmetric=bool(np.all(policy[:,cyc]==policy[0,cyc])),
             gain=float(gain),price=float(p.mean()),prices=p.tolist(),profits=pi.tolist())
    if full and cfg.memory==1 and cfg.n==2 and cfg.m<=15:
        vl=evaluate_policy(env["mean_payoff"][ja],nxt,cfg.delta)
        onloss=[]; allloss=[]; fullgap=[]; eq=True
        for i in range(cfg.n):
            v,qstar=best_response(policy,i,env["mean_payoff"],env["powers"],cfg.memory,cfg.delta)
            gap=(v-qstar[np.arange(len(v)),policy[i]])/np.maximum(abs(v),1e-12)
            onloss.append(gap[cyc].mean()); allloss.append(gap.mean())
            fullgap.append(((v[cyc]-vl[cyc,i])/v[cyc]).mean())
            eq=eq and bool(np.max(gap[cyc])<1e-8)
        out.update(equilibrium=eq,q_loss_on=float(np.mean(onloss)),
                   q_loss_all=float(np.mean(allloss)),value_loss=float(np.mean(fullgap)))
    path,gain_dev,ic,ratio,lengths=impulse(policy,cyc,env,cfg)
    out.update(deviation_gain=float(gain_dev),ic=float(ic),punishment_ratio=float(ratio),
               punishment_length=float(np.mean([v for v in lengths if v>=0])) if any(v>=0 for v in lengths) else None)
    return out,cyc,path


def run_session(seed,cfg,full=True,save_q=False):
    env=environment(cfg)
    q,policy,state,steps,converged,trace=train(
        seed,env["payoff"],env["q0"],env["powers"],cfg.memory,cfg.alpha,cfg.beta,
        cfg.delta,cfg.stable_periods,cfg.max_steps,cfg.no_explore,cfg.init=="random")
    out,cyc,path=analyze(policy,state,env,cfg,full=full)
    out.update(seed=int(seed),steps=int(steps),converged=bool(converged))
    # After stopping, deterministic long-run expected profit fills remaining trace.
    # This is explicitly recorded as frozen continuation, not extra learning.
    trace=np.where(np.isnan(trace),np.mean(out["profits"]),trace)
    return out,policy,cyc,path,trace,q if save_q else None
