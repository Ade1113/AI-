"""Build the Chinese review document from saved numerical results."""
from pathlib import Path
import json,csv
import numpy as np
from docx import Document
from docx.shared import Inches,Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
R=ROOT/"results";F=ROOT/"figures"
S=json.loads((R/"summary.json").read_text());B=S["baseline"];G=S["groups"]
D=Document()
sec=D.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7)
sec.top_margin=Cm(1.9);sec.bottom_margin=Cm(1.9);sec.left_margin=Cm(2);sec.right_margin=Cm(2)
for el in list(sec._sectPr.findall(qn("w:docGrid"))):sec._sectPr.remove(el)

for name in ["Normal","Title","Subtitle","Heading 1","Heading 2","Caption"]:
    st=D.styles[name];st.font.name="Times New Roman";st.font.color.rgb=RGBColor(0,0,0)
    st.element.rPr.rFonts.set(qn("w:eastAsia"),"Noto Sans CJK SC")
    st.element.rPr.rFonts.set(qn("w:ascii"),"Times New Roman")
    st.element.rPr.rFonts.set(qn("w:hAnsi"),"Times New Roman")
    for attr in list(st.element.rPr.rFonts.attrib):
        if "theme" in attr.lower():del st.element.rPr.rFonts.attrib[attr]
    if st.element.pPr is not None:
        for bdr in list(st.element.pPr.findall(qn("w:pBdr"))):st.element.pPr.remove(bdr)
    snap=OxmlElement("w:snapToGrid");snap.set(qn("w:val"),"0");st.element.get_or_add_pPr().append(snap)
D.styles["Normal"].font.size=Pt(10.5)
D.styles["Normal"].paragraph_format.line_spacing=1.2
D.styles["Normal"].paragraph_format.space_after=Pt(6)
D.styles["Normal"].paragraph_format.first_line_indent=Pt(0)
D.styles["Normal"].paragraph_format.left_indent=Pt(0)
D.styles["Normal"].paragraph_format.right_indent=Pt(0)
D.styles["Title"].font.size=Pt(22)
D.styles["Heading 1"].font.size=Pt(15)
D.styles["Heading 2"].font.size=Pt(12)
for name in ["Heading 1","Heading 2"]:
    D.styles[name].paragraph_format.space_before=Pt(8)
    D.styles[name].paragraph_format.space_after=Pt(8)
D.styles["Caption"].font.size=Pt(9)
D.styles["Caption"].font.bold=False
D.styles["Caption"].font.italic=False
D.styles["Caption"].paragraph_format.space_after=Pt(7)
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run();fld=OxmlElement("w:fldSimple");fld.set(qn("w:instr"),"PAGE");r._r.addnext(fld)
D.core_properties.title="人工智能算法定价与合谋 Python 实验复现报告"
D.core_properties.subject="Calvano et al. 2020 实验结果与复现检阅"
D.core_properties.author="Python 复现实验"


def p(text,style=None):
    return D.add_paragraph(text,style=style)
def h(text):D.add_heading(text,1)
def page(title):
    par=D.add_heading(title,1);par.paragraph_format.page_break_before=True
def mean(key):return B[key]["mean"]
def fmt(x,d=3):return f"{x:.{d}f}"
def pct(x,d=1):return f"{100*x:.{d}f}%"
def ci(key):
    v=B[key];return f"{v['mean']:.4f} ± {v['ci95_halfwidth']:.4f}"
def pic(name,width=5.8,note=None):
    par=D.add_paragraph();par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    par.paragraph_format.space_after=Pt(2);par.paragraph_format.keep_with_next=bool(note)
    par.add_run().add_picture(str(F/(name+".png")),width=Inches(width))
    if note:p(note,"Caption")
def table(headers,rows,widths=None,size=9):
    t=D.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    if widths is None:widths=[6.65/len(headers)]*len(headers)
    for i,w in enumerate(widths):t.columns[i].width=Inches(w)
    for i,v in enumerate(headers):t.rows[0].cells[i].text=str(v)
    for row in rows:
        cells=t.add_row().cells
        for i,val in enumerate(row):cells[i].text=str(val)
    for ir,row in enumerate(t.rows):
        trPr=row._tr.get_or_add_trPr();no=OxmlElement("w:cantSplit");trPr.append(no)
        if ir==0:
            repeat=OxmlElement("w:tblHeader");trPr.append(repeat)
        for i,cell in enumerate(row.cells):
            cell.width=Inches(widths[i]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcPr=cell._tc.get_or_add_tcPr()
            borders=OxmlElement("w:tcBorders")
            for edge in ["top","left","bottom","right"]:
                el=OxmlElement("w:"+edge);el.set(qn("w:val"),"single");el.set(qn("w:sz"),"4");el.set(qn("w:color"),"D9D9D9");borders.append(el)
            tcPr.append(borders)
            shade=OxmlElement("w:shd");shade.set(qn("w:fill"),"E8E8E8" if ir==0 else "FFFFFF");tcPr.append(shade)
            margins=OxmlElement("w:tcMar")
            for edge in ["top","bottom","left","right"]:
                el=OxmlElement("w:"+edge);el.set(qn("w:w"),"70");el.set(qn("w:type"),"dxa");margins.append(el)
            tcPr.append(margins)
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(0);para.paragraph_format.space_before=Pt(0)
                para.paragraph_format.line_spacing=Pt(size+4)
                para.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size=Pt(size);run.font.bold=ir==0
    spacer=D.add_paragraph()
    spacer.paragraph_format.line_spacing=Pt(2)
    spacer.paragraph_format.space_after=Pt(4)
    spacer.add_run().font.size=Pt(1)
    return t
def pair_images(a,b,wa=2.9):
    par=D.add_paragraph();par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    par.add_run().add_picture(str(F/(a+".png")),width=Inches(wa))
    par.add_run("  ")
    par.add_run().add_picture(str(F/(b+".png")),width=Inches(wa))
def grows(names,originals=None):
    rows=[]
    for i,name in enumerate(names):
        v=G[name]
        rows.append([name,f"{v['gain']:.3f} ± {v['gain_ci']:.3f}",
                     "—" if originals is None else str(originals[i]),f"{v['converged']}/{v['n']}"])
    return rows


p("人工智能算法定价与合谋", "Title")
p("Python 实验复现与结果检阅", "Subtitle")
p("复现对象  Calvano · Calzolari · Denicolò · Pastorello  |  AER 2020\n实验日期  2026 年 10 月 20 日")
h("主要结果")
p(f"基准双寡头模型的核心数量结果得到复现。1,000 个独立随机种子的平均利润增益 Δ 为 {mean('gain'):.4f}，"
  "原文表 1 为 0.849。算法收敛后的价格显著高于一次性伯特兰竞争价格；强制降价后，双方经历短暂价格战，再逐步回到原先的高价格区间。"
  "不过，单期偏离受到惩罚，并不等价于任意持续偏离都无利可图。本报告分别核算这两个问题。")
table(["指标","本次结果","原文或理论参照"],[
    ["平均利润增益 Δ",ci("gain"),"0.849  原文表 1"],
    ["长期平均价格",ci("price"),"约 1.79  原文图 4"],
    ["静态纳什价格",fmt(S["benchmarks"]["pn"][0],5),"约 1.47"],
    ["垄断价格",fmt(S["benchmarks"]["pm"][0],5),"约 1.92"],
    ["恒定价格会话占比",pct(sum(t["frequency"] for t in S["table1"] if t["category"]=="1")),"64.3%"],
    ["基准收敛会话",f"{B['converged']}/1,000","连续 100,000 期策略不变"],
    ["单期最优降价后的折现收益变化",pct(mean("deviation_gain"),2),"通常为负"]],[2.55,2.0,2.1])
p("“±”表示跨独立会话均值的近似 95% 蒙特卡洛置信区间半宽，不表示原文估计的不确定性。"
  "Δ 的分母是垄断利润与静态纳什利润之差，Δ=0.849 不能解释为利润比竞争水平高 84.9%。")
h("阅读重点")
p("图 4 提供与截图同风格的价格冲击曲线，同时附正文定义下的替代版本。表 1 对照价格周期和收益分布；"
  "参数网格、折现因子、稳健性及重新配对结果在后文逐项报告。所有复现曲线均来自本次 Python 实际运行，未对原文曲线做拟合或手工调整。")
p(f"总计完成 {S['totals']['sessions']:,} 次训练会话、约 {S['totals']['training_periods']/1e9:.2f} 十亿期互动。"
  "核心实验与原文保持相同的 1,000 次重复；参数扫描和稳健性实验采用较小的重复规模，具体见实验覆盖表。")

page("模型和算法")
p("市场包含 n 家企业和一个外部选项。企业同时选择价格；每家企业只利用自己的利润、上一期价格状态和自己的 Q 表更新策略。"
  "企业之间没有显式通信，也未在奖励函数中加入合谋目标。[1]")
p("Logit 需求  qᵢ(p) = exp[(aᵢ − pᵢ)/μ] / {Σⱼ exp[(aⱼ − pⱼ)/μ] + exp(a₀/μ)}")
p("单期利润  πᵢ(p) = (pᵢ − cᵢ) qᵢ(p)")
p("Q 更新  Qᵢ(s,a) ← (1−α)Qᵢ(s,a) + α[πᵢ + δ maxₐ′ Qᵢ(s′,a′)]")
p("探索概率  εₜ = exp(−βt)；探索时从所有价格档位均匀抽样，否则选择 Q 值最大的价格；并列时选择最低价格。")
table(["参数","基准值","说明"],[
    ["n / k / m","2 / 1 / 15","企业数 / 记忆期数 / 价格档位"],
    ["cᵢ / aᵢ / a₀","1 / 2 / 0","成本 / 产品质量 / 外部选项"],
    ["μ / δ","0.25 / 0.95","产品差异 / 折现因子"],
    ["α / β","0.15 / 4×10⁻⁶","学习率 / 探索衰减率"],
    ["ξ","0.1","价格网格上下扩展系数"],
    ["策略稳定窗口","100,000 期","每家企业在全部状态上的贪婪动作均不变"],
    ["单次上限","1,000,000,000 期","达到上限但未稳定时标记为未收敛"]],[1.3,1.9,3.45])
p("价格网格严格按原文区间 [pᴺ−ξ(pᴹ−pᴺ), pᴹ+ξ(pᴹ−pᴺ)] 取 15 个等距点，"
  f"范围为 [{S['benchmarks']['prices'][0][0]:.6f}, {S['benchmarks']['prices'][0][-1]:.6f}]。"
  "连续纳什价及垄断价均不要求落在网格节点上。")
p("Q 表初始化为：对手独立均匀随机定价时，该动作的期望利润除以 (1−δ)。初始状态均匀随机。"
  "基准每家企业有 225 个状态、3,375 个状态动作单元。每期先计算双方更新目标，再同步更新，以免自环状态下引入先后更新偏差。")

page("实验覆盖和复现口径")
table(["实验","本次规模","与原文关系"],[
    ["基准及图 4–6、8–11","1,000 个种子","基准重复次数一致"],
    ["α 与 β 参数扫描","11×11 点，每点 100 次","原文为 100×100 点，每点 1,000 次"],
    ["折现因子","21 个取值，每点 200 次","覆盖 0 至 0.99；采样密度及重复次数缩减"],
    ["无记忆对照","200 次","k=0，δ=0，α=0.25，β=10⁻⁴"],
    ["稳健性","36 组，每组 200 次","成本、质量、企业数、需求扰动、μ、初始化、价格集、记忆"],
    ["需求基准口径追加检验","5 组，每组 200 次","保留无冲击基准的替代定义，与期望基准并列"],
    ["重新配对","1,000 对，各 40,000 期","关闭探索，继续更新 Q 表"],
    ["未执行的扩展","见后文边界说明","不作为已复现结果"]],[1.65,2.05,2.95],9)
p("每个种子对应一个独立训练会话。先从收敛策略构造确定性状态转移图，找到训练末态最终进入的周期，"
  "再计算周期上的平均利润和价格。冲击实验从周期的每个相位出发，先在会话内部平均，再对会话等权平均，避免长周期会话获得更高权重。")
p("参数网格 α∈[0.025,0.25]，β∈[0.2×10⁻⁶,2×10⁻⁵]，均等距取 11 点。"
  "图中只显示已执行的格点，不进行平滑插值；因此热力图比原文粗糙是预期现象。")
p("置信区间以独立会话为抽样单位。种子、参数、每次迭代数、收敛标志、最终周期及收益均保存在 JSON/CSV 中；"
  "基准 1,000 次实验还保留完整 Q 表、策略和学习轨迹。")
p("作者正式复现包的 DOI 已核实，但下载页面返回 HTTP 403，因此本项目属于基于正文、作者补充材料和公开代码审阅的独立重实现，"
  "不是作者原程序的逐行翻译。[1–3] 公开 Python 示例的价格端点、初始状态和稳定计数与正文存在差别，本项目按正文处理。")
p("对于需求冲击，本实现用对随机需求取期望后的利润函数计算连续纳什和垄断基准，企业不预先观察当期冲击。"
  "非对称企业使用各自的纳什价与联合利润最大化价格构造各自价格网格。这些实现约定在代码中固定并可检阅。")

page("图 4 与截图一致的价格冲击展示")
ref=S["figure4_reference"]
pic("figure04",5.55,
    "图 4  每个会话中强制企业 1 在第 1 期选择第 3 个价格档位 1.505216，此后恢复原策略。1,000 次会话等权平均。")
p(f"基准长期价格为 {mean('price'):.4f}。固定档位降价后的第 2 期，偏离者和非偏离者平均价格分别为 "
  f"{ref['time2_deviator']:.4f} 和 {ref['time2_other']:.4f}，随后逐步恢复。该冲击平均改变偏离者折现收益 {pct(ref['deviation_gain'],2)}，"
  f"周期相位平均的不盈利比例为 {pct(ref['ic'],2)}。")
pic("figure04_literal",5.05,
    "替代图 4  严格按正文脚注 30，以对手冲击前价格计算网格内静态最优回应。除冲击价格规则外，训练结果和统计权重均相同。")
p("原图第 1 期价格约 1.505，而正文的静态最优回应在本模型下平均约 1.61。上图采用可明确说明、与截图接近的固定档位冲击；"
  "下图保留正文定义。两者不能当作完全相同的实验，也未据图形外观反向调整训练参数。")

page("基准分布和最优性诊断")
p("表 1 按最终价格周期分组。1-Sym. 为双方收敛至相同恒定价格，1-Asym. 为不同恒定价格。"
  "完全对称的企业仍可能形成不对称价格或周期，这源于各自随机探索历史不同。")
table(["类别","本次频率","原文频率","本次 Δ","原文 Δ"],[
    [t["category"],fmt(t["frequency"]),str(of),fmt(t["gain"]),str(og)]
    for t,of,og in zip(S["table1"],[.277,.366,.643,.238,.119,1],[.866,.855,.860,.846,.793,.849])
],[1.15,1.35,1.35,1.4,1.4])
p("收益均值与原文高度接近；周期构成的差异应结合 1,000 次会话的抽样误差解读。"
  "均值接近并不意味着每个随机种子或每条路径与作者结果相同。")
table(["最优性口径","本次","原文表 1"],[
    ["一期偏离后恢复原策略  路径上稳定比例",pct(mean("one_step_equilibrium")),"50.5%"],
    ["上述口径  路径上平均 Q 损失",pct(mean("one_step_q_loss_on"),3),"0.2%"],
    ["上述口径  全状态平均 Q 损失",pct(mean("one_step_q_loss_all"),3),"1.8%"],
    ["持续动态最优回应  路径上均衡比例",pct(mean("equilibrium")),"无完全同口径直接值"],
    ["持续动态最优回应  相对最优价值损失",pct(mean("value_loss"),2),"无完全同口径直接值"]],[3.75,1.45,1.45],9)
p("一期口径先计算双方继续使用已学策略的价值 Vᶠ，再计算 Q¹(s,a)=π(s,a)+δVᶠ(s′)。"
  "其结果与原文表 1 的数量级接近；由于未取得作者程序，这只能作为可比诊断，不能证明原文内部实现完全相同。")
p("持续偏离则固定对手策略，对偏离者求解 Bellman 最优方程 V*(s)=maxₐ[π(s,a)+δV*(s′)]。"
  "本次严格路径上最优性比例明显低于一期口径。只检查均衡路径上的一期偏离，不能排除先进入路径外状态、随后继续改变动作的获利策略。"
  "因此本报告将高价格与短期惩罚视为已复现现象，不把它们直接等同于严格均衡证明。")

page("参数网格中的收益和策略稳定性")
pair_images("figure01","figure02")
p("左图对应原文图 1；右图对应图 2 的一期偏离诊断。每个格点 100 次训练。图 2 的标题明确采用一期偏离稳定性，避免与持续动态最优回应混淆。","Caption")
pair_images("figure07","figure02_audit")
p("左下图对应原文图 7，以非偏离者第 2 期价格与冲击前价格之比表示惩罚强度，值越低表示降价越多；右下图为持续动态最优回应审计。","Caption")
p(f"本次 {S['grid']['cells']} 个格点的平均利润增益介于 {S['grid']['gain_min']:.3f} 与 {S['grid']['gain_max']:.3f}。"
  "这检验了高利润是否只在单个参数点上出现。网格较稀且每点重复次数较少，因此不宜比较原图细微的局部纹理或据此精确定位全局最优参数。")
p("β 越小，探索衰减越慢，训练耗时越长。α 决定新观察对旧 Q 值的替换速度；更快更新未必提高长期收益。"
  "惩罚热力图来自正文静态最优回应冲击，和前页固定档位版本分开记录。")

page("折现因子和无记忆对照")
pic("figure03",6.0,"图 3  每个折现因子执行 200 次会话，浅色带为均值的近似 95% 置信区间。")
p("改变 δ 保持其余基准参数不变。高折现因子提高未来损失对当前定价的影响，使延迟惩罚能够约束当前行为；"
  "当 δ 较低时，算法更倾向于争取当期收益，平均利润增益下降。δ 同时进入 Q 更新目标和初始化，因而这不是只改变经济激励而完全保持学习动态不变的实验。")
table(["对照组","本次 Δ","原文参照","收敛次数"],grows(["discount_0.00","discount_0.50","discount_0.95","discount_0.99","memoryless"],
    ["见图 3","见图 3",".849","见图 3",".185"]),[2.3,1.55,1.25,1.55])
p("无记忆实验只有一个状态，因此不能根据上一期对手价格实施条件惩罚。其残余利润增益可能来自价格离散化、"
  "持续更新过程以及未达到精确最优回应，不应仅凭 Δ>0 判断存在重复博弈式惩罚机制。")

page("冲击分布与小幅降价")
pic("figure05",6.0,"图 5  仅使用最终价格恒定的会话。实线为均值，矩形为四分位区间，虚线为样本最小值至最大值；冲击采用正文静态最优回应。")
p("平均曲线并未展示所有会话的异质性。不同训练历史会产生不同惩罚深度和恢复路径，因此检阅机制时需同时查看分布，而不能只看平滑均值。")
pic("figure06",5.7,"图 6  将偏离企业在第 1 期的原定价格降低一个网格档位，之后恢复原策略；所有会话及周期相位均参与平均。")
p("小幅降价后若双方第 2 期进一步降价，就出现原文所称的过度反应。这里将“小幅”明确规定为一个价格档位，"
  "正文未给出可唯一确定的小冲击数值，因此该曲线是具有明确规则的机制复现。")

# Tables 2 and 3: symmetric fixed-point subsample, all alternate deviation columns.
devrows=list(csv.DictReader((R/"tables2_3_replication.csv").open()))
price_grid=S["benchmarks"]["prices"][0]
pre_indices=sorted(set(round(float(r["pre_price"]),8) for r in devrows))
cols=list(range(0,14,2))
def dev_matrix(metric):
    rows=[]
    for pv in pre_indices:
        rr=[r for r in devrows if abs(float(r["pre_price"])-pv)<1e-7]
        pidx=int(np.argmin(abs(np.array(price_grid)-pv)))
        freq=float(rr[0]["frequency"])
        row=[f"{pv:.2f}",f"{freq:.2f}"]
        for j in cols:
            match=[r for r in rr if abs(float(r["deviation_price"])-price_grid[j])<1e-7]
            row.append(f"{float(match[0][metric]):.2f}" if match else ("0" if j==pidx else ""))
        rows.append(row)
    return rows
heads=["冲击前价","频率"]+[f"{price_grid[i]:.2f}" for i in cols]
ww=[.68,.5]+[(6.65-1.18)/len(cols)]*len(cols)
page("表 2 偏离后的价格变化")
p("仅纳入收敛至对称恒定价格的会话。列标题为强制偏离价格，按原文方式隔一档报告；未构成降价的位置留空。"
  "频率以本次对称恒定价格会话为分母；小样本价格组的数值应谨慎解读。完整 15 档数据及组内次数另存 CSV。")
D.add_heading("面板 A 非偏离者第 2 期相对冲击前价格变化",2)
table(heads,dev_matrix("nondeviator_price_change"),ww,8)
D.add_heading("面板 B 偏离者第 2 期相对第 1 期价格变化",2)
table(heads,dev_matrix("deviator_price_change"),ww,8)
p("表中 −0.13 表示价格下降 13%，不是价格下降 0.13 个单位。不同降价幅度通常触发相似量级的竞争反应；"
  "对偏离企业而言，大幅降价后下一期可以回升，而小幅降价后反而可能继续下调。")

page("表 3 偏离是否有利可图")
D.add_heading("面板 A 偏离者折现利润的相对变化",2)
table(heads,dev_matrix("discounted_gain"),ww,8)
D.add_heading("面板 B 偏离无利可图的比例",2)
table(heads,dev_matrix("unprofitable_fraction"),ww,8)
p("折现收益从偏离当期开始计算，比较强制偏离一期后恢复原策略的路径与完全不偏离的路径。"
  "确定性策略的无限期价值通过收敛迭代求解，δ=0.95 时残差阈值为 10⁻¹¹，避免只累计前 15 期而漏掉后续收益。")
p("0 表示相同价格、没有实际偏离的对角位置；空白表示不属于降价实验。惩罚能使许多单期降价无利可图，"
  "但不能据此推出持续多期改变策略也无利可图，相关区别已在最优性诊断中报告。")

page("已学习策略的有向图")
pic("figure08",6.2,"图 8  基准样本中按种子顺序选取的首个对称恒定价格且全状态可达该价格的会话。方形为吸收节点，节点大小表示介数中心性，颜色越深表示该价格状态的利润增益越高。")
p(f"示例会话编号为 {B['graph_session']}，对应种子 {20261020+B['graph_session']}。每个节点代表一对上一期价格，"
  "每条边表示双方同时执行已学策略后的下一期状态。本图展示一个实际训练出的策略图，不是对 1,000 个策略表求均值得到的虚构代表策略。")
p(f"在整个基准样本中，有 {pct(B['all_basin_fraction'])} 的会话从全部 225 个状态出发均会进入训练末态对应的长期吸收集，"
  f"平均可达状态数为 {B['mean_basin']:.2f}。原文报告全部状态可达的会话约为 92%。")
p("较大的吸引域说明原有价格协调能够在多种扰动后恢复，但图的拓扑结构本身不能证明经济意义上的最优惩罚或均衡。"
  "它也不能说明不同会话之间的策略能够直接互换。")

page("策略相图")
pic("figure09",5.8,"图 9  与前页同一会话。横纵坐标为两家企业的价格，短箭头只表示下一期变化方向，不按完整跳转距离绘制。")
p("相图把策略图节点放回价格坐标中，便于观察不同初始价格如何移动。吸收节点之外的许多状态先向较低价格区间移动，"
  "再返回长期价格附近。这与冲击响应中先发生价格战、随后恢复的路径相呼应。")
p("原文图 8 和图 9 也是单个会话的示例。本次不具备作者的原始随机种子与最终 Q 表，因而不追求节点位置或单个箭头逐一一致；"
  "本图的可核验目标是节点含义、策略转移、吸收集和总体可达性统计。SVG 文件保留矢量文本与图元，方便后续放大和编辑。")

page("市场结构和经济参数稳健性")
pic("robustness",6.25,"稳健性实验  红色方块为本次均值，误差线为近似 95% 置信区间。基准点为 1,000 次，其余各点为 200 次。")
table(["设定","本次 Δ","原文 Δ","收敛次数"],grows(
    ["players_3","players_4","cost_0.875","cost_0.75","cost_0.625","cost_0.5","cost_0.25"],
    [.643,.559,.841,.812,.781,.759,.713]),[2.2,1.6,1.3,1.55])
p("增加企业数同时改变市场竞争强度和 Q 表规模。保持 β 不变时，每个状态动作单元得到的探索相对更少，"
  "因此不能把利润变化全部解释为经济竞争效应。成本不对称实验则还涉及利润在企业间如何分配。")

page("表 4 成本不对称及利润分配")
asym=S["asymmetry"]
table(["c₂","企业 2 纳什份额","本次 Δ","原文 Δ","本次利润比","原文利润比"],[
    [fmt(x["c2"]),fmt(x["nash_share2"]),fmt(x["gain"]),str(og),fmt(x["profit_ratio"]),str(orr)]
    for x,og,orr in zip(asym[:6],[.849,.841,.812,.781,.759,.713],[.997,1.050,1.121,1.193,1.265,1.442])
],[.65,1.3,1.05,1.05,1.3,1.3],8.5)
p("企业 2 的纳什份额指两种在售商品内部的销量份额，不含外部选项。利润比定义为 (π₁/π₁ᴺ)/(π₂/π₂ᴺ)，"
  "先在会话内部计算，再对会话平均。大于 1 表示企业 1 相对于自身竞争基准的利润增长倍数更高。")
p("降低企业 2 的成本会提高其竞争市场份额，但合作收益的相对分配可能偏向成本更高的企业 1。"
  "因此合计利润增益的变化不能只归因于是否成功协调，也与不对称企业之间的收益分配有关。")
D.add_heading("质量不对称",2)
table(["a₂","企业 2 纳什份额","本次 Δ","本次利润比"],[
    [fmt(x["a2"]),fmt(x["nash_share2"]),fmt(x["gain"]),fmt(x["profit_ratio"])] for x in asym[6:]
],[1.1,1.9,1.7,1.95])
p("质量实验固定 a₁=2，提高企业 2 的质量参数。较低成本与较高质量都增加企业 2 的净产品吸引力；"
  "但价格网格和基准需按各组实际参数重新求解，不能直接复制成本组的曲线充当质量组结果。")

page("随机需求和基准定义")
table(["需求或质量设定","本次 Δ","原文 Δ","收敛次数"],grows(
    ["shock_0.05","shock_0.1","shock_0.15","shock_0.2","shock_0.25"],
    [.848,.832,.797,.750,.695]),[2.35,1.55,1.2,1.55])
p("质量不对称实验固定企业 1 的 a₁=2，提高企业 2 的 a₂；需求冲击实验令 a₀ 在 −a₀ᴴ、0、a₀ᴴ 三点等概率独立抽样。"
  "冲击值在企业选择价格时不可见。随机冲击只影响奖励，不额外加入状态。")
p("随机需求组的纳什和垄断参照由期望利润函数重新求解，长期收益也按期望奖励计算。"
  "这避免把需求波动引起的机械利润水平变化全部记作合谋程度变化；同时也意味着比较时必须核对作者是否采用完全相同的基准计算约定。")
D.add_heading("固定无冲击基准的追加检验",2)
table(["冲击幅度","期望基准口径","固定基准口径","原文"],[
    [str(sh),fmt(G[f"shock_{sh}"]["gain"]),fmt(G[f"fixedshock_{sh}"]["gain"]),str(og)]
    for sh,og in zip([.05,.1,.15,.2,.25],[.848,.832,.797,.750,.695])
],[1.2,1.8,1.8,1.85])
p("追加口径同时保留无冲击的价格网格、Q 初始化以及利润归一化参照，仅在训练奖励中加入需求冲击。"
  "两组都完整保留，不将更接近原文的结果覆盖原组。该对照表明需求冲击的数量结论对基准定义敏感，仍有剩余差异。")
page("产品差异与其数值边界")
pic("product_differentiation",5.8,"产品差异参数对照  红色为本次模拟，蓝色为原文补充表 A10 的公开汇总值；连线只用于帮助比较离散参数点。")
table(["μ","本次 Δ","原文 Δ"],[
    [str(mu),fmt(G[f"mu_{mu}"]["gain"]),str(og)]
    for mu,og in zip([.01,.05,.1,.15,.2,.3,.35,.4,.45,.5],[.805,.827,.829,.835,.839,.859,.853,.859,.860,.856])
],[1.2,2.7,2.75])
p("μ 越小，产品越接近替代品。本次最小取值为 0.01，未将其冒充 μ=0 的完全同质品极限。"
  "极小 μ 处使用不同初值求解纳什一阶条件，并检查单边微小价格变动不能提高利润。")

page("初始化 价格集合和记忆长度")
table(["设定","本次 Δ","原文 Δ","收敛次数"],grows(
    ["init_nash","init_constant5","init_constant10","init_random","wide_grid","low_grid","actions_50","actions_100","memory_2"],
    [.731,.793,.978,.877,.761,.612,.709,.704,.574]),[2.25,1.6,1.25,1.55])
p("init_nash 假定对手始终使用距连续纳什价格最近的网格点；本次最近点为 1.466469。"
  "作者补充材料还讨论向上近似到第三个网格点，初始化口径并非逐字节相同。constant5、constant10 分别把整个 Q 表设为 5 和 10；"
  "constant10 同时关闭随机探索。random 对每个 Q 单元独立均匀抽取 [0,10] 数值。[2]")
p("即使关闭随机探索，较高的初始 Q 值也可能诱导尝试不同动作：访问过的动作价值下降后，其他未访问动作变得相对有吸引力。"
  "因此“没有 ε 探索”不能简单理解为“没有任何学习中的动作尝试”。")
p("wide_grid 使用 ξ=0.5；low_grid 将最低价格设为 0.99，最高价保持基准；actions_50 和 actions_100 改变网格密度；"
  "memory_2 使用最近两期联合价格作为状态。后一组每家企业有 50,625 个状态和 759,375 个 Q 单元。")
p("更大的动作或记忆空间并不保证效果改善。学习时间和探索资源相同时，空间扩大可能使绝大多数单元难以充分访问。"
  "所有这些实验仍使用相同的全策略稳定窗口，而不是观察到价格几期不变便提前终止。")
p(f"两期记忆组的本次平均 Δ={G['memory_2']['gain']:.3f}，原文为 0.574，差约 "
  f"{G['memory_2']['gain']-.574:.3f}。这一偏差明显大于基准组偏差，不能标为定量复现成功。"
  "状态编码已经验证；在未取得作者代码前，不能确定差异究竟来自初始化、状态或停止规则的细节，还是其他实现约定。")

page("学习过程与重新配对")
pic("figure10",5.55,"图 10  每 1,000 期抽取最近 100 期利润的移动平均；蓝色虚线为探索时随机定价、否则使用向下近似纳什价的竞争参照。")
p(f"基准平均训练长度为 {mean('steps')/1e6:.3f} 百万期。少量会话在图示上限前停止：截至 150 万期为 "
  f"{pct(B['fraction_stopped_by_1_5m'])}；其剩余绘图部分用冻结策略的周期期望利润延续，并非声称又执行了额外学习。")
pic("figure11",5.55,"图 11  对 1,000 对已训练算法按固定随机排列循环换伴，确保不与原搭档配对；ε=0，继续学习，每点为 100 期平均。")
p(f"换伴后最初 100 期平均 Δ 为 {S['rematch']['first100']:.3f}，最后 100 期为 {S['rematch']['last100']:.3f}。"
  "该实验区分了已经学会一般定价与已经同特定搭档协调两个概念。换伴规则和初始状态均已固定，不能据此假定所有部署环境具有相同适应速度。")

page("多期冲击及解释边界")
pic("figureA08",5.9,"补充图 A8  强制企业 1 连续 5 期使用距连续纳什价最近的网格点 1.466469，随后恢复原策略；相同 1,000 次训练结果。")
p("该补充实验核验一次冲击与持续短期冲击的恢复路径是否具有相似结构。这里明确使用最近档位；"
  "因此与原补充图的强制价格档位可能不同，不将视觉完全一致作为已达成结论。")
h("尚未完成的原文扩展")
p("本报告未执行随机进入退出导致的可变市场结构、完全同质品 μ=0 极限、grim-trigger 初始化、线性需求、Boltzmann 探索、"
  "不对称学习率，以及三企业下大幅降低 β 的补偿性探索。未覆盖项目不并入任何复现成功比例，也未以原文结果填充本次数据。")
p("原文完整 α×β 扫描为 10,000 个参数点、每点 1,000 次，合计一千万次训练。本次网格仅覆盖其中的参数范围，"
  "计算密度和重复数量更小。均值置信区间仅反映本次种子间变异，不包含模型设定、数值定义差异或原文结果的不确定性。")
p("高价格、惩罚性价格响应以及恢复路径构成本模型内的机制证据。它们不能直接用于判断现实市场中的违法合谋，"
  "也不证明算法具有沟通意图；后者不属于本次模拟能够识别的内容。")

page("复现方法和文件索引")
p("代码使用 Python、NumPy、SciPy、Numba 和 Matplotlib。Numba 只编译 Python 数值循环，不改变 Q-learning 更新规则；"
  "Word 由 python-docx 根据保存的统计结果生成。实际运行版本、机器信息和文件哈希记录在环境清单中。")
table(["文件或目录","用途"],[
    ["model.py","需求、基准价格、Q-learning、周期识别、冲击和最优回应"],
    ["run_experiments.py","按固定种子运行全部实验；已完成会话可断点续跑"],
    ["postprocess.py","一期偏离诊断、策略图统计、重新配对和补充冲击"],
    ["run_shock_sensitivity.py","随机需求基准口径的追加对照"],
    ["make_figures.py","由保存结果生成全部图形、汇总 CSV 与 summary.json"],
    ["build_report.py","从 summary.json 和图形生成本 Word 报告"],
    ["tests/verify.py","数值基准、解析解、执行等价性与同种子重复检查"],
    ["results/baseline","1,000 次基准会话的 Q 表、策略、周期、轨迹和元数据"],
    ["figures","300 dpi PNG 与可编辑 SVG 图形"],
    ["results/*.csv","图表数据、逐次会话结果和原文表格对应矩阵"],
    ["README.md / requirements.txt","安装、执行顺序、计算规模和指标定义"]],[2.0,4.65])
p("常规环境中先建立 Python 虚拟环境并安装 requirements.txt，随后按 README 中的命令执行。"
  "完整参数网格可通过 --grid-size 100 --grid-sessions 1000 --results-dir results_full 配置，避免混合不同规模的数据。")
p("有效性检查包括：连续纳什与垄断价格；价格网格端点；随机对手初始化；Numba 与逐行解释执行在同一 2,000 期轨迹上的一致性；"
  "固定策略折现价值与解析解；动态最优回应与解析解；双期记忆编码；完整基准会话同种子重跑完全一致。"
  "动态最优回应还与独立线性规划解交叉核验。"
  "这些检查通过说明实现满足所列条件，不意味着已经验证所有经济结论。")
p("基准种子为 20261020 至 20262019；网格、折现与稳健性实验使用不同的固定种子区间，详细起点在每组 config.json 中。"
  "置信区间按会话聚合，不把单个会话的数百万期互动视作独立样本。")

page("资料来源和检阅结论")
p("[1] Calvano, E., Calzolari, G., Denicolò, V., & Pastorello, S. (2020). Artificial Intelligence, Algorithmic Pricing, and Collusion. "
  "American Economic Review, 110(10), 3267–3297. https://doi.org/10.1257/aer.20190623")
p("[2] 作者 Online Appendix，May 2020，24 页。https://www.aeaweb.org/articles/materials/13398")
p("[3] 作者复现包登记。https://doi.org/10.3886/E119462V1 。本次核实登记链接，下载入口返回 HTTP 403；未声称已运行该包。")
p("[4] Matteo Courthoud. Algorithmic-Collusion-Replication. 公开 Python、MATLAB、Julia 示例。"
  "https://github.com/matteocourthoud/Algorithmic-Collusion-Replication 。审阅提交 fcb04bf90d43a30556533a5d7233e0e00943f7cc，MIT 许可。")
p("以上资料于 2026 年 10 月 20 日检索。正文和作者附录构成模型与原始比较值的主要依据；"
  "第三方示例仅用于检查实现路径。本次模型为独立编写，未把第三方运行结果作为本次实验结果。")
h("可以确认的结论")
p(f"在本次基准环境中，平均利润增益 {mean('gain'):.4f} 与原文 0.849 基本一致；价格分布、周期行为、"
  "降价后的短期竞争反应和逐步恢复支持原文的主要模拟现象。大规模重复和明确的周期权重处理，使这一结果不依赖单个展示种子。")
h("需要保留的限定")
p("图 4 的冲击价格存在图示与正文定义不完全一致的问题，本报告同时提供两种透明实现。"
  "一期偏离诊断与严格动态最优回应具有不同的偏离集合，不能互换解释。"
  "参数扫描重复规模缩小，部分扩展未执行，因此本报告应称为核心实验及主要稳健性实验的独立复现，而不是全篇所有计算逐项等量重跑。")
p("后续如用于论文或正式汇报，建议优先检查本报告的实验覆盖、图 4 冲击定义和最优性诊断三处，"
  "再决定是否追加完整参数网格、作者包逐行审计或未覆盖扩展。")

out=ROOT/"report"/"T3_算法定价与合谋_Python复现报告.docx"
out.parent.mkdir(exist_ok=True)
D.save(out)
print(out)
