# T3：Calvano 等 2020 算法定价与合谋 Python 复现

本项目重实现论文 *Artificial Intelligence, Algorithmic Pricing, and Collusion*
（American Economic Review 110(10), 3267–3297）的核心实验和主要稳健性实验。
这是适合上传 GitHub 的纯源码版本，包含 Python 脚本、测试、依赖清单和运行说明。
不包含已生成的实验数据、Q 表、图表、Word 报告、论文 PDF 或第三方依赖。
完整实验曾实际运行；本文以下结果说明对应先前运行记录，数据不随本源码包提供。
没有使用原图拟合、手动平滑或作者结果填充。
运行完整流程后生成 `report/T3_算法定价与合谋_Python复现报告.docx`。

## 安装与运行

建议 Python 3.12，在项目目录中执行：

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python tests/verify.py
python run_experiments.py --stage all --workers 6
python run_shock_sensitivity.py
python postprocess.py --mode baseline
python postprocess.py --mode grid
python make_figures.py
python build_report.py
```

`run_experiments.py` 将每个会话的 JSON 作为完成标记，已经完成的会话自动跳过。
参数或样本量不同则拒绝混写。生成报告需要完整结果，不能只运行 smoke test。
`postprocess.py --mode grid` 为一期偏离诊断重演同样的种子，并核验迭代数一致；
这些确定性重演不是新的独立会话，不重复计入总样本量。

本源码包不附训练数据。首次使用应先按上述顺序生成完整结果；
已有完整 `results/` 目录时，重新制图与生成报告只需：

```sh
python make_figures.py
python build_report.py
```

完整原文网格的训练配置（计算量远大于本报告）：

```sh
python run_experiments.py --stage grid --grid-size 100 --grid-sessions 1000 \
  --results-dir results_full --workers 6
```

此命令只生成新的训练数据。本报告与配套制图脚本默认读取 `results`，
若使用其他结果目录或实验设计，应相应调整汇总与报告中的样本量说明。

## 默认实验规模与先前运行范围

- 基准：1,000 会话，α=0.15、β=4e-6、δ=0.95。
- 参数扫描：11×11 参数格点，每点 100 会话；原文为 100×100、每点 1,000。
- 折现因子：21 个取值，每点 200 会话。
- 无记忆对照：200 会话。
- 主要稳健性：36 组，每组 200 会话。
- 随机需求基准定义追加对照：5 组，每组 200 会话。
- 重新配对：由基准样本形成 1,000 对，各执行 40,000 期。
- 总计 25,700 个独立训练会话；重新配对和诊断重演另计。

本报告不声称执行了全篇全部附录实验。未执行随机进入退出、μ=0、
grim-trigger 初始化、线性需求、Boltzmann 探索、不对称学习参数等扩展。

## 关键定义

1. 价格网格严格使用原文 ξ=0.1 的区间，15 个等距价格。
2. 初始状态均匀随机；初始 Q 为随机对手利润的无限期折现值。
3. 并列最大 Q 时选择最低价格。
4. 连续 **100,000 个时期**中所有企业、所有状态的贪婪动作不变才算收敛；
   上限为 10 亿期。每期只有当前状态可能发生变化，因此检查该行等价于全表检查。
   稳定计数每期增加一次，不按企业数多次增加。
5. Q 更新使用双方更新前的下一状态最大值，保证同时更新。
6. 收敛后的收益取训练末态进入的整个周期的平均值。
7. 冲击先在每个会话内等权平均所有周期相位，再对会话等权平均。
8. Numba 采用每会话固定种子，线程数不改变会话内随机序列。

### 图 4 的两种冲击规则

论文正文脚注 30 说对“对手冲击前价格”作静态最优回应，但图中第 1 期价格
约为 1.505。本模型下正文定义给出的平均静态最优回应约为 1.61。

- `figure04.png`：固定第三个网格点 1.505216，匹配截图的冲击幅度；
  该设定明确标为对图示的实现约定，不声称恢复了作者的原始内部代码。
- `figure04_literal.png`：按正文定义计算每个周期相位的网格内静态最优回应。

两者使用同一批基准 Q 表，均未为了使曲线好看而更换种子。图 5、图 7、
基准 JSON 中的 `deviation_gain`/`ic` 使用正文定义。参考截图口径的统计值在
`summary.json` 的 `figure4_reference`。

### 均衡与 Q 损失不可混用

- `one_step_equilibrium`：对每个路径状态、每家企业检验任意一期偏离，
  此后返回原策略。先计算原策略价值，再求单期偏离价值。
- `equilibrium`：固定对手策略，对自己求持续动态最优回应，检验路径动作是否
  在最优 Bellman Q 表中最优。
- `one_step_q_loss_*`：一期偏离损失，以一期最优偏离价值为分母。
- `q_loss_*`：动态最优 Q 表中所选动作的损失，以最优状态价值为分母。
- `value_loss`：`(V* - V_learned) / V*`，不是“一期 Q 损失”，也不是
  `(V* - V_learned) / V_learned`。

一期指标与原文表 1 的量级较接近，但作者程序未取得，不能据此证明内部实现相同。
动态最优回应通过另行构造的线性规划交叉验证。不能把一期偏离稳定直接当作
任意持续偏离都不获利的证明。

### 随机需求的两种基准

- `shock_*`：用期望利润重新求纳什/垄断价格，构造价格网格及 Q 初始化，
  并用期望利润基准归一化。
- `fixedshock_*`：保留无冲击的网格、初始化和归一化基准，训练奖励才加入随机冲击。

两种结果均保留；固定基准较接近原文，但不据此隐藏另一组结果。
两期记忆结果与原文存在明显数量差异，在报告中明确列出。

## 运行后生成的输出

- `results/baseline/*.npz`：每次基准会话的完整 Q 表、策略、周期、冲击响应、学习曲线。
- `results/*/*.json`：每个会话的种子、迭代数、收敛状态、周期及统计。
- `results/*/config.json`：实验参数及种子起点。
- `results/*.csv`：各图数据、表 1–4 对应统计和稳健性汇总。
- `results/summary.json`：Word 和结果概览的数据来源。
- `results/verification.json`：有效性检查结果。
- `figures/*.png`：300 dpi 图形。
- `figures/*.svg`：矢量图形。

训练曲线每 1,000 期抽取最近 100 期的移动平均。已停止会话的尾部使用冻结策略
的周期期望利润延续，停止比例在报告中披露。恢复长度观察窗口为 40 期，
只对在窗口内返回原吸收集的周期相位计算；无限期折现收益另行求解，不截断在 40 期。
近似 95% 置信区间按独立会话计算，不能将期数视为样本量。

## 来源

- 论文：https://doi.org/10.1257/aer.20190623
- 作者附录：https://www.aeaweb.org/articles/materials/13398
- 作者复现包登记：https://doi.org/10.3886/E119462V1
  （本次下载页返回 HTTP 403，未取得或运行作者包）
- 审阅的公开示例：https://github.com/matteocourthoud/Algorithmic-Collusion-Replication
  ，提交 `fcb04bf90d43a30556533a5d7233e0e00943f7cc`。

模型为独立编写。公开示例没有被直接作为本次生产实现使用。示例中价格端点、
初始状态和收敛计数与正文不同，本项目选择正文规则。


## 源码文件

| 文件 | 用途 |
| --- | --- |
| `model.py` | 市场模型、Q-learning、周期分析及最优回应 |
| `run_experiments.py` | 基准、参数扫描、折现和主要稳健性实验 |
| `run_shock_sensitivity.py` | 随机需求基准定义的追加检验 |
| `postprocess.py` | 冲击响应、重新配对及策略诊断 |
| `make_figures.py` | 统计汇总、PNG 和 SVG 图形 |
| `build_report.py` | 从完整结果生成中文 Word 报告 |
| `tests/verify.py` | 数值正确性及可重复性检验 |
| `requirements.txt` | 安装依赖 |
| `requirements-used.txt` | 先前实验使用的依赖版本记录 |

`.gitignore` 默认排除实验输出、虚拟环境、缓存和压缩包。
上传 GitHub 时解压本包，将 `T3/` 内文件作为仓库内容即可。
默认流程运行数万次训练，不是即时演示；机器速度和并行线程数影响所需时间。
图形使用 Arial、Times New Roman，中文报告使用 Noto Sans CJK SC；
系统未安装这些字体时会使用替代字体，版面可能略有差异。
