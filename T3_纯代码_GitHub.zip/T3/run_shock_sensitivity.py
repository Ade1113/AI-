"""Pre-specified interpretation check: retain the original no-shock benchmarks.

Both normalization conventions are preserved and reported, never silently swapped.
"""
from dataclasses import replace
from run_experiments import *

if __name__=="__main__":
    for i,s in enumerate([.05,.10,.15,.20,.25]):
        run_group(f"fixedshock_{s}",replace(Config(),shock=s,shock_benchmark="baseline"),
                  200,70_000_000+i*10000,6)
