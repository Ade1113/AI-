"""Numerical correctness checks, separate from scientific replication claims."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from dataclasses import replace
from model import *

def main():
    c=Config(); e=environment(c)
    assert np.allclose(e["pn"],1.47292666,atol=1e-7)
    assert np.allclose(e["pm"],1.92498092,atol=1e-7)
    assert np.allclose(e["prices"][:,0],e["pn"]-.1*(e["pm"]-e["pn"]))
    assert np.allclose(e["prices"][:,-1],e["pm"]+.1*(e["pm"]-e["pn"]))
    for i in range(2):
        for a in range(15):
            mask=e["actions"][:,i]==a
            assert np.isclose(e["q0"][i,a],e["mean_payoff"][mask,i].mean()/.05)
    args=(123,e["payoff"],e["q0"],e["powers"],1,.15,4e-6,.95,100000,2000,False,False,2000,1000)
    fast=train(*args)
    reference=train.py_func(*args)
    assert np.allclose(fast[0],reference[0],rtol=0,atol=1e-12)
    assert np.array_equal(fast[1],reference[1])
    assert fast[2:5]==reference[2:5]
    assert not fast[4]  # Hitting ceiling is not convergence.
    repeat=train(*args)
    assert np.array_equal(fast[0],repeat[0])
    # Every state chooses price index 2: values have a closed form.
    policy=np.full((2,225),2,dtype=np.int64)
    nxt,ja=transition(policy,e["powers"],1)
    val=evaluate_policy(e["mean_payoff"][ja],nxt,.95)
    assert np.allclose(val,e["mean_payoff"][32]/.05,atol=3e-10)
    cyc=cycle_from(nxt,0)
    assert np.array_equal(cyc,[32])
    v,q=best_response(policy,0,e["mean_payoff"],e["powers"],1,.95)
    best_stage=e["mean_payoff"][np.arange(15)*15+2,0].max()
    assert np.allclose(v,best_stage/.05,atol=3e-9)
    assert np.allclose(v,q.max(axis=1),atol=1e-9)
    # Memory-two state update retains exactly the last two joint actions.
    pol2=np.full((2,225**2),2,dtype=np.int64)
    n2,j2=transition(pol2,e["powers"],2)
    assert n2[123]==(123*225+32)%(225**2)
    r1=run_session(20261020,c,save_q=True)
    r2=run_session(20261020,c,save_q=True)
    assert r1[0]==r2[0] and np.array_equal(r1[-1],r2[-1])
    # Independent LP check of the unexpected dynamic best-response diagnostic.
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    pol=r1[1]
    for i in range(2):
        j=1-i
        ss=np.repeat(np.arange(225),15);aa=np.tile(np.arange(15),225)
        jj=pol[j,ss]*e["powers"][j]+aa*e["powers"][i]
        rows=np.arange(len(ss))
        mat=coo_matrix((np.r_[-np.ones(len(ss)),.95*np.ones(len(ss))],
                       (np.r_[rows,rows],np.r_[ss,jj])),shape=(len(ss),225)).tocsr()
        lp=linprog(np.ones(225),A_ub=mat,b_ub=-e["mean_payoff"][jj,i],
                   bounds=[(None,None)]*225,method="highs")
        vv,qq=best_response(pol,i,e["mean_payoff"],e["powers"],1,.95)
        assert lp.success and np.allclose(lp.x,vv,atol=3e-8)
    msg={"status":"PASS","checks": [
        "continuous benchmark values","price-grid endpoints","Q initialization",
        "Numba matches independent interpreted execution for 2000 periods",
        "iteration cap is censored","exact same-seed rerun",
        "policy value vs analytic discounted sum","best response vs analytic solution",
        "memory-two encoding","complete-session exact reproducibility",
        "dynamic best response agrees with independent linear programming"]}
    out=Path(__file__).resolve().parents[1]/"results"/"verification.json"
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(msg,indent=2))
    print(json.dumps(msg,indent=2))
if __name__=="__main__": main()
