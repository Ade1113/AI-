"""Run resumable seeded experiments. See README.md for scale and definitions."""
from pathlib import Path
import argparse, json, time, os, platform
from dataclasses import asdict,replace
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from model import Config,environment,run_session

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"results"


def run_group(name,cfg,count,seed_start,workers=6,keep=False):
    dest=OUT/name
    dest.mkdir(exist_ok=True,parents=True)
    meta=dict(config=asdict(cfg),sessions=count,seed_start=seed_start)
    meta_path=dest/"config.json"
    if meta_path.exists():
        previous=json.loads(meta_path.read_text())
        previous["config"]=asdict(Config(**previous["config"]))
        assert previous==meta, f"Config mismatch for {name}"
    else:
        meta_path.write_text(json.dumps(meta,indent=2))
    environment(cfg)
    todo=[j for j in range(count) if not (dest/f"{j:04}.json").exists()]
    if not todo:
        print(f"{name}: cached {count}",flush=True); return
    started=time.time()
    def job(j):
        result,pol,cyc,path,trace,q=run_session(seed_start+j,cfg,full=cfg.n==2 and cfg.m==15,save_q=keep)
        # Commit arrays first; JSON is the completion marker.
        if keep:
            np.savez_compressed(dest/f"{j:04}.npz",policy=pol,cycle=cyc,path=path,trace=trace,q=q)
        else:
            np.savez_compressed(dest/f"{j:04}.npz",path=path)
        (dest/f"{j:04}.json").write_text(json.dumps(result,indent=2))
        return result
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs={ex.submit(job,j):j for j in todo}
        done=0
        for f in as_completed(futs):
            r=f.result(); done+=1
            if done%max(10,count//10)==0 or done==len(todo):
                print(f"{name}: {count-len(todo)+done}/{count}, "
                      f"elapsed {time.time()-started:.1f}s, last steps {r['steps']}, "
                      f"converged {r['converged']}",flush=True)


def main():
    global OUT
    p=argparse.ArgumentParser()
    p.add_argument("--stage",choices=["baseline","grid","discount","robustness","all"],default="all")
    p.add_argument("--workers",type=int,default=6)
    p.add_argument("--grid-size",type=int,default=11)
    p.add_argument("--grid-sessions",type=int,default=100)
    p.add_argument("--baseline-sessions",type=int,default=1000)
    p.add_argument("--sweep-sessions",type=int,default=200)
    p.add_argument("--results-dir",type=Path,default=OUT,
                   help="Use a separate directory for a different experimental scale.")
    args=p.parse_args()
    OUT=args.results_dir.resolve()
    OUT.mkdir(exist_ok=True)
    # Compile once before threads start.
    run_session(1,replace(Config(),max_steps=2,stable_periods=100),full=False)
    base=Config()
    if args.stage in ("baseline","all"):
        run_group("baseline",base,args.baseline_sessions,20261020,args.workers,True)
    if args.stage in ("grid","all"):
        for ia,a in enumerate(np.linspace(.025,.25,args.grid_size)):
            for ib,b in enumerate(np.linspace(.2e-6,20e-6,args.grid_size)):
                cfg=replace(base,alpha=float(a),beta=float(b))
                run_group(f"grid_a{ia:02}_b{ib:02}",cfg,args.grid_sessions,
                          30_000_000+ia*100_000+ib*1000,args.workers)
    if args.stage in ("discount","all"):
        for i,d in enumerate([0,.05,.10,.15,.20,.25,.30,.35,.40,.45,.50,.55,.60,.65,.70,.75,.80,.85,.90,.95,.99]):
            run_group(f"discount_{d:.2f}",replace(base,delta=d),args.sweep_sessions,
                      40_000_000+i*10000,args.workers)
        run_group("memoryless",replace(base,memory=0,delta=0,alpha=.25,beta=1e-4),
                  args.sweep_sessions,41_000_000,args.workers)
    if args.stage in ("robustness","all"):
        variants=[]
        for c in [.875,.75,.625,.5,.25]:
            variants.append((f"cost_{c}",replace(base,c2=c)))
        for a in [2.125,2.25,2.375,2.5,2.75]:
            variants.append((f"quality_{a}",replace(base,a2=a)))
        for n in [3,4]:
            variants.append((f"players_{n}",replace(base,n=n)))
        for shock in [.05,.10,.15,.20,.25]:
            # Same one-billion ceiling; censored runs must never be called converged.
            variants.append((f"shock_{shock}",replace(base,shock=shock)))
        for mu in [.01,.05,.1,.15,.2,.3,.35,.4,.45,.5]:
            variants.append((f"mu_{mu}",replace(base,mu=mu)))
        for init in ["nash","constant5","constant10","random"]:
            variants.append((f"init_{init}",replace(base,init=init,no_explore=init=="constant10")))
        variants.extend([
            ("actions_50",replace(base,m=50)),
            ("actions_100",replace(base,m=100)),
            ("wide_grid",replace(base,xi=.5)),
            ("low_grid",replace(base,low_price=.99)),
            ("memory_2",replace(base,memory=2)),
        ])
        for i,(name,cfg) in enumerate(variants):
            run_group(name,cfg,args.sweep_sessions,50_000_000+i*10000,args.workers)
    print("Finished",args.stage,flush=True)


if __name__=="__main__":
    main()
