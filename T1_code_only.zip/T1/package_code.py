"""Package T1 source code with portable configuration, excluding data/results."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = [
    "repro/__init__.py", "repro/__main__.py", "repro/common.py",
    "repro/author.py", "repro/inventory.py", "repro/synthetic_data.py",
    "repro/model.py", "repro/train.py", "repro/report.py", "repro/verify.py",
    "tests/test_author.py", "tests/test_causality.py", "tests/test_inventory.py",
    "config.json", "requirements.txt", "requirements.lock.txt", "README.md",
    ".gitignore", "package_code.py",
]
NOTICE = """## 纯代码包使用说明

本包只包含复现源码、测试、参数配置和依赖说明。原始论文、作者数据、
已执行 Notebook、实验结果、模型权重和虚拟环境不随包分发。

- `config.json` 中 `source_dir` 默认指向 `data/replication_package_MS-FTBDA-20-01585`。
  运行 `author` 或 `all` 前，请将原始复现数据包解压到这里，或修改该字段；
  必须保留 CSV 和 `.ipynb_checkpoints` 子目录。相对路径以配置文件所在目录为基准。
- `python -m pytest -q`、`python -m repro smoke` 和 `python -m repro synthetic`
  可以独立于作者数据运行；后两者会自行生成合成数据。
- `report` 和 `verify` 依赖此前生成的完整实验产物，不是源码包的安装测试。
  中文 HTML 报告和导览 Notebook 在执行报告命令后生成。
- 新机器优先安装 `requirements.txt`。`requirements.lock.txt` 保留原 macOS
  完整环境记录，其中部分平台依赖不适用于 Windows/Linux。
- Windows 可使用 `python -m venv .venv`、`.venv\\Scripts\\activate` 激活环境，
  然后使用 `python -m pip install -r requirements.txt`。
- 执行 `python package_code.py` 可重新生成 `dist/T1_code_only.zip`。

"""


def packaged_text(name):
    text = (ROOT / name).read_text(encoding="utf-8")
    if name == "config.json":
        config = json.loads(text)
        config["source_dir"] = "data/replication_package_MS-FTBDA-20-01585"
        return json.dumps(config, ensure_ascii=False, indent=2) + "\n"
    if name == "README.md":
        if "## 纯代码包使用说明" not in text:
            title, rest = text.split("\n", 1)
            text = title + "\n\n" + NOTICE + rest.lstrip()
        text = text.replace(
            "先阅读 `reports/复现报告.html` 或 `notebooks/复现实验导览.ipynb`。本项目区分：",
            "报告命令会生成 `reports/复现报告.html` 和 `notebooks/复现实验导览.ipynb`。本项目区分：",
        )
        return text.replace("pip install -r requirements.lock.txt", "pip install -r requirements.txt")
    if name == ".gitignore":
        for pattern in ["data/", "results/", "reports/", "notebooks/", "dist/", "*.log"]:
            if pattern not in text.splitlines():
                text = text.rstrip() + "\n" + pattern + "\n"
    return text


def main():
    archive = ROOT / "dist/T1_code_only.zip"
    archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in FILES:
            content = packaged_text(name)
            if name.endswith(".py"):
                ast.parse(content, filename=name)
            z.writestr("T1/" + name, content)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == {"T1/" + name for name in FILES}
        for name in z.namelist():
            z.read(name).decode("utf-8")
    assert archive.stat().st_size < 20_000_000
    print(json.dumps({"path": str(archive), "files": len(FILES),
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
