import numpy as np
import pandas as pd
import pytest

from repro.author import author_inventory, field_metrics
from repro.common import parse_array


def test_array_formats_and_invalid_values():
    np.testing.assert_array_equal(parse_array("[1. 2.\n 3.]"), [1, 2, 3])
    np.testing.assert_array_equal(parse_array("[1, 2, 3]"), [1, 2, 3])
    with pytest.raises(ValueError):
        parse_array("[nan]")


def test_author_backlog_reset_is_preserved_and_visible():
    row = {"initial_stock": [0], "OPT_pred": [5], "demand_hist": [np.array([3, 4, 2])], "vlt": [1]}
    full, costed, trace = author_inventory(row, "OPT")
    np.testing.assert_array_equal(full, [-3, 1, -1])
    np.testing.assert_array_equal(costed, [1, -1])
    assert trace[1]["backlog_reset"]


def test_author_negative_order_is_not_silently_clipped():
    row = {"initial_stock": [10], "OPT_pred": [5], "demand_hist": [np.array([0, 0])], "vlt": [1]}
    _, costed, trace = author_inventory(row, "OPT")
    assert trace[0]["replenishment"] == -5
    np.testing.assert_array_equal(costed, [5])


def test_field_endpoint_and_denominator_are_explicit():
    frame = pd.DataFrame([{"sku_dc_pair_index": 0, "test_inv": "[-2, 4, -8]", "test_demand": "[1, 2]",
                           "ave_demand": 2, "ave_inv": -1, "vlt": "3 days"}])
    result = field_metrics(frame, 1, 9).iloc[0]
    assert result.total_cost == 22
    assert result.stockout_ratio == pytest.approx(1/3)
    assert result.stockout_ratio_costed_denominator == .5
    assert result.turnover == 0
    assert result.turnover_raw == -.5
