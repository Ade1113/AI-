import copy
import numpy as np
import torch

from repro.common import load_config
from repro.inventory import simulate_fixed
from repro.model import InventoryNet
from repro.synthetic_data import features, generate, split_ranges, training_arrays
from repro.train import encode_context, rollout_context, seed_all, simulate_policy


def small_cfg():
    cfg = copy.deepcopy(load_config()["synthetic"])
    cfg["n_skus"] = 9
    return cfg


def test_future_perturbation_cannot_change_features(tmp_path):
    cfg = small_cfg()
    data = generate(cfg, tmp_path)
    day = split_ranges(cfg)["validation"][0]
    before = features(data, cfg, day)
    changed = {key: value.copy() for key, value in data.items()}
    changed["demand"][:, day:] += 999
    changed["lead"][:, day:] = 999
    after = features(changed, cfg, day)
    for key in before:
        np.testing.assert_array_equal(before[key], after[key], err_msg=key)


def test_target_windows_do_not_cross_splits(tmp_path):
    cfg = small_cfg()
    data = generate(cfg, tmp_path)
    ranges = split_ranges(cfg)
    train = training_arrays(data, cfg, 9, "train")
    val = training_arrays(data, cfg, 9, "validation")
    assert train["label_last_day"].max() < ranges["validation"][0]
    assert val["label_last_day"].max() < ranges["test"][0]
    changed = training_arrays(data, cfg, 1, "train")
    assert not np.array_equal(train["target_q"], changed["target_q"])
    for key in ["seq", "vlt", "basic", "stock"]:
        np.testing.assert_array_equal(train[key], changed[key])


def test_model_shapes_finite_nonnegative_and_roundtrip(tmp_path):
    cfg = small_cfg()
    seed_all(0, 1)
    data = generate(cfg, tmp_path)
    arrays = training_arrays(data, cfg, 9)
    model = InventoryNet(cfg).eval()
    inputs = [torch.from_numpy(arrays[key][:4]) for key in ("seq", "basic", "vlt", "calendar", "stock")]
    result = model(*inputs)
    assert result["daily"].shape == (4, 31, 7)
    assert result["quantity"].shape == (4, 1)
    for key in ("daily", "cumulative", "quantity", "lead"):
        assert torch.isfinite(result[key]).all() and (result[key] >= 0).all()
    torch.save(model.state_dict(), tmp_path / "weights.pt")
    restored = InventoryNet(cfg).eval()
    restored.load_state_dict(torch.load(tmp_path / "weights.pt", weights_only=True))
    torch.testing.assert_close(result["quantity"], restored(*inputs)["quantity"], rtol=0, atol=0)


def test_batched_rollout_matches_independent_daily_simulation(tmp_path):
    cfg = small_cfg()
    data = generate(cfg, tmp_path)
    ctx = rollout_context(data, cfg, "test")
    for method in ("OPT", "Normal", "Gamma"):
        batch = simulate_policy(data, cfg, ctx, 9, method)
        for sku in range(cfg["n_skus"]):
            result = simulate_fixed(data["demand"][sku, ctx["start"]:ctx["stop"]],
                                    np.array(ctx["days"])-ctx["start"], data["lead"][sku, ctx["days"]],
                                    batch["orders"][sku])
            np.testing.assert_array_equal(batch["inventory"][sku], result["inventory"])
            assert batch["total_cost"][sku] == result["total_cost"]
