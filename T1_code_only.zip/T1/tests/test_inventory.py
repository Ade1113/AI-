import numpy as np
import pytest

from repro.inventory import enumerate_optimum, optimal_quantity, oracle_orders, simulate_fixed


@pytest.mark.parametrize("ratio", [1, 4, 9])
@pytest.mark.parametrize("initial", [-2, 0, 10])
def test_theorem_matches_independent_enumeration(ratio, initial):
    rng = np.random.default_rng(178)
    for _ in range(8):
        demand = rng.integers(0, 3, 5)
        days = [0, 2]
        leads = [1, 2]
        q = oracle_orders(demand, days, leads, initial, 1, ratio)
        actual = simulate_fixed(demand, days, leads, q, initial, 1, ratio)["total_cost"]
        optimum, _ = enumerate_optimum(demand, days, leads, initial, 1, ratio)
        assert actual == pytest.approx(optimum)


def test_arrivals_precede_demand_and_backorders_persist():
    result = simulate_fixed([3, 4, 2], [0], [1], [5])
    np.testing.assert_array_equal(result["inventory"], [-3, -2, -4])
    assert result["total_cost"] == 81


def test_zero_demand_excess_stock_and_horizon():
    assert optimal_quantity([0, 0], 10) == 0
    assert optimal_quantity([], -2) == 0
    assert optimal_quantity([1, 2, 3], 100) == 0
    q = oracle_orders([1, 2], [0, 1], [1, 2])
    assert q[1] == 0
    result = simulate_fixed([1, 2], [0], [5], [100])
    np.testing.assert_array_equal(result["inventory"], [-1, -3])


def test_reject_crossing_and_invalid_inputs():
    with pytest.raises(ValueError):
        oracle_orders([1]*8, [0, 1], [5, 1])
    with pytest.raises(ValueError):
        optimal_quantity([-1], 0)
    with pytest.raises(ValueError):
        simulate_fixed([1], [0], [1], [-2])


def test_integer_critical_ratio_tie_has_optimal_cost():
    q = optimal_quantity([2, 3], 0, 1, 1)
    # q=2 and q=5 are both minimizers; compare costs, not arbitrary tie labels.
    costs = [sum(abs(x-np.cumsum([2, 3]))) for x in (2, q, 5)]
    assert len(set(costs)) == 1
