# T1：端到端库存管理复现

## 纯代码包使用说明

本包只包含复现源码、测试、参数配置和依赖说明。原始论文、作者数据、
已执行 Notebook、实验结果、模型权重和虚拟环境不随包分发。

- `config.json` 中 `source_dir` 默认指向 `data/replication_package_MS-FTBDA-20-01585`。
  运行 `author` 或 `all` 前，请将原始复现数据包解压到这里，或修改该字段；
  必须保留 CSV 和 `.ipynb_checkpoints` 子目录。相对路径以配置文件所在目录为基准。
- `python -m pytest -q`、`python -m repro smoke` 和 `python -m repro synthetic`
  可以独立于作者数据运行；后两者会自行生成合成数据。
- `report` 和 `verify` 依赖此前生成的完整实验产物，不是源码包的安装测试。
  中文 HTML 报告和导览 Notebook 在执行报告命令后生成。
- 新机器优先安装 `requirements.txt`。`requirements.lock.txt` 保留原 macOS
  完整环境记录，其中部分平台依赖不适用于 Windows/Linux。
- Windows 可使用 `python -m venv .venv`、`.venv\Scripts\activate` 激活环境，
  然后使用 `python -m pip install -r requirements.txt`。
- 执行 `python package_code.py` 可重新生成 `dist/T1_code_only.zip`。

本目录对应 Qi et al., *A Practical End-to-End Inventory Management Model with Deep Learning*, Management Science 69(2), 759–773，DOI：[10.1287/mnsc.2022.4564](https://doi.org/10.1287/mnsc.2022.4564)。

报告命令会生成 `reports/复现报告.html` 和 `notebooks/复现实验导览.ipynb`。本项目区分：

1. **作者口径复算**：保留公开 Notebook 的算法行为，包括其需要讨论的边界处理。
2. **论文口径对照**：只针对证据明确的公式、参数、截距和匹配距离另做分析。
3. **合成方法验证**：重建训练流程，明确不是原始京东训练数据或作者模型权重。

## 环境与复跑

运行目录为本文件所在目录。需要 Python 3.11；首次安装：

```sh
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Apple Silicon 上 LightGBM 另需 `libomp`（本机使用 Homebrew 安装）。若只运行作者子样本评估，不需要训练或 GPU。所有主命令：

```sh
.venv/bin/python -m pytest -q --junitxml=results/tests.xml
.venv/bin/python -m repro author
.venv/bin/python -m repro smoke
.venv/bin/python -m repro synthetic
.venv/bin/python -m repro report
.venv/bin/python -m repro verify
```

`python -m repro all` 顺序执行作者评估、完整合成套件、报告和保存结果验证；不会改原始材料。`smoke` 是 30 个 SKU、2 轮、1 个种子的端到端验证，输出独立保存，不能冒充完整实验。

`config.json` 集中设置源数据、输出目录与训练参数。另一个配置文件可用 `--config PATH` 指定；相对路径以配置文件目录为基准。修改合成参数时应使用新的输出目录，防止混用旧权重。相同配置下重跑会复用已完成的训练任务；中断但未完成的单个训练任务从头开始，不伪称精确断点续训。

`requirements.txt` 固定直接依赖；`requirements.lock.txt` 记录实际完整环境。安装过程中使用清华 PyPI 镜像解决本机 Python 对官方索引的 TLS 连接问题。Python 3.11 在本目录的 `.bootstrap/` 中独立安装，没有替换系统 Python。

## 源码与产物

| 模块/目录 | 作用 |
|---|---|
| `repro/author.py` | 离线评估、现场统计、匹配、原 Notebook 独立运行、缓存逐项对照 |
| `repro/inventory.py` | 理论库存仿真、定理 1 标签、独立小规模枚举 |
| `repro/synthetic_data.py` | 合成机制、时间切分、因果特征与标签 |
| `repro/model.py` | 三输出 MQRNN 风格网络与损失 |
| `repro/train.py` | 训练、验证集选择、LightGBM、成本比例与消融实验 |
| `repro/report.py` | 中文 HTML 报告与已执行导览 Notebook |
| `results/stage1/author/` | 原作者口径的成本、统计及轨迹诊断 |
| `results/stage1/paper_check/` | 独立论文口径对照 |
| `results/stage1/notebooks/` | 已执行的原 Notebook 副本；CSV 为原文件的只读使用链接 |
| `results/stage1/matching/` | 匹配索引、协变量平衡、复用数量与分布图 |
| `results/synthetic/` | 完整合成数据、指标、图表、参数和权重 |
| `results/synthetic_smoke/` | 小规模通路验证，不计入完整实验 |
| `tests/` | 数学核验、边界、信息泄漏和作者行为测试 |

## 必须保留的解释边界

- `df_test.csv` 的 3,000 行不是 3,000 个唯一 SKU；分组后是 2,607 个。
- 公开预测不是训练输入。现有 5/2/1 行模型数据不足以训练原论文模型。
- 作者仿真会产生负补货量、到货时重置负库存，并仅对部分记录天数计费。作者口径保留，合成仿真不沿用。
- 现场实验的前后匿名 ID 只在组内对齐。不能把候选池重新匹配索引当作现有结果文件的真实身份映射。
- 原 Notebook 使用 `h=1,b=9`；论文现场实验记载 `h=12,b=88`。对照只重新计价现有库存轨迹，没有声称重新执行现场政策。
- 双重差分回归标准误按“组别:ID”聚类。只有两期，不能验证平行趋势。匹配可能使用处理后协变量，也不能消除所有混杂。
- 原 Notebook 的 5 项 DiD 检验缓存 t/p 值与干净重跑不一致；独立实现与干净重跑一致。`reference_discrepancies.csv` 保留这 10 个缓存差异，未通过改动算法强行对齐。
- 论文明确说按创建日期切分；合成重建额外使用 31 天隔离区防止多跨度标签泄漏，不声称时间划分与原实验完全相同。

## 合成重建的公开假设

- 1,000 个 SKU；数据种子 2026；训练种子 0、1、2。周期审查 R=7，实际交货期 1–6 天，无订单交叉；完全延期交货、无限容量、无固定订货费。
- 单位日需求强度为 log-uniform(0.5,12)，三类需求为 Poisson、周正弦调制 Poisson、Bernoulli(0.25)×Poisson(均值/0.25)。真实强度和相位不进入特征。
- 时间区间为零基半开区间：历史 `[0,180)`；训练 `[180,270)`；验证 `[301,331)`；测试 `[362,392)`；总长度 423 天。
- 实际需求输入为最近 56 天，已知日历输入含未来星期信息；历史交货期仅使用确定已经到货的订单。所有尺度来自 `[0,180)`。
- 补货标签按实际到货日之间的需求由定理 1 生成。历史库存状态按四个倍率轮换，测试初始库存为 0；跨实验共享同一物理路径。
- LSTM 编码器 + 共享多跨度解码器是 **MQRNN 风格的重建**，不是逐行复原原训练源码。BM1 使用专门学习的累计需求分位数，BM2 使用逐日预测并按多期成本求解。
- 六个需求分位数为 0.1/0.6/0.7/0.8/0.9/0.95，另有均值输出。需求损失将逐日和累计损失取平均；各自包括 pinball 与均值 MSE。两个辅助损失默认权重 0.1。
- 决策标签按历史日均需求×7 归一化；需求预测按历史日均需求归一化；累计需求按历史日均需求×7；交货期按 6。网络的非负输出使用 Softplus。
- SGD、动量 0.85、初始学习率 0.001、epoch 级逆时间衰减 1e-4、梯度裁剪 10、最多 100 epoch、早停耐心 10。
- 预测基准每个种子训练一次，各成本比例分别按验证集 BM2 库存成本保存 checkpoint；BM1/BM2 各自的预测输出选择也只用验证集。测试集从不选择参数。
- LightGBM 的树数在 20–200、步长 20 中按验证库存成本选择，其他参数写入每个模型的 `selection.json`。
- 成本比例为 1/4/9，均重新生成决策标签并训练；比例 9 的无辅助损失模型另训。评价不仅报告均值，还报告三个训练种子的标准差。
- 不预设 E2E 必须获胜。若其表现不如 LightGBM 等基准，应按实际结果报告并讨论重建假设与数据机制。

## 论文图表对应关系

| 论文内容 | 本项目对应产物 | 覆盖边界 |
|---|---|---|
| 第 4 节、图 2 右 | `stage1/author/offline_summary.csv`、`offline_costs.*` | 公开子样本的评估复算 |
| 表 2 | `field_ttests.csv` | 500+500 子样本，原脚本参数 |
| 表 3 | `field_regression.csv` | 原无截距与含截距对照分别保存 |
| 表 4 | `field_did.csv` | 原检验与按个体聚类的回归对照 |
| 图 3 | `matching_distributions.*`、`matching_balance.csv` | 原匹配与倾向得分距离对照 |
| 定理 1、图 1 | `inventory.py`、`model.py`、测试及模型权重 | 合成数据的方法验证 |
| 附录 B | `synthetic/summary.csv`、`cost_comparison.*` | 三种成本比例、三个种子、辅助损失消融；非完整附录重做 |
