from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def load_config(path=None):
    path = Path(path or ROOT / "config.json").resolve()
    cfg = json.loads(path.read_text())
    for key in ("source_dir", "output_dir"):
        cfg[key] = str((path.parent / cfg[key]).resolve())
    return cfg


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=_json_default) + "\n")
    temporary.replace(path)


def _json_default(obj):
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(type(obj).__name__)


def parse_array(value):
    """Read either Python lists or the author's whitespace-separated numpy arrays."""
    if isinstance(value, str):
        if "," in value or value.strip() == "[]":
            values = ast.literal_eval(value)
        else:
            values = value.strip().strip("[]").split()
    else:
        values = value
    result = np.asarray(values, dtype=float)
    if result.ndim != 1 or not np.isfinite(result).all():
        raise ValueError("Expected a finite one-dimensional numeric sequence")
    return result


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def environment():
    packages = ["numpy", "pandas", "scipy", "scikit-learn", "statsmodels", "matplotlib",
                "seaborn", "torch", "lightgbm", "nbclient", "nbformat"]
    versions = {}
    for package in packages:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = "not installed"
    return {"python": platform.python_version(), "platform": platform.platform(),
            "machine": platform.machine(), "packages": versions}


def plot_setup():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "savefig.dpi": 220, "svg.fonttype": "none"})
    return plt


def save_figure(fig, stem):
    stem = Path(stem)
    stem.parent.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "svg"):
        fig.savefig(stem.with_suffix("." + extension), bbox_inches="tight")


def inventory_cost(inventory, h, b):
    inventory = np.asarray(inventory, dtype=float)
    return h * np.maximum(inventory, 0).sum(axis=-1), b * np.maximum(-inventory, 0).sum(axis=-1)
