"""Reproduction of Qi et al. (2023), with explicit provenance boundaries."""
