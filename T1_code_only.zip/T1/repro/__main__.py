import argparse

from .common import load_config


def main():
    parser = argparse.ArgumentParser(description="T1 public-subsample reproduction and synthetic method validation")
    parser.add_argument("command", choices=["author", "synthetic", "smoke", "report", "verify", "all"])
    parser.add_argument("--config", default=None)
    parser.add_argument("--skip-notebooks", action="store_true", help="Skip independent original-notebook parity checks")
    args = parser.parse_args()
    cfg = load_config(args.config)
    if args.command in ("author", "all"):
        from .author import run_author
        run_author(cfg, execute=not args.skip_notebooks)
    if args.command in ("synthetic", "smoke", "all"):
        from .train import run_synthetic
        run_synthetic(cfg, smoke=args.command == "smoke")
    if args.command in ("report", "all"):
        from .report import build_report
        build_report(cfg)
    if args.command in ("verify", "all"):
        from .verify import verify
        verify(cfg)


if __name__ == "__main__":
    main()
