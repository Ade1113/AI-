"""CPU training, causal rollouts, validation-only model selection, and full suite."""
from __future__ import annotations

import copy
import hashlib
import json
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import torch
from torch.utils.data import DataLoader, Dataset

from .common import environment, plot_setup, save_figure, write_json
from .inventory import oracle_orders
from .model import InventoryNet, losses
from .synthetic_data import features, generate, split_ranges, training_arrays

INPUTS = ("seq", "basic", "vlt", "calendar", "stock")
TARGETS = ("target_q", "target_lead", "target_daily", "target_cumulative")


def seed_all(seed, threads):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)


class ArrayDataset(Dataset):
    def __init__(self, arrays):
        self.values = {key: torch.from_numpy(arrays[key]) for key in INPUTS+TARGETS}

    def __len__(self):
        return len(self.values["stock"])

    def __getitem__(self, index):
        return {key: value[index] for key, value in self.values.items()}


def rollout_context(data, cfg, split):
    start, stop = split_ranges(cfg)[split]
    days = list(range(start, stop, cfg["review_period"]))
    return {"start": start, "stop": stop, "days": days,
            "features": {day: features(data, cfg, day) for day in days}}


@torch.inference_mode()
def encode_context(model, context):
    model.eval()
    result = {}
    for day, frame in context["features"].items():
        # Chunking limits inference working memory independently of SKU count.
        chunks = []
        for start in range(0, len(frame["seq"]), 256):
            args = [torch.from_numpy(frame[k][start:start+256]) for k in ("seq", "basic", "vlt", "calendar")]
            chunks.append(model.encode(*args))
        result[day] = {key: torch.cat([chunk[key] for chunk in chunks], dim=0) for key in chunks[0]}
        for key in ("daily", "cumulative", "lead"):
            result[day][key] = result[day][key].numpy()
    return result


def simulate_policy(data, cfg, context, ratio, method, model=None, encoded=None, quantile=6, gbm=None, tree_iteration=None):
    """Policy sees causal features/current stock. Only scheduler sees actual lead."""
    n, scale = len(data["scale"]), data["scale"]
    start, stop = context["start"], context["stop"]
    length, R = stop-start, cfg["review_period"]
    stock = np.zeros(n, float)
    scheduled = np.zeros((n, length+cfg["lead_max"]+1))
    history = np.empty((n, length))
    quantities = []
    oracle = None
    if method == "OPT":
        rel_days = np.array(context["days"])-start
        oracle = np.array([oracle_orders(data["demand"][s, start:stop], rel_days,
                                        data["lead"][s, context["days"]], h=cfg["holding_cost"],
                                        b=cfg["holding_cost"]*ratio) for s in range(n)])
    q_index = 0
    for offset, day in enumerate(range(start, stop)):
        stock += scheduled[:, offset]
        if day in context["features"]:
            f = context["features"][day]
            remaining = stop-day
            if method == "OPT":
                q = oracle[:, q_index]
            elif method in ("Normal", "Gamma"):
                protection = np.minimum(R+f["lead_mean"], remaining)
                if method == "Normal":
                    variance = protection*f["demand_std"]**2 + f["demand_mean"]**2 * f["lead_std"]**2
                    target = f["demand_mean"]*protection + stats.norm.ppf(ratio/(1+ratio))*np.sqrt(variance)
                else:
                    variance = f["demand_std"]**2
                    theta = np.divide(variance, f["demand_mean"], out=np.zeros(n), where=f["demand_mean"]>0)
                    shape = np.divide(f["demand_mean"], theta, out=np.zeros(n), where=theta>0)*protection
                    target = stats.gamma.ppf(ratio/(1+ratio), a=np.maximum(shape, 1e-12), scale=np.maximum(theta, 1e-12))
                    target = np.where(variance > 0, target, f["demand_mean"]*protection)
                q = np.maximum(target-stock, 0)
            elif method in ("BM1", "BM2"):
                prediction = encoded[day]
                predicted_lead = np.clip(np.rint(prediction["lead"].ravel()*6), 1, cfg["lead_max"]).astype(int)
                protection = np.minimum(R+predicted_lead, remaining)
                if method == "BM1":
                    target = prediction["cumulative"][np.arange(n), protection-1, quantile]*scale*R
                else:
                    interval = np.maximum(protection-predicted_lead, 0)
                    last_index = np.minimum(predicted_lead+np.floor(ratio/(1+ratio)*interval).astype(int), remaining-1)
                    cumulative = np.cumsum(prediction["daily"][:, :, quantile], axis=1)*scale[:, None]
                    target = cumulative[np.arange(n), last_index]
                q = np.where(predicted_lead < remaining, np.maximum(target-stock, 0), 0)
            elif method in ("E2E", "E2E_no_aux"):
                with torch.inference_mode():
                    stock_tensor = torch.from_numpy((stock/(scale*R)).astype(np.float32)[:, None])
                    q = model.quantity(encoded[day]["fused"], stock_tensor).numpy().ravel()*scale*R
            elif method == "LightGBM":
                x = np.column_stack([f["tree"], stock/(scale*R)])
                q = gbm.predict(x, num_iteration=tree_iteration)*scale*R
            else:
                raise ValueError(f"Unknown policy: {method}")
            if not np.isfinite(q).all():
                raise FloatingPointError(f"Nonfinite order in {method}")
            q = np.maximum(np.rint(q), 0)
            # No policy reads these realized leads; the physical environment does.
            arrival_offsets = offset + data["lead"][:, day]
            scheduled[np.arange(n), arrival_offsets] += q
            quantities.append(q)
            q_index += 1
        stock -= data["demand"][:, day]
        history[:, offset] = stock
    holding = cfg["holding_cost"]*np.maximum(history, 0).sum(axis=1)
    shortage = cfg["holding_cost"]*ratio*np.maximum(-history, 0).sum(axis=1)
    return {"holding_cost": holding, "stockout_cost": shortage, "total_cost": holding+shortage,
            "stockout_ratio": (history < 0).mean(axis=1), "mean_on_hand": np.maximum(history, 0).mean(axis=1),
            "inventory": history, "orders": np.array(quantities).T}


def select_pto(data, cfg, context, ratio, encoded):
    selection, values = {}, {}
    for method in ("BM1", "BM2"):
        candidates = [simulate_policy(data, cfg, context, ratio, method, encoded=encoded, quantile=q)["total_cost"].mean()
                      for q in range(len(cfg["quantiles"])+1)]
        selection[method] = int(np.argmin(candidates))
        values[method] = float(min(candidates))
    return selection, values


def train_network(data, cfg, arrays, validation, seed, ratio, variant, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    signature = hashlib.sha256(json.dumps({"cfg": cfg, "seed": seed, "ratio": ratio, "variant": variant}, sort_keys=True).encode()).hexdigest()
    status_path = output / "status.json"
    if status_path.exists():
        status = json.loads(status_path.read_text())
        if status.get("signature") != signature:
            raise ValueError(f"Configuration changed; choose a new output directory: {output}")
        if status.get("complete"):
            return status
    seed_all(seed, cfg["cpu_threads"])
    model = InventoryNet(cfg)
    optimizer = torch.optim.SGD(model.parameters(), lr=cfg["learning_rate"], momentum=cfg["momentum"])
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda epoch: 1/(1+cfg["learning_rate_decay"]*epoch))
    loader = DataLoader(ArrayDataset(arrays), batch_size=cfg["batch_size"], shuffle=True, num_workers=0,
                        generator=torch.Generator().manual_seed(seed))
    forecast_only = variant == "forecast"
    ratios = cfg["cost_ratios"] if forecast_only else [ratio]
    best = {str(r): {"cost": float("inf"), "epoch": 0} for r in ratios}
    no_improvement, log, start_time = 0, [], time.monotonic()
    for epoch in range(1, cfg["max_epochs"]+1):
        model.train()
        total_loss, count = 0.0, 0
        for batch in loader:
            optimizer.zero_grad(set_to_none=True)
            pred = model(*(batch[key] for key in INPUTS))
            loss, _ = losses(pred, batch, cfg["quantiles"], 0 if variant == "no_aux" else cfg["aux_weight"], forecast_only)
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite training loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
            optimizer.step()
            total_loss += loss.item()*len(batch["stock"])
            count += len(batch["stock"])
        scheduler.step()
        model.eval()
        encoded = encode_context(model, validation)
        any_improvement, row = False, {"epoch": epoch, "train_loss": total_loss/count,
                                       "elapsed_seconds": time.monotonic()-start_time}
        for r in ratios:
            if forecast_only:
                selection, costs = select_pto(data, cfg, validation, r, encoded)
                cost = costs["BM2"]  # Predeclared selection criterion.
            else:
                selection = None
                cost = simulate_policy(data, cfg, validation, r, "E2E", model=model, encoded=encoded)["total_cost"].mean()
            row[f"validation_cost_b{r}"] = float(cost)
            if cost < best[str(r)]["cost"] - 1e-7:
                best[str(r)] = {"cost": float(cost), "epoch": epoch, "quantile_selection": selection}
                payload = {"state_dict": model.state_dict(), "config": cfg, "seed": seed, "ratio": r,
                           "variant": variant, "epoch": epoch, "validation_cost": float(cost), "signature": signature}
                torch.save(payload, output / f"best_b{r}.pt")
                any_improvement = True
        log.append(row)
        pd.DataFrame(log).to_csv(output / "training_log.csv", index=False)
        no_improvement = 0 if any_improvement else no_improvement+1
        status = {"complete": False, "signature": signature, "variant": variant, "seed": seed,
                  "ratio": ratio, "last_epoch": epoch, "best": best, "elapsed_seconds": time.monotonic()-start_time}
        write_json(status_path, status)
        if epoch == 1 or epoch % 5 == 0 or no_improvement >= cfg["patience"]:
            best_text = ",".join(str(r) + ":" + format(best[str(r)]["cost"], ".1f") for r in ratios)
            print(f"seed={seed} {variant} b={ratio} epoch={epoch} loss={row['train_loss']:.4f} "
                  f"val={best_text} "
                  f"elapsed={status['elapsed_seconds']:.1f}s", flush=True)
        if no_improvement >= cfg["patience"]:
            break
    status["complete"] = True
    status["stopping_reason"] = "patience" if no_improvement >= cfg["patience"] else "max_epochs"
    write_json(status_path, status)
    return status


def load_network(path, cfg):
    model = InventoryNet(cfg)
    payload = torch.load(path, map_location="cpu", weights_only=True)
    model.load_state_dict(payload["state_dict"])
    model.eval()
    return model


def fit_tree(data, cfg, train_arrays, validation, ratio, seed, output):
    import lightgbm as lgb
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    path = output / "model.txt"
    if path.exists() and (output / "selection.json").exists():
        return lgb.Booster(model_file=str(path)), json.loads((output / "selection.json").read_text())["best_iteration"]
    model = lgb.LGBMRegressor(n_estimators=200, learning_rate=.05, num_leaves=31, min_child_samples=20,
                             subsample=.8, subsample_freq=1, colsample_bytree=.8, random_state=seed,
                             deterministic=True, force_col_wise=True, n_jobs=cfg["cpu_threads"], verbosity=-1)
    model.fit(train_arrays["tree"], train_arrays["target_q"].ravel())
    candidates = []
    for iteration in range(20, 201, 20):
        result = simulate_policy(data, cfg, validation, ratio, "LightGBM", gbm=model.booster_, tree_iteration=iteration)
        candidates.append({"iteration": iteration, "validation_cost": result["total_cost"].mean()})
    best = min(candidates, key=lambda r: r["validation_cost"])
    model.booster_.save_model(str(path), num_iteration=best["iteration"])
    write_json(output / "selection.json", {"best_iteration": best["iteration"], "candidates": candidates,
                                           "parameters": model.get_params()})
    return lgb.Booster(model_file=str(path)), best["iteration"]


def run_synthetic(full_cfg, smoke=False):
    cfg = copy.deepcopy(full_cfg["synthetic"])
    output = Path(full_cfg["output_dir"]) / ("synthetic_smoke" if smoke else "synthetic")
    if smoke:
        cfg.update(n_skus=30, seeds=[0], cost_ratios=[9], max_epochs=2, patience=2)
    output.mkdir(parents=True, exist_ok=True)
    if (output / "config.json").exists() and json.loads((output / "config.json").read_text()) != cfg:
        raise ValueError("Output already contains a different synthetic configuration")
    write_json(output / "completion.json", {"complete": False, "smoke": smoke, "stage": "running"})
    write_json(output / "config.json", cfg)
    write_json(output / "environment.json", environment())
    seed_all(cfg["data_seed"], cfg["cpu_threads"])
    data = generate(cfg, output / "data")
    validation, testing = rollout_context(data, cfg, "validation"), rollout_context(data, cfg, "test")
    all_rows, details, selections = [], [], []
    training = {ratio: training_arrays(data, cfg, ratio) for ratio in cfg["cost_ratios"]}
    first = next(iter(training.values()))
    ranges = split_ranges(cfg)
    write_json(output / "leakage_audit.json", {
        "training_decisions": len(first["decision_day"]), "last_training_label_day": int(first["label_last_day"].max()),
        "first_validation_day": ranges["validation"][0], "last_validation_label_day": validation["days"][-1]+cfg["forecast_horizon"]-1,
        "first_test_day": ranges["test"][0], "scale_last_observation_day": cfg["history_days"]-1,
        "test_used_for_selection": False, "feature_future_perturbation_test": "see pytest results"})

    def record(result, ratio, seed, method):
        record_row = {"ratio": ratio, "seed": seed, "method": method}
        for key in ("holding_cost", "stockout_cost", "total_cost", "stockout_ratio", "mean_on_hand"):
            record_row[key] = float(np.mean(result[key]))
        all_rows.append(record_row)
        frame = pd.DataFrame({key: result[key] for key in ("holding_cost", "stockout_cost", "total_cost", "stockout_ratio")})
        frame["sku"] = np.arange(len(frame))
        details.append(frame.assign(ratio=ratio, seed=seed, method=method))
        if seed == cfg["seeds"][0] and ratio == 9:
            np.savez_compressed(output / f"trace_{method}.npz", inventory=result["inventory"][:12], orders=result["orders"][:12])
        pd.DataFrame(all_rows).to_csv(output / "metrics.csv", index=False)

    for seed in cfg["seeds"]:
        forecast_dir = output / "models" / f"seed_{seed}" / "forecast"
        reference_ratio = 9 if 9 in training else cfg["cost_ratios"][-1]
        train_network(data, cfg, training[reference_ratio], validation, seed, reference_ratio, "forecast", forecast_dir)
        for ratio in cfg["cost_ratios"]:
            for base in ("OPT", "Normal", "Gamma"):
                record(simulate_policy(data, cfg, testing, ratio, base), ratio, seed, base)
            forecaster = load_network(forecast_dir / f"best_b{ratio}.pt", cfg)
            val_encoded, test_encoded = encode_context(forecaster, validation), encode_context(forecaster, testing)
            selection, val_costs = select_pto(data, cfg, validation, ratio, val_encoded)
            for method in ("BM1", "BM2"):
                q = selection[method]
                selections.append({"seed": seed, "ratio": ratio, "method": method, "selected_index": q,
                                   "selected_output": cfg["quantiles"][q] if q < 6 else "mean", "validation_cost": val_costs[method]})
                record(simulate_policy(data, cfg, testing, ratio, method, encoded=test_encoded, quantile=q), ratio, seed, method)
            tree_dir = output / "models" / f"seed_{seed}" / f"gbm_b{ratio}"
            tree, iteration = fit_tree(data, cfg, training[ratio], validation, ratio, seed, tree_dir)
            record(simulate_policy(data, cfg, testing, ratio, "LightGBM", gbm=tree, tree_iteration=iteration), ratio, seed, "LightGBM")
            for variant in (["e2e", "no_aux"] if ratio == 9 else ["e2e"]):
                model_dir = output / "models" / f"seed_{seed}" / f"{variant}_b{ratio}"
                train_network(data, cfg, training[ratio], validation, seed, ratio, variant, model_dir)
                model = load_network(model_dir / f"best_b{ratio}.pt", cfg)
                encoded = encode_context(model, testing)
                method = "E2E_no_aux" if variant == "no_aux" else "E2E"
                record(simulate_policy(data, cfg, testing, ratio, method, model=model, encoded=encoded), ratio, seed, method)
            print(f"Evaluation complete: seed={seed}, b/h={ratio}", flush=True)
    metric_frame = pd.DataFrame(all_rows)
    summary = metric_frame.groupby(["ratio", "method"]).agg(
        total_cost_mean=("total_cost", "mean"), total_cost_std=("total_cost", "std"),
        holding_cost_mean=("holding_cost", "mean"), stockout_cost_mean=("stockout_cost", "mean"),
        stockout_ratio_mean=("stockout_ratio", "mean"), seeds=("seed", "count"))
    summary.to_csv(output / "summary.csv")
    detail_frame = pd.concat(details, ignore_index=True)
    detail_frame.to_csv(output / "metrics_per_sku.csv", index=False)
    pd.DataFrame(selections).to_csv(output / "validation_selections.csv", index=False)
    pivot = detail_frame.pivot(index=["ratio", "seed", "sku"], columns="method", values="total_cost")
    gaps = pivot.drop(columns="OPT").subtract(pivot.OPT, axis=0)
    if (gaps < -1e-6).any().any():
        raise AssertionError("A policy beat the clairvoyant optimum; investigate simulation/label consistency")
    write_json(output / "completion.json", {"complete": True, "smoke": smoke, "n_skus": cfg["n_skus"],
                "seeds": cfg["seeds"], "ratios": cfg["cost_ratios"], "rows": len(metric_frame),
                "oracle_lower_bound_per_sku_pass": True,
                "training_run_count": len(list((output / "models").rglob("status.json")))})
    plot_synthetic(output)
    return summary


def plot_synthetic(output):
    output = Path(output)
    frame = pd.read_csv(output / "summary.csv")
    plt = plot_setup()
    ratios = sorted(frame.ratio.unique())
    fig, axes = plt.subplots(1, len(ratios), figsize=(5.3*len(ratios), 4.4), squeeze=False)
    order = ["OPT", "E2E", "BM1", "BM2", "Normal", "Gamma", "LightGBM", "E2E_no_aux"]
    for ax, ratio in zip(axes[0], ratios):
        subset = frame[frame.ratio == ratio].set_index("method").reindex([m for m in order if m in frame[frame.ratio == ratio].method.values])
        colors = ["#777777" if m == "OPT" else "#2878A5" if m.startswith("E2E") else "#B97443" for m in subset.index]
        ax.bar(np.arange(len(subset)), subset.total_cost_mean, yerr=subset.total_cost_std.fillna(0),
               color=colors, edgecolor="black", linewidth=.4, capsize=3)
        ax.set(xticks=np.arange(len(subset)), xticklabels=subset.index, title=f"b/h = {ratio}", ylabel="Mean 30-day cost per SKU")
        ax.tick_params(axis="x", rotation=50)
    fig.suptitle("Synthetic method validation | error bars: SD across training seeds")
    fig.tight_layout()
    save_figure(fig, output / "cost_comparison")
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for path in sorted((output / "models/seed_0").glob("*/training_log.csv")):
        log = pd.read_csv(path)
        key = "validation_cost_b9"
        if key in log:
            ax.plot(log.epoch, log[key], label=path.parent.name)
    ax.set(xlabel="Epoch", ylabel="Validation cost", title="Validation-only checkpoint selection (seed 0)")
    ax.legend(frameon=False)
    save_figure(fig, output / "training_curves")
    plt.close(fig)
