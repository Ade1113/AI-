"""Verify saved results and original-file integrity without retraining."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

from .common import sha256, write_json


def verify(cfg):
    root = Path(cfg["output_dir"])
    stage, syn = root / "stage1", root / "synthetic"
    checks = []

    def check(name, passed, detail=None):
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    manifest = pd.read_csv(stage / "source_manifest.csv")
    check("original_files_unchanged", all(sha256(Path(cfg["source_dir"])/row.file) == row.sha256 for row in manifest.itertuples()), len(manifest))
    comparison = pd.read_csv(stage / "reference_comparison.csv")
    clean = comparison[comparison.reference_kind == "clean_notebook"]
    check("matches_clean_notebooks", len(clean) > 0 and clean["pass"].all(), len(clean))
    discrepancies = comparison.loc[(comparison.reference_kind != "clean_notebook") & ~comparison["pass"]]
    check("cache_discrepancies_disclosed", (stage / "reference_discrepancies.csv").exists(), discrepancies["item"].tolist())
    completion = json.loads((syn / "completion.json").read_text())
    check("full_synthetic_complete", completion["complete"] and not completion["smoke"])
    metrics = pd.read_csv(syn / "metrics.csv")
    expected = []
    for seed in cfg["synthetic"]["seeds"]:
        for ratio in cfg["synthetic"]["cost_ratios"]:
            methods = ["OPT", "Normal", "Gamma", "BM1", "BM2", "LightGBM", "E2E"]
            if ratio == 9:
                methods.append("E2E_no_aux")
            expected += [(ratio, seed, method) for method in methods]
    actual = list(metrics[["ratio", "seed", "method"]].itertuples(index=False, name=None))
    check("all_experiments_exactly_once", sorted(actual) == sorted(expected), len(actual))
    check("metrics_finite", np.isfinite(metrics.select_dtypes("number")).all().all())
    check("total_equals_components", np.allclose(metrics.total_cost, metrics.holding_cost+metrics.stockout_cost, rtol=0, atol=1e-8))
    check("stockout_ratio_bounds", metrics.stockout_ratio.between(0, 1).all())
    detail = pd.read_csv(syn / "metrics_per_sku.csv")
    check("all_skus_evaluated", detail.groupby(["ratio", "seed", "method"]).sku.nunique().eq(cfg["synthetic"]["n_skus"]).all())
    pivot = detail.pivot(index=["ratio", "seed", "sku"], columns="method", values="total_cost")
    check("oracle_lower_bound_per_sku", not (pivot.drop(columns="OPT").subtract(pivot.OPT, axis=0) < -1e-7).any().any())
    statuses = list((syn / "models").rglob("status.json"))
    check("network_tasks_complete", all(json.loads(p.read_text())["complete"] for p in statuses), len(statuses))
    epochs_ok = selection_ok = True
    for path in statuses:
        status = json.loads(path.read_text())
        log = pd.read_csv(path.parent / "training_log.csv")
        epochs_ok &= log.epoch.max() <= cfg["synthetic"]["max_epochs"]
        for ratio, best in status["best"].items():
            selection_ok &= np.isclose(best["cost"], log[f"validation_cost_b{ratio}"].min(), rtol=0, atol=1e-7)
            selection_ok &= (path.parent / f"best_b{ratio}.pt").exists()
    check("epoch_limits_respected", epochs_ok)
    check("validation_checkpoint_selection", selection_ok)
    nb_path = Path(__file__).resolve().parents[1] / "notebooks/复现实验导览.ipynb"
    nb = json.loads(nb_path.read_text())
    code = [cell for cell in nb["cells"] if cell["cell_type"] == "code"]
    check("guide_notebook_executed", all(cell.get("execution_count") is not None for cell in code)
          and not any(out["output_type"] == "error" for cell in code for out in cell.get("outputs", [])))
    result = {"passed": all(c["passed"] for c in checks), "checks": checks,
              "historical_cache_discrepancy_count": len(discrepancies)}
    write_json(root / "verification.json", result)
    print(f"Saved-result verification: {sum(c['passed'] for c in checks)}/{len(checks)} passed", flush=True)
    if not result["passed"]:
        raise AssertionError([c["name"] for c in checks if not c["passed"]])
    return result
