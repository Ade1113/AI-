"""An explicit MQRNN-style reconstruction; original training source unavailable."""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class InventoryNet(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        hidden = cfg["hidden_size"]
        self.quantiles = cfg["quantiles"]
        self.encoder = nn.LSTM(3, hidden, batch_first=True)
        self.global_context = nn.Sequential(nn.Linear(hidden+5, hidden), nn.ReLU())
        # Shared local decoder uses only known future calendar covariates.
        self.daily_decoder = nn.Sequential(nn.Linear(hidden+3, hidden), nn.ReLU(), nn.Linear(hidden, 7))
        self.cumulative_decoder = nn.Sequential(nn.Linear(hidden+3, hidden), nn.ReLU(), nn.Linear(hidden, 7))
        v1, v2 = cfg["vlt_widths"]
        self.vlt_branch = nn.Sequential(nn.Linear(4+5, v1), nn.ReLU(), nn.Dropout(cfg["dropout"]),
                                        nn.Linear(v1, v2), nn.ReLU())
        self.lead_head = nn.Linear(v2, 1)
        a, b = cfg["integration_widths"]
        self.fusion1 = nn.Sequential(nn.Linear(hidden+v2+1, a), nn.ReLU(), nn.Dropout(cfg["dropout"]))
        self.fusion2 = nn.Sequential(nn.Linear(a+1, b), nn.ReLU(), nn.Dropout(cfg["dropout"]))
        self.quantity_head = nn.Linear(b, 1)
        for name, param in self.named_parameters():
            if "weight" in name:
                nn.init.normal_(param, 0, cfg["weight_init_std"])
            else:
                nn.init.zeros_(param)

    def encode(self, seq, basic, vlt, calendar):
        _, (hidden, _) = self.encoder(seq)
        context = self.global_context(torch.cat([hidden[-1], basic], dim=-1))
        local = torch.cat([context[:, None, :].expand(-1, calendar.shape[1], -1), calendar], dim=-1)
        daily = F.softplus(self.daily_decoder(local))
        cumulative = F.softplus(self.cumulative_decoder(local))
        vlt_context = self.vlt_branch(torch.cat([vlt, basic], dim=-1))
        lead = F.softplus(self.lead_head(vlt_context))
        review = torch.ones_like(lead)  # Fixed R=7, normalized by R.
        fused = self.fusion1(torch.cat([context, vlt_context, review], dim=-1))
        return {"fused": fused, "daily": daily, "cumulative": cumulative, "lead": lead}

    def quantity(self, fused, stock):
        return F.softplus(self.quantity_head(self.fusion2(torch.cat([fused, stock], dim=-1))))

    def forward(self, seq, basic, vlt, calendar, stock):
        values = self.encode(seq, basic, vlt, calendar)
        values["quantity"] = self.quantity(values["fused"], stock)
        return values


def forecast_loss(prediction, target, quantiles):
    tau = torch.as_tensor(quantiles, dtype=target.dtype, device=target.device)
    residual = target[..., None] - prediction[..., :len(quantiles)]
    pinball = torch.maximum(tau*residual, (tau-1)*residual).mean()
    mean_mse = F.mse_loss(prediction[..., -1], target)
    return pinball + mean_mse


def losses(outputs, batch, quantiles, auxiliary_weight=.1, forecast_only=False):
    daily = forecast_loss(outputs["daily"], batch["target_daily"], quantiles)
    cumulative = forecast_loss(outputs["cumulative"], batch["target_cumulative"], quantiles)
    lead = F.mse_loss(outputs["lead"], batch["target_lead"])
    decision = F.mse_loss(outputs["quantity"], batch["target_q"])
    demand = (daily+cumulative)/2
    total = demand+lead if forecast_only else decision+auxiliary_weight*(demand+lead)
    return total, {"decision_mse": decision.detach(), "demand_loss": demand.detach(), "lead_mse": lead.detach()}
