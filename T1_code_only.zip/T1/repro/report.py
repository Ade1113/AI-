"""Generate a self-contained Chinese HTML report and an executed reading notebook."""
from __future__ import annotations

import base64
import html
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

import pandas as pd

from .common import ROOT, environment, write_json


def build_report(cfg):
    output = Path(cfg["output_dir"])
    stage1, synthetic = output / "stage1", output / "synthetic"
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)

    def table(path, **kwargs):
        path = Path(path)
        if not path.exists():
            return '<p class="pending">尚未生成：' + html.escape(str(path.name)) + '</p>'
        frame = pd.read_csv(path, **kwargs)
        return '<div class="table-wrap">' + frame.to_html(index=False, border=0, float_format=lambda x: f"{x:.6g}") + '</div>'

    def figure(path, caption):
        path = Path(path)
        if not path.exists():
            return ""
        encoded = base64.b64encode(path.read_bytes()).decode()
        return f'<figure><img src="data:image/png;base64,{encoded}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>'

    checks = pd.read_csv(stage1 / "reference_comparison.csv") if (stage1 / "reference_comparison.csv").exists() else pd.DataFrame()
    complete = json.loads((synthetic / "completion.json").read_text()) if (synthetic / "completion.json").exists() else {"complete": False}
    tests = {"tests": "未执行", "failures": "未知", "errors": "未知"}
    if (output / "tests.xml").exists():
        root = ET.parse(output / "tests.xml").getroot()
        suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
        tests = {k: sum(int(s.attrib.get(k, 0)) for s in suites) for k in ("tests", "failures", "errors")}
    n_pass = int(checks["pass"].sum()) if len(checks) else 0
    clean_checks = checks[checks.reference_kind == "clean_notebook"] if len(checks) else checks
    cached_checks = checks[checks.reference_kind != "clean_notebook"] if len(checks) else checks
    clean_pass = int(clean_checks["pass"].sum()) if len(clean_checks) else 0
    cached_pass = int(cached_checks["pass"].sum()) if len(cached_checks) else 0
    audit = pd.read_csv(stage1 / "author/offline_diagnostics.csv")
    diag = audit.groupby("method")[["negative_order_rounds", "backlog_resets", "index_fallback_rounds", "skipped_days"]].sum().reset_index()
    diag.to_csv(stage1 / "offline_diagnostics_summary.csv", index=False)
    original = pd.read_csv(stage1 / "author/offline_summary.csv").set_index("method")
    e2e, gbm = original.loc["E2E_RNN", "total_cost"], original.loc["gbm", "total_cost"]
    synthetic_interpretation = "合成训练尚未全部完成，不能据此报告最终比较结论。"
    if complete["complete"]:
        summary = pd.read_csv(synthetic / "summary.csv")
        b9 = summary[summary.ratio == 9].set_index("method")
        e, g = b9.loc["E2E", "total_cost_mean"], b9.loc["LightGBM", "total_cost_mean"]
        baseline = b9.drop(index=["OPT", "E2E", "E2E_no_aux"], errors="ignore")["total_cost_mean"].idxmin()
        baseline_cost = b9.loc[baseline, "total_cost_mean"]
        direction = "低" if e < g else "高"
        synthetic_interpretation = (f"默认 b/h=9 时，E2E 平均成本为 {e:.2f}，LightGBM 为 {g:.2f}；"
                                    f"E2E 比 LightGBM {direction} {abs(e/g-1)*100:.2f}%。"
                                    f"该设置下成本最低的可实施比较基准为 {baseline}（{baseline_cost:.2f}）；"
                                    f"E2E 相对它的成本变化为 {(e/baseline_cost-1)*100:+.2f}%。"
                                    "这是所声明合成机制下的实测结果，不代表京东数据表现，也不证明某一模型普遍占优。")
    sections = f"""
<header><p class="eyebrow">T1 · 可重复计算记录</p><h1>端到端库存管理论文复现报告</h1>
<p>A Practical End-to-End Inventory Management Model with Deep Learning · Qi et al., Management Science 69(2), 759–773</p>
<p>DOI：<a href="https://doi.org/10.1287/mnsc.2022.4564">10.1287/mnsc.2022.4564</a> · 本报告不替代原论文。</p></header>
<section><h2>1. 完成状态与材料边界</h2>
<div class="cards"><div><strong>{clean_pass}/{len(clean_checks)}</strong><span>与原源码干净执行一致</span></div>
<div><strong>{cached_pass}/{len(cached_checks)}</strong><span>与历史缓存一致；差异见下文</span></div>
<div><strong>{tests['tests']}</strong><span>自动测试；失败 {tests['failures']}，错误 {tests['errors']}</span></div>
<div><strong>{'已完成' if complete['complete'] else '未完成'}</strong><span>完整合成实验套件</span></div></div>
<p>现有包包含三个检查点 Notebook、九份 CSV 和 README。离线数据为 3,000 条记录、2,607 个唯一 SKU；
现场实验为处理组与对照组前后各 500 条，候选对照 55,333 条。模型原始示例仅含销售 5 行、库存 2 行、交货期 1 行。
未发现作者的训练脚本、模型定义、完整特征处理或模型权重。原始文件通过 SHA-256 校验保持不变。</p>
<p>结果分为：作者公开子样本原口径、论文明确公式的独立对照、合成数据的方法重建。后两类均不冒充原作者训练复现。</p>
{table(stage1 / 'data_audit.csv')}
</section>
<section><h2>2. 作者子样本：离线成本</h2>
<p>独立脚本保留数据行顺序、SKU 分组、取整方式及原库存更新逻辑。三个原 Notebook 的副本也已从干净内核执行，
仅将 pandas 的 <code>drop('y',1)</code> 改为显式 axis 参数，并使用非交互绘图后端。原文件未改动。</p>
<p>E2E_RNN 总成本为 <strong>{e2e:.2f}</strong>，GBM 为 <strong>{gbm:.2f}</strong>，前者低 {(1-e2e/gbm)*100:.2f}%。
这些平均值按公开的 2,607 个 SKU 聚合，不能直接要求与论文全量 24,333 个 SKU 的图 2 数值相同。</p>
{table(stage1 / 'author/offline_summary.csv')}
{figure(stage1 / 'author/offline_costs.png', '公开子样本的作者原口径；OPT 为作者保存的事后最优预测列，并未在该原始仿真下重新证明最优性。')}
<h3>公式对照：Normal 基准</h3>
<p>原代码使用 Z90=1.64，且随机交货期方差项与公式 (7) 不同。独立对照使用 Φ⁻¹(0.9) 和 μ_D²σ_L²，
其余评估逻辑完全保留。BM1/BM2 在公开脚本中将需求预测序列取均值后计算；缺少训练过程，无法验证它们等同于论文所述的全部分位数预测与优化步骤。</p>
{table(stage1 / 'paper_check/offline_summary.csv')}
<h3>原仿真行为诊断</h3>
<p>下表记录负补货量、到货时丢弃负库存、索引回退和跳过的循环日数。作者口径为忠实复算而保留这些行为；
合成仿真采用非负订货与完整延期交货，二者结果不能混用。README 称预测列为补货量，代码却再次减库存，其语义仍待作者说明。</p>
{table(stage1 / 'offline_diagnostics_summary.csv')}
</section>
<section><h2>3. 现场实验：统计复算及口径对照</h2>
<p>原口径 h=1、b=9；论文现场实验记载 h=12、b=88。对照组和处理组的匿名 ID 各自从 0 开始，
仅用于组内前后对齐，不视为跨组全局 ID。</p>
<h3>作者口径的两样本 t 检验</h3>{table(stage1 / 'author/field_ttests.csv')}
<h3>作者口径的无截距回归</h3>{table(stage1 / 'author/field_regression.csv')}
<p>尤其注意：公开子样本的周转指标回归系数约 +0.346，p≈0.770，并不显著。不能把论文全量样本“所有指标显著改善”的结论直接照搬到这里。</p>
{figure(stage1 / 'author/field_pre_post.png', '公开子样本的前后期比较；连线用于呈现均值，不是平行趋势检验。')}
<h3>论文参数与含截距回归</h3>{table(stage1 / 'paper_check/field_regression.csv')}
<h3>双重差分</h3>{table(stage1 / 'author/field_did.csv')}
<p><strong>历史缓存差异：</strong>作者 Notebook 保存的五项 DiD 检验 t 值和 p 值与干净重跑不同，共十个数值。
独立实现与原 Notebook 的本次干净执行一致。组均值一致而差值检验不同，不能用浮点舍入解释；
现有材料不足以唯一确定原缓存的历史内核状态或跨组行配对。下面保留两组结果，不修改算法去强行匹配旧缓存。</p>
{table(stage1 / 'reference_discrepancies.csv')}
<p>author_p 为原脚本按行跨组相减、再对前后差值做独立 t 检验的结果；clustered_p 为
组别、时期、交互项回归，标准误按“组别:ID”聚类。保留原代码对对照组后期周转值未截断的细节。
当前仅有两期，无法验证平行趋势，也不能排除选择偏差和同期冲击。</p>
<p>所有主表保留作者对 inv[:-1] 计费、缺货天数却除以 len(inv) 的约定。
field_panel.csv 同时提供记录天数、计费天数、需求长度与使用计费天数分母的诊断值；没有逐日时间锚点时不擅自解释或修正。</p>
</section>
<section><h2>4. 匹配复算</h2>
<p>原实现拟合逻辑回归展示倾向得分，但最近邻使用未经标准化的需求、交货期及组别常数列。
独立对照改为按拟合倾向得分一对一、有放回匹配。分布相近不等于识别无偏的因果效应；协变量是否为处理前测量仍需原始业务说明。</p>
{table(stage1 / 'matching/matching_reuse.csv')}
{table(stage1 / 'matching/matching_balance.csv')}
{figure(stage1 / 'matching/matching_distributions.png', '匹配前、作者特征距离匹配后、倾向得分距离匹配后的分布。')}
<p>候选池未附完整库存结果和可靠的跨文件匿名映射，因此没有将重新匹配的样本替换进入现场实验成本与双重差分。</p>
</section>
<section><h2>5. 合成数据方法验证</h2>
<p>{html.escape(synthetic_interpretation)}</p>
<p>完整设置：1,000 个 SKU、随机种子 2026，平稳、周周期与间歇性需求；供应商分为短交期 1–3 天与长交期 4–6 天两组，
每 7 天审查一次，无订单交叉。180 天历史、90 天训练、30 天验证、30 天测试，集合间各隔离 31 天，末尾再留 31 天标签缓冲。
需求模块输入最近 56 天；尺度仅由训练开始前的 180 天计算。</p>
<p>训练状态按 -7、0、7、14 倍历史日均需求轮换，每个 SKU/审查日生成一个监督样本；测试从零库存开始。
真实未来值只用于训练标签和 OPT，其他策略只能访问决策日前历史、已实现的历史交货期、当前库存、静态类别和已知日历。
所有测试策略共享完全相同的需求、实际交货期和初始状态。</p>
<p>重建采用 LSTM 编码器与共享多跨度分位数解码器，另设累计需求分位数预测头供 BM1 使用，不能以逐日分位数之和代替总量分位数。
需求隐藏维度 50；交货期层宽 50/20；融合层宽 100/100；Dropout 0.2。补货量、交货期为均方误差，需求为分位数损失加均值输出的均方误差。
这些实现细节及 Softplus 非负输出均是明确声明的重建选择，并非已找回的作者源码。</p>
<p>优化器为 SGD（学习率 0.001、动量 0.85），按 epoch 使用 1/(1+10⁻⁴·epoch) 衰减，梯度范数裁剪 10。
上限 100 轮、耐心 10 轮，按验证库存成本选模型；PTO 的六个分位数及均值也仅在验证集选择。
每个种子的预测模型训练一次，按 b/h 分别保存最佳验证 checkpoint；LightGBM 以 20 棵树为步长在 20–200 棵内按验证库存成本选择。</p>
<p>训练种子为 0、1、2；成本比例为 1、4、9；比例改变时重新生成最优标签并训练 E2E 与 LightGBM。
默认比例 9 另训练取消两个辅助损失的消融模型。图中误差条仅表示三个训练种子之间的标准差，不是不同数据生成机制下的置信区间。</p>
<p>本次默认比例下，有无辅助损失的成本均值非常接近，不能据此声称辅助损失带来明确成本改善。
这也说明：运行流程通过验证与重现论文的性能优势，是两种不同的结论。</p>
{table(synthetic / 'summary.csv')}
{figure(synthetic / 'cost_comparison.png', '合成方法验证：相同物理环境下的成本比较；不将胜过某一基准作为验收条件。')}
{figure(synthetic / 'training_curves.png', '种子 0 的验证成本及模型选择过程。')}
</section>
<section><h2>6. 验证证据与复跑入口</h2>
<p>自动测试涵盖最优标签与独立枚举、零需求、过量库存、缺货累计、到货日、期末截断、无交叉约束、
原代码的负订单与负库存重置、未来数据扰动不改变特征、标签窗口不跨集合，以及模型权重保存和恢复。</p>
<p>完整合成套件逐 SKU 检查所有策略成本不低于同一仿真下的事后最优成本。每个训练任务保存日志、最佳权重、参数和状态。
独立实现与原 Notebook 干净执行一致说明公开评估流程已复算；历史缓存另作差异记录，不等于论文全量训练已被独立重现。</p>
<p>另在新 Python 进程中重新加载全部权重评估，34 个数值结果及权重文件的 SHA-256 均与第一次完整运行相同。
证据见 results/synthetic/replay_verification.json。HTML 结构与导览 Notebook 已检查、图表文件已目视检查；浏览器工具不允许本地文件 URL 预览。</p>
<pre>.venv/bin/python -m pytest -q --junitxml=results/tests.xml
.venv/bin/python -m repro author
.venv/bin/python -m repro synthetic
.venv/bin/python -m repro report</pre>
<p>配置见 config.json；直接依赖见 requirements.txt；完整已安装依赖见 requirements.lock.txt；
原文件摘要见 results/stage1/source_manifest.csv；逐项对照见 results/stage1/reference_comparison.csv。
详细阅读 Notebook 位于 notebooks/复现实验导览.ipynb。</p>
</section>"""
    css = """body{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Noto Sans CJK SC',sans-serif;color:#243341;background:#f4f6f8;margin:0;line-height:1.75}
main{max-width:1120px;margin:40px auto;padding:0 24px}header,section{background:white;padding:28px 36px;margin-bottom:20px;border-radius:12px;border:1px solid #dce2e8}
h1{font-size:30px;line-height:1.35}h2{font-size:22px;border-bottom:2px solid #d5e6ee;padding-bottom:8px}h3{font-size:17px}.eyebrow{color:#2878A5;font-weight:700;letter-spacing:2px}
.cards{display:flex;gap:16px}.cards>div{flex:1;background:#eff6fa;padding:16px;border-radius:8px}.cards strong{display:block;font-size:25px;color:#20668b}.cards span{font-size:13px}
.table-wrap{overflow:auto;margin:20px 0}table{border-collapse:collapse;font-size:12px;min-width:80%}th,td{padding:8px 10px;border-bottom:1px solid #dbe3e8;text-align:right;white-space:nowrap}th{background:#ecf2f6}td:first-child,th:first-child{text-align:left}
figure{margin:20px 0}img{width:100%;height:auto}figcaption{color:#627584;font-size:13px}pre{overflow:auto;padding:18px;background:#132d3d;color:#e7f0f6;border-radius:8px;font-size:13px}a{color:#216f9a}.pending{color:#98691d}
@media print{body{background:white}main{margin:0;max-width:none}header,section{border:0;border-radius:0;padding:12px}h2{break-after:avoid}.table-wrap{overflow:visible}figure,table{break-inside:avoid}}"""
    document = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>T1 论文复现报告</title><style>' + css + '</style><main>' + sections + '</main></html>'
    (reports / "复现报告.html").write_text(document)
    build_notebook(cfg)
    write_json(reports / "report_status.json", {"stage1_checks": len(checks), "stage1_passed": n_pass,
                "tests": tests, "synthetic_complete": complete["complete"], "environment": environment()})
    print(f"Report: {reports / '复现报告.html'}", flush=True)


def build_notebook(cfg):
    import nbformat
    from nbclient import NotebookClient
    notebook_dir = ROOT / "notebooks"
    notebook_dir.mkdir(exist_ok=True)
    nb = nbformat.v4.new_notebook()
    nb.metadata.kernelspec = {"display_name": "Python 3.11 (T1)", "language": "python", "name": "python3"}
    relative_results = repr(os.path.relpath(cfg["output_dir"], ROOT))
    nb.cells = [nbformat.v4.new_markdown_cell("# T1 复现实验导览\n\n本 Notebook 读取独立脚本已生成的结果，不依赖手工执行顺序。\n\n**三种证据分别呈现：作者子样本复算、论文口径对照、合成方法验证。**"),
                nbformat.v4.new_code_cell("from pathlib import Path\nimport json\nimport pandas as pd\nfrom IPython.display import display, Image\nROOT = Path.cwd()\nif not (ROOT / 'config.json').exists():\n    ROOT = ROOT.parent\nR = ROOT / " + relative_results),
                nbformat.v4.new_markdown_cell("## 公开子样本与缓存核对\n3,000 条记录，2,607 个唯一 SKU。"),
                nbformat.v4.new_code_cell("display(pd.read_csv(R/'stage1/author/offline_summary.csv'))\nc = pd.read_csv(R/'stage1/reference_comparison.csv')\ndisplay(c.groupby(['reference_kind','pass']).size().rename('count').reset_index())\ndisplay(Image(filename=str(R/'stage1/author/offline_costs.png')))"),
                nbformat.v4.new_markdown_cell("## 现场实验与回归\n公开子样本不保证重现全量样本的全部统计显著性。周转回归尤其需要独立解释。"),
                nbformat.v4.new_code_cell("display(pd.read_csv(R/'stage1/author/field_ttests.csv'))\ndisplay(pd.read_csv(R/'stage1/author/field_regression.csv'))\ndisplay(pd.read_csv(R/'stage1/paper_check/field_regression.csv'))\ndisplay(pd.read_csv(R/'stage1/author/field_did.csv'))"),
                nbformat.v4.new_markdown_cell("## 匹配诊断\n有放回匹配允许复用对照样本；不将其视为 500 个独立对照个体。"),
                nbformat.v4.new_code_cell("display(pd.read_csv(R/'stage1/matching/matching_balance.csv'))\ndisplay(pd.read_csv(R/'stage1/matching/matching_reuse.csv'))\ndisplay(Image(filename=str(R/'stage1/matching/matching_distributions.png')))"),
                nbformat.v4.new_markdown_cell("## 合成数据方法验证\n合成数据不能替代作者真实数据的训练复现。模型与分位数只在验证集选择。"),
                nbformat.v4.new_code_cell("if (R/'synthetic/completion.json').exists() and json.loads((R/'synthetic/completion.json').read_text()).get('complete'):\n    display(pd.read_csv(R/'synthetic/summary.csv'))\n    display(Image(filename=str(R/'synthetic/cost_comparison.png')))\n    display(Image(filename=str(R/'synthetic/training_curves.png')))\nelse:\n    print('完整合成实验尚未完成。')"),
                nbformat.v4.new_markdown_cell("## 继续阅读\n\n- `../reports/复现报告.html`：完整中文报告。\n- `../README.md`：环境、复跑命令与目录说明。\n- `../results/stage1/notebooks/`：原 Notebook 的独立执行副本。\n- `../results/synthetic/models/`：每个种子/比例的模型与训练日志。")]
    NotebookClient(nb, timeout=180, kernel_name="python3", resources={"metadata": {"path": str(ROOT)}}).execute()
    nbformat.write(nb, notebook_dir / "复现实验导览.ipynb")
