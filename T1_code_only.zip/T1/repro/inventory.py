"""Daily arrivals precede demand; orders have no fixed costs or capacity limit.

Theorem 1 applies only to nonnegative demand, backordering, and noncrossing
arrivals. Oracle information is isolated here and never exposed to a policy.
"""
from __future__ import annotations

import itertools
import numpy as np


def optimal_quantity(demand_between_arrivals, arrival_inventory, h=1.0, b=9.0):
    demand = np.asarray(demand_between_arrivals, dtype=float)
    if h <= 0 or b <= 0 or (demand < 0).any() or not np.isfinite(demand).all():
        raise ValueError("Positive costs and finite nonnegative demands are required")
    if demand.size == 0:
        return 0.0
    # Zero-based version of s* = floor(b*(v_next-v)/(h+b)) + v.
    index = min(int(np.floor(b * demand.size / (h + b))), demand.size - 1)
    return max(float(demand[:index + 1].sum() - arrival_inventory), 0.0)


def oracle_orders(demand, order_days, leads, initial_inventory=0.0, h=1.0, b=9.0):
    demand = np.asarray(demand, dtype=float)
    days, leads = np.asarray(order_days, int), np.asarray(leads, int)
    arrivals = days + leads
    if len(days) != len(leads) or (leads < 1).any() or (np.diff(arrivals) <= 0).any():
        raise ValueError("Orders must have positive lead times and strictly increasing arrivals")
    quantities = []
    accumulated_orders = 0.0
    for i, arrival in enumerate(arrivals):
        if arrival >= len(demand):
            quantities.append(0.0)
            continue
        next_arrival = min(arrivals[i+1] if i+1 < len(arrivals) else len(demand), len(demand))
        stock = initial_inventory + accumulated_orders - demand[:arrival].sum()
        q = optimal_quantity(demand[arrival:next_arrival], stock, h, b)
        quantities.append(q)
        accumulated_orders += q
    return np.asarray(quantities)


def simulate_fixed(demand, order_days, leads, quantities, initial_inventory=0.0, h=1.0, b=9.0):
    demand = np.asarray(demand, float)
    if (demand < 0).any() or not np.isfinite(demand).all():
        raise ValueError("Demand must be finite and nonnegative")
    days, leads, quantities = np.asarray(order_days, int), np.asarray(leads, int), np.asarray(quantities, float)
    if not (len(days) == len(leads) == len(quantities)) or (quantities < 0).any():
        raise ValueError("Invalid order schedule or negative quantity")
    arrivals = np.zeros(len(demand))
    for day, lead, q in zip(days, leads, quantities):
        if lead < 1 or day < 0:
            raise ValueError("Invalid order day or lead time")
        if day + lead < len(demand):
            arrivals[day + lead] += q
    end_inventory = initial_inventory + np.cumsum(arrivals - demand)
    holding = h * np.maximum(end_inventory, 0).sum()
    shortage = b * np.maximum(-end_inventory, 0).sum()
    return {"inventory": end_inventory, "arrivals": arrivals, "holding_cost": holding,
            "stockout_cost": shortage, "total_cost": holding + shortage}


def enumerate_optimum(demand, order_days, leads, initial_inventory=0.0, h=1.0, b=9.0):
    """Independent exhaustive verifier for tiny integer fixtures, not a labeler."""
    bound = int(np.ceil(np.sum(demand) + max(-initial_inventory, 0)))
    best, best_q = float("inf"), None
    for quantities in itertools.product(range(bound + 1), repeat=len(order_days)):
        result = simulate_fixed(demand, order_days, leads, quantities, initial_inventory, h, b)
        if result["total_cost"] < best:
            best, best_q = result["total_cost"], quantities
    return best, best_q
