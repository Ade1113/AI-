"""Faithful public-subsample evaluation and separately labelled paper checks."""
from __future__ import annotations

import json
import re
import shutil
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors
import statsmodels.api as sm

from .common import environment, parse_array, plot_setup, save_figure, sha256, write_json

METHODS = ["OPT", "E2E_RNN", "Bm1", "Bm2", "Normal", "Gamma", "gbm"]
METRICS = ["holding_cost", "stockout_cost", "total_cost", "turnover", "stockout_ratio"]
NOTEBOOKS = {"offline": "E2E_Section4-checkpoint.ipynb",
             "field": "Field_experiments_summary 2-checkpoint.ipynb",
             "matching": "Propensity_score_matching 2-checkpoint.ipynb"}


def audit_sources(source, output):
    source, output = Path(source), Path(output)
    rows = []
    for path in sorted(source.rglob("*")):
        if path.is_file() and path.name != ".DS_Store":
            rows.append({"file": str(path.relative_to(source)), "bytes": path.stat().st_size,
                         "sha256": sha256(path)})
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / "source_manifest.csv", index=False)
    audits = []
    for path in sorted(source.rglob("*.csv")):
        frame = pd.read_csv(path)
        row = {"file": str(path.relative_to(source)), "rows": len(frame),
               "columns": len(frame.columns), "missing_cells": int(frame.isna().sum().sum())}
        for key in ("SKU", "sku_dc_pair_index"):
            if key in frame:
                row["unique_id_count"] = frame[key].nunique()
        for col in ("sf_rnn", "demand_hist", "test_inv", "test_demand"):
            if col in frame:
                lengths = frame[col].map(parse_array).map(len)
                row[col + "_min_length"] = lengths.min()
                row[col + "_max_length"] = lengths.max()
        audits.append(row)
    pd.DataFrame(audits).to_csv(output / "data_audit.csv", index=False)
    write_json(output / "environment.json", environment())
    return rows


def author_inventory(x, method):
    """Preserve the original loop, including negative orders and backlog reset.

    Extra trace fields do not affect the computation. Only inv2 is costed by
    the author. Record order and within-SKU row sequence are not re-sorted.
    """
    inv1, inv2, trace = [x["initial_stock"][0]], [], []
    rounds = len(x["OPT_pred"])
    for r in range(rounds):
        length = len(x["demand_hist"][r]) - (1 if r < rounds - 1 else 0)
        lead = int(round(x["vlt"][r]))
        fallback = False
        for t in range(length):
            if t == 0:
                if r == 0:
                    replen = int(round(x[method + "_pred"][r] - inv1[0]))
                else:
                    try:
                        replen = int(round(x[method + "_pred"][r] - inv1[-lead-1]))
                    except IndexError:
                        replen = int(round(x[method + "_pred"][r] - inv1[1]))
                        fallback = True
            before = inv1[-1]
            recorded, costed, reset = False, False, False
            if t < lead:
                if r == 0:
                    inv1.append(inv1[-1] - x["demand_hist"][r][t])
                    recorded = True
            elif t == lead:
                reset = inv1[-1] < 0
                after = (inv1[-1] if not reset else 0) + replen - x["demand_hist"][r][t]
                inv1.append(after)
                inv2.append(after)
                recorded = costed = True
            else:
                after = inv1[-1] - x["demand_hist"][r][t]
                inv1.append(after)
                inv2.append(after)
                recorded = costed = True
            trace.append({"round": r, "offset": t, "lead_rounded": lead,
                          "demand": x["demand_hist"][r][t], "inventory_before": before,
                          "inventory_after": inv1[-1], "replenishment": replen,
                          "recorded": recorded, "costed": costed,
                          "backlog_reset": reset, "fallback_index": fallback})
    return np.array(inv1[1:]), np.array(inv2), trace


def offline(source, output, track="author"):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(Path(source) / "df_test.csv")
    for col in ("sf_rnn", "demand_hist"):
        frame[col] = frame[col].map(parse_array)
    forecast_mean = frame.sf_rnn.map(np.mean)
    frame["Bm1_pred"] = forecast_mean * (frame.review_period + frame.vlt).astype(int)
    days = frame.review_period + frame.vlt
    frame["Bm2_pred"] = forecast_mean * np.where(days <= 9, days.astype(int), days.astype(int) - days // 10)
    if track == "author":
        z = 1.64
        variance = ((frame.review_period + frame.vendor_vlt_mean) * frame.demand_std ** 2
                    + frame.demand_std ** 2 * frame.vendor_vlt_std)
    else:
        z = stats.norm.ppf(0.9)
        variance = ((frame.review_period + frame.vendor_vlt_mean) * frame.demand_std ** 2
                    + frame.demand_mean ** 2 * frame.vendor_vlt_std ** 2)
    frame["Normal_pred"] = (frame.demand_mean * (frame.review_period + frame.vendor_vlt_mean)
                            + z * np.sqrt(variance)).astype(int)
    theta = frame.demand_std ** 2 / (frame.demand_mean + 1e-4)
    shape = frame.demand_mean / (theta + 1e-4)
    gamma_q = stats.gamma.ppf(0.9, a=(frame.review_period + frame.vendor_vlt_mean).astype(int) * shape,
                             scale=theta)
    frame["Gamma_pred"] = np.nan_to_num(gamma_q, nan=0).astype(int)
    grouped = frame.groupby("SKU").agg(lambda x: x.tolist())
    results, traces, diagnostics = [], [], []
    for sku, row in grouped.iterrows():
        for method in METHODS:
            _, inventory, trace = author_inventory(row, method)
            holding = sum(v for v in inventory if v > 0)
            shortage = -9 * sum(v for v in inventory if v < 0)
            results.append({"SKU": sku, "method": method, "holding_cost": holding,
                            "stockout_cost": shortage, "total_cost": holding + shortage,
                            "costed_days": len(inventory)})
            trace_frame = pd.DataFrame(trace)
            if len(trace_frame):
                diagnostics.append({"SKU": sku, "method": method,
                                    "negative_order_rounds": trace_frame.loc[trace_frame.offset == 0, "replenishment"].lt(0).sum(),
                                    "backlog_resets": trace_frame.backlog_reset.sum(),
                                    "index_fallback_rounds": trace_frame.loc[trace_frame.offset == 0, "fallback_index"].sum(),
                                    "skipped_days": (~trace_frame.recorded).sum()})
                # Keep all order boundaries and 12 complete SKU trajectories for inspection.
                if len(traces) < 12 * len(METHODS) or trace_frame.replenishment.lt(0).any():
                    traces.append(trace_frame.assign(SKU=sku, method=method))
    detail = pd.DataFrame(results)
    detail.to_csv(output / "offline_per_sku.csv", index=False)
    summary = detail.groupby("method")[["holding_cost", "stockout_cost", "total_cost"]].mean().reindex(METHODS)
    summary.to_csv(output / "offline_summary.csv")
    pd.DataFrame(diagnostics).to_csv(output / "offline_diagnostics.csv", index=False)
    if traces:
        pd.concat(traces, ignore_index=True).to_csv(output / "offline_trace_examples.csv", index=False)
    write_json(output / "offline_scope.json", {
        "records": len(frame), "unique_SKUs": len(grouped), "track": track,
        "h": 1, "b": 9, "normal_z": z,
        "only_change_in_paper_check": "Normal baseline equation 7; other author semantics retained",
        "not_recreated": ["training", "full-cohort Figure 2", "BM1 aggregate quantile training",
                          "BM2 daily forecast optimization"],
        "saved_prediction_semantics": "Author subtracts inventory from *_pred; README calls them quantities. Unresolved."
    })
    plt = plot_setup()
    fig, ax = plt.subplots(figsize=(10, 4.5))
    x = np.arange(len(summary))
    ax.bar(x, summary.holding_cost, label="Holding cost", color="#72A8C8", edgecolor="black", linewidth=.4)
    ax.bar(x, summary.stockout_cost, bottom=summary.holding_cost, label="Stockout cost",
           color="#D9A06F", edgecolor="black", linewidth=.4, hatch="//")
    ax.set(xticks=x, xticklabels=summary.index, ylabel="Mean cost per disclosed SKU",
           title=f"Public subsample: 2,607 SKUs | {track}")
    ax.legend(frameon=False)
    save_figure(fig, output / "offline_costs")
    plt.close(fig)
    return summary


def field_metrics(frame, h, b):
    rows = []
    for _, row in frame.iterrows():
        inv, demand = parse_array(row.test_inv), parse_array(row.test_demand)
        costed = inv[:-1]  # Intentionally preserve author endpoint convention.
        holding = h * np.maximum(costed, 0).sum()
        shortage = b * np.maximum(-costed, 0).sum()
        if row.ave_demand <= 0 or len(inv) == 0:
            raise ValueError("Invalid mean demand or empty field inventory")
        rows.append({"id": int(row.sku_dc_pair_index), "holding_cost": holding,
                     "stockout_cost": shortage, "total_cost": holding + shortage,
                     "turnover": max(0, row.ave_inv / row.ave_demand),
                     "turnover_raw": row.ave_inv / row.ave_demand,
                     "stockout_ratio": (costed < 0).sum() / len(inv),
                     "stockout_ratio_costed_denominator": (costed < 0).mean() if len(costed) else np.nan,
                     "recorded_days": len(inv), "costed_days": len(costed), "demand_days": len(demand),
                     "ave_demand": row.ave_demand, "vlt": int(str(row.vlt).split()[0])})
    return pd.DataFrame(rows).set_index("id").sort_index()


def field(source, output, track="author"):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    h, b = (1, 9) if track == "author" else (12, 88)
    frames = {}
    for group, file_group in ((1, "e2e"), (0, "jd")):
        for post, phase in ((0, "pre"), (1, "post")):
            frame = pd.read_csv(Path(source) / f"order_{file_group}_{phase}_500.csv")
            if not frame.sku_dc_pair_index.is_unique:
                raise ValueError("Duplicate within-group IDs")
            frames[group, post] = field_metrics(frame, h, b)
        if not frames[group, 0].index.equals(frames[group, 1].index):
            raise ValueError("Pre/post IDs do not match within group")
    panel = pd.concat([frame.assign(group=group, post=post).reset_index()
                       for (group, post), frame in frames.items()], ignore_index=True)
    panel["unit"] = panel.group.astype(str) + ":" + panel.id.astype(str)
    panel["interaction"] = panel.group * panel.post
    panel.to_csv(output / "field_panel.csv", index=False)
    summary = panel.groupby(["group", "post"])[METRICS].mean()
    summary.to_csv(output / "field_summary.csv")
    tests, regressions, did_rows = [], [], []
    for metric in METRICS:
        a, c = frames[1, 1][metric].to_numpy(), frames[0, 1][metric].to_numpy()
        t, p = stats.ttest_ind(a, c, equal_var=True)
        pooled = ((len(a)-1)*np.var(a, ddof=1)+(len(c)-1)*np.var(c, ddof=1))/(len(a)+len(c)-2)
        se = np.sqrt(pooled*(1/len(a)+1/len(c)))
        half = stats.t.ppf(.975, len(a)+len(c)-2)*se
        tests.append({"metric": metric, "treatment": a.mean(), "control": c.mean(),
                      "difference": a.mean()-c.mean(), "relative_difference": a.mean()/c.mean()-1,
                      "t": t, "p": p, "ci_low": a.mean()-c.mean()-half, "ci_high": a.mean()-c.mean()+half})
        post_panel = panel.loc[panel.post == 1]
        X = post_panel[["group", "vlt", "ave_demand"]]
        if track != "author":
            X = sm.add_constant(X)
        fit = sm.OLS(post_panel[metric], X).fit()
        ci = fit.conf_int().loc["group"]
        regressions.append({"metric": metric, "coefficient": fit.params["group"], "p": fit.pvalues["group"],
                            "ci_low": ci.iloc[0], "ci_high": ci.iloc[1], "intercept": track != "author"})
        # Author's DiD test subtracts paired row positions across groups, then
        # runs an independent t test across periods. Preserve the raw post-JD turnover.
        control_post_metric = "turnover_raw" if metric == "turnover" else metric
        post_delta = frames[1, 1][metric].to_numpy() - frames[0, 1][control_post_metric].to_numpy()
        pre_delta = frames[1, 0][metric].to_numpy() - frames[0, 0][metric].to_numpy()
        td, pdid = stats.ttest_ind(post_delta, pre_delta, equal_var=True)
        Xdid = sm.add_constant(panel[["group", "post", "interaction"]])
        fitdid = sm.OLS(panel[metric], Xdid).fit(cov_type="cluster", cov_kwds={"groups": panel.unit})
        ci = fitdid.conf_int().loc["interaction"]
        did_rows.append({"metric": metric, "author_difference": post_delta.mean()-pre_delta.mean(),
                         "author_t": td, "author_p": pdid, "regression_did": fitdid.params["interaction"],
                         "clustered_p": fitdid.pvalues["interaction"], "ci_low": ci.iloc[0], "ci_high": ci.iloc[1]})
    pd.DataFrame(tests).to_csv(output / "field_ttests.csv", index=False)
    pd.DataFrame(regressions).to_csv(output / "field_regression.csv", index=False)
    pd.DataFrame(did_rows).to_csv(output / "field_did.csv", index=False)
    write_json(output / "field_scope.json", {"track": track, "h": h, "b": b,
               "n_per_group_period": 500, "endpoint_rule": "cost inv[:-1]; author stockout denominator len(inv)",
               "within_group_ids_aligned": True, "cross_group_IDs_are_not_global_identifiers": True,
               "regression_did_covariance": "cluster by group:id",
               "limitations": ["No daily time anchors to resolve all endpoint semantics", "Two periods cannot test parallel trends",
                               "Matching covariates may be post-treatment", "Public subsample is not the paper full cohort"]})
    plt = plot_setup()
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.7))
    for ax, metric in zip(axes, ["total_cost", "turnover", "stockout_ratio"]):
        for group, label, color in [(1, "Treatment", "#2878A5"), (0, "Control", "#B97443")]:
            y = [frames[group, phase][metric].mean() for phase in (0, 1)]
            ax.plot([0, 1], y, "o-", label=label, color=color)
        ax.set(xticks=[0, 1], xticklabels=["Pre", "Post"], title=metric.replace("_", " "))
    axes[0].legend(frameon=False)
    fig.suptitle(f"Disclosed 500 units per group | {track}: h={h}, b={b}")
    fig.tight_layout()
    save_figure(fig, output / "field_pre_post")
    plt.close(fig)
    return summary


def matching(source, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    treated = pd.read_csv(Path(source) / "order_e2e_post_500.csv")
    candidate = pd.read_csv(Path(source) / "control_demand_vlt.csv")
    treated["vlt_num"] = treated.vlt.map(lambda x: int(str(x).split()[0]))
    cols = ["ave_demand", "vlt_num"]
    tx, cx = treated[cols].copy(), candidate[cols].copy()
    X = pd.concat([tx, cx], ignore_index=True)
    labels = np.r_[np.ones(len(tx)), np.zeros(len(cx))]
    with warnings.catch_warnings(record=True) as caught:
        model = LogisticRegression().fit(X, labels)
    ps = model.predict_proba(X)[:, 1]
    tp, cp = ps[:len(tx)], ps[len(tx):]
    # The original passes e2e as a third matching feature. Its constant 1-versus-0
    # difference contributes equally to each candidate distance.
    raw_t, raw_c = tx.assign(e2e=1), cx.assign(e2e=0)
    raw_distance, raw_idx = NearestNeighbors(n_neighbors=1).fit(raw_c).kneighbors(raw_t)
    score_distance, score_idx = NearestNeighbors(n_neighbors=1).fit(cp[:, None]).kneighbors(tp[:, None])
    indices = {"author_features": raw_idx.ravel(), "propensity_score": score_idx.ravel()}
    balance, duplicates = [], []
    for name, idx in {"before": np.arange(len(cx)), **indices}.items():
        for col in cols:
            scale = np.sqrt((tx[col].var(ddof=1) + cx[col].var(ddof=1))/2)
            balance.append({"method": name, "covariate": col, "treated_mean": tx[col].mean(),
                            "control_mean": cx.iloc[idx][col].mean(),
                            "smd": (tx[col].mean()-cx.iloc[idx][col].mean())/scale})
        duplicates.append({"method": name, "matched_rows": len(idx), "unique_control_rows": len(np.unique(idx)),
                           "reused_rows": len(idx)-len(np.unique(idx))})
    for name, idx in indices.items():
        pd.DataFrame({"treatment_row": np.arange(len(tx)), "candidate_row": idx,
                      "treatment_score": tp, "control_score": cp[idx],
                      "score_distance": np.abs(tp-cp[idx])}).to_csv(output / f"matches_{name}.csv", index=False)
    pd.DataFrame(balance).to_csv(output / "matching_balance.csv", index=False)
    pd.DataFrame(duplicates).to_csv(output / "matching_reuse.csv", index=False)
    write_json(output / "matching_scope.json", {"n_treatment": len(tx), "n_candidate": len(cx),
               "with_replacement": True, "standardization": False, "warnings": [str(w.message) for w in caught],
               "used_to_replace_field_controls": False, "reason": "Candidate outcomes and verified cross-file ID mapping unavailable",
               "fitted_coefficients": model.coef_, "intercept": model.intercept_})
    plt = plot_setup()
    fig, axes = plt.subplots(1, 3, figsize=(14, 3.7))
    for ax, (name, idx) in zip(axes, {"Before": np.arange(len(cx)), **indices}.items()):
        bins = np.linspace(min(tp.min(), cp[idx].min()), max(tp.max(), cp[idx].max()) + 1e-12, 21)
        ax.hist(tp, bins=bins, density=True, alpha=.6, label="Treatment", color="#2878A5")
        ax.hist(cp[idx], bins=bins, density=True, alpha=.5, label="Control", color="#B97443")
        ax.set(title=name.replace("_", " "), xlabel="Estimated propensity", ylabel="Density")
    axes[0].legend(frameon=False)
    fig.tight_layout()
    save_figure(fig, output / "matching_distributions")
    plt.close(fig)


def execute_notebooks(source, output):
    """Execute copies in isolated directories; never change source notebooks/CSVs."""
    import nbformat
    from nbclient import NotebookClient
    source, output = Path(source), Path(output)
    executed = {}
    for kind, filename in NOTEBOOKS.items():
        work = output / kind
        work.mkdir(parents=True, exist_ok=True)
        for csv in source.glob("*.csv"):
            dest = work / csv.name
            if not dest.exists():
                dest.symlink_to(csv.resolve())
        nb = nbformat.read(source / ".ipynb_checkpoints" / filename, as_version=4)
        adaptations = []
        for cell in nb.cells:
            if cell.cell_type == "code":
                old = cell.source
                cell.source = re.sub(r"\.drop\('y',\s*1\)", ".drop('y', axis=1)", old)
                if old != cell.source:
                    adaptations.append("pandas drop axis keyword; no numerical change")
        nb.cells.insert(0, nbformat.v4.new_code_cell("import matplotlib\nmatplotlib.use('Agg')"))
        if kind == "offline":
            export = "df_aggcom.to_csv('executed_offline_summary.csv')"
        elif kind == "field":
            export = """import json
from pathlib import Path
payload = {'post_e2e': [list(x) for x in post_exp_e2e], 'post_jd': [list(x) for x in post_exp_jd],
           'pre_e2e': [e2e_holding_cost, e2e_stockout_cost, e2e_total_cost, e2e_turnover1, e2e_stockout_ratio],
           'pre_jd': [jd_holding_cost, jd_stockout_cost, jd_total_cost, jd_turnover1, jd_stockout_ratio]}
Path('executed_field_arrays.json').write_text(json.dumps(payload))"""
        else:
            export = "np.savetxt('executed_match_indices.csv', matched_idx, fmt='%d', delimiter=',')"
        nb.cells.append(nbformat.v4.new_code_cell(export))
        NotebookClient(nb, timeout=300, kernel_name="python3", resources={"metadata": {"path": str(work)}}).execute()
        nbformat.write(nb, work / "executed.ipynb")
        executed[kind] = {"status": "executed", "adaptations": adaptations}
        print(f"Executed original notebook copy: {kind}", flush=True)
    write_json(output / "execution_status.json", executed)


def compare_references(source, output):
    """Compare independent implementation, clean execution, and pre-existing caches."""
    source, output = Path(source), Path(output)
    rows = []
    current = pd.read_csv(output / "author/offline_summary.csv", index_col=0)
    clean = pd.read_csv(output / "notebooks/offline/executed_offline_summary.csv", index_col=0).T
    names = {"holding_cost": "Holding cost", "stockout_cost": "Stockout cost", "total_cost": "Total cost"}
    original = json.loads((source / ".ipynb_checkpoints" / NOTEBOOKS["offline"]).read_text())
    cached_text = "".join(original["cells"][16]["outputs"][0]["text"])
    for metric, label in names.items():
        line = next(line for line in cached_text.splitlines() if line.startswith(label))
        saved = [float(x.strip().replace("\\\\", "")) for x in line.split("&")[1:]]
        for method, cached in zip(METHODS, saved):
            value, independent = current.loc[method, metric], clean.loc[method, label]
            rows.append({"section": "offline", "item": f"{method}/{metric}", "computed": value,
                         "reference": independent, "reference_kind": "clean_notebook",
                         "tolerance": 1e-7, "pass": abs(value-independent) < 1e-7})
            rows.append({"section": "offline", "item": f"{method}/{metric}", "computed": value,
                         "reference": cached, "reference_kind": "saved_cache_2_decimals",
                         "tolerance": .0051, "pass": abs(value-cached) < .0051})
    arrays = json.loads((output / "notebooks/field/executed_field_arrays.json").read_text())
    panel = pd.read_csv(output / "author/field_panel.csv")
    for key, values in arrays.items():
        phase, group_name = key.split("_")
        sub = panel[(panel.group == (1 if group_name == "e2e" else 0)) & (panel.post == (1 if phase == "post" else 0))].sort_values("id")
        for metric, ref in zip(METRICS, values):
            col = "turnover_raw" if key == "post_jd" and metric == "turnover" else metric
            error = np.max(np.abs(sub[col].to_numpy()-ref))
            rows.append({"section": "field", "item": f"{key}/{metric}/max_abs_error", "computed": error,
                         "reference": 0, "reference_kind": "clean_notebook", "tolerance": 1e-7, "pass": error < 1e-7})
    # Pre-existing field means are printed in the original notebook cells.
    original = json.loads((source / ".ipynb_checkpoints" / NOTEBOOKS["field"]).read_text())
    summary = panel.groupby(["group", "post"])[METRICS].mean()
    for cell_idx, group, post in [(8, 1, 1), (11, 0, 1), (33, 1, 0), (36, 0, 0)]:
        txt = "".join(original["cells"][cell_idx]["outputs"][0]["text"])
        saved = [float(line.rsplit(":", 1)[1]) for line in txt.splitlines() if ":" in line]
        for metric, cached in zip(METRICS, saved):
            value = summary.loc[group, post][metric]
            rows.append({"section": "field", "item": f"{group}/{post}/{metric}", "computed": value,
                         "reference": cached, "reference_kind": "saved_cache", "tolerance": 1e-7,
                         "pass": abs(value-cached) < 1e-7})
    # Saved statistical output is an independent reference, not recomputed by
    # copying the new implementation's own expected results.
    ttests = pd.read_csv(output / "author/field_ttests.csv").set_index("metric")
    did = pd.read_csv(output / "author/field_did.csv").set_index("metric")
    regression = pd.read_csv(output / "author/field_regression.csv").set_index("metric")
    executed_field = json.loads((output / "notebooks/field/executed.ipynb").read_text())
    for metric, post_cell, did_cell, reg_cell in zip(METRICS, [13, 14, 15, 16, 17], [38, 40, 42, 44, 46], [23, 24, 25, 26, 27]):
        for label, cell_idx, computed in [("ttest", post_cell, ttests.loc[metric]),
                                          ("did", did_cell, did.loc[metric])]:
            txt = "".join(original["cells"][cell_idx]["outputs"][0]["text"])
            for name, ref_text in re.findall(r"([tp])\s*=\s*([-+\deE.]+)", txt):
                reference = float(ref_text)
                value = float(computed[("author_" if label == "did" else "") + name])
                tolerance = max(abs(reference)*1e-7, 1e-100) if name == "p" else 1e-7
                rows.append({"section": "field", "item": f"{label}/{metric}/{name}", "computed": value,
                             "reference": reference, "reference_kind": "saved_cache", "tolerance": tolerance,
                             "pass": abs(value-reference) <= tolerance})
            clean_txt = "".join(executed_field["cells"][cell_idx+1]["outputs"][0]["text"])
            for name, ref_text in re.findall(r"([tp])\s*=\s*([-+\deE.]+)", clean_txt):
                reference = float(ref_text)
                value = float(computed[("author_" if label == "did" else "") + name])
                tolerance = max(abs(reference)*1e-7, 1e-100) if name == "p" else 1e-7
                rows.append({"section": "field", "item": f"{label}/{metric}/{name}", "computed": value,
                             "reference": reference, "reference_kind": "clean_notebook", "tolerance": tolerance,
                             "pass": abs(value-reference) <= tolerance})
        txt = "".join(original["cells"][reg_cell]["outputs"][0]["text"])
        line = next(line for line in txt.splitlines() if line.strip().startswith("e2e "))
        fields = line.split()
        for key, position, tolerance in [("coefficient", 1, .000051), ("p", 4, .00051)]:
            reference = float(fields[position])
            value = float(regression.loc[metric, key])
            rows.append({"section": "field", "item": f"regression/{metric}/{key}", "computed": value,
                         "reference": reference, "reference_kind": "saved_cache_rounded", "tolerance": tolerance,
                         "pass": abs(value-reference) <= tolerance})
        clean_txt = "".join(executed_field["cells"][reg_cell+1]["outputs"][0]["text"])
        clean_line = next(line for line in clean_txt.splitlines() if line.strip().startswith("e2e "))
        clean_fields = clean_line.split()
        for key, position, tolerance in [("coefficient", 1, .000051), ("p", 4, .00051)]:
            reference, value = float(clean_fields[position]), float(regression.loc[metric, key])
            rows.append({"section": "field", "item": f"regression/{metric}/{key}", "computed": value,
                         "reference": reference, "reference_kind": "clean_notebook", "tolerance": tolerance,
                         "pass": abs(value-reference) <= tolerance})
    actual_idx = pd.read_csv(output / "matching/matches_author_features.csv").candidate_row.to_numpy()
    ref_idx = np.loadtxt(output / "notebooks/matching/executed_match_indices.csv", dtype=int)
    rows.append({"section": "matching", "item": "different_indices", "computed": (actual_idx != ref_idx).sum(),
                 "reference": 0, "reference_kind": "clean_notebook", "tolerance": 0, "pass": np.array_equal(actual_idx, ref_idx)})
    result = pd.DataFrame(rows)
    result["difference"] = result.computed - result.reference
    result.to_csv(output / "reference_comparison.csv", index=False)
    result.loc[~result["pass"]].to_csv(output / "reference_discrepancies.csv", index=False)
    write_json(output / "reference_comparison_summary.json", result.groupby(["reference_kind", "pass"]).size().reset_index(name="count").to_dict("records"))
    return result


def run_author(cfg, execute=True):
    source = Path(cfg["source_dir"])
    output = Path(cfg["output_dir"]) / "stage1"
    manifest = audit_sources(source, output)
    for track in ("author", "paper_check"):
        print(f"Offline and field evaluation: {track}", flush=True)
        offline(source, output / track, track)
        field(source, output / track, track)
    matching(source, output / "matching")
    if execute:
        execute_notebooks(source, output / "notebooks")
        comparison = compare_references(source, output)
        if not comparison.loc[comparison.reference_kind == "clean_notebook", "pass"].all():
            raise AssertionError("Independent implementation differs from clean original notebook execution")
    unchanged = all(sha256(source / entry["file"]) == entry["sha256"] for entry in manifest)
    write_json(output / "source_integrity.json", {"all_original_files_unchanged": unchanged, "files": len(manifest)})
    if not unchanged:
        raise AssertionError("A source file changed")
    print("Stage 1 complete", flush=True)
