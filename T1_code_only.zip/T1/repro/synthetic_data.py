"""Controlled substitute data, not JD data. No future observations in features."""
from __future__ import annotations

from pathlib import Path
import numpy as np

from .common import write_json
from .inventory import optimal_quantity


def split_ranges(cfg):
    train_start = cfg["history_days"]
    train_end = train_start + cfg["train_days"]
    val_start = train_end + cfg["gap_days"]
    val_end = val_start + cfg["validation_days"]
    test_start = val_end + cfg["gap_days"]
    test_end = test_start + cfg["test_days"]
    return {"train": (train_start, train_end), "validation": (val_start, val_end),
            "test": (test_start, test_end), "total_days": test_end + cfg["tail_days"]}


def generate(cfg, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    ranges = split_ranges(cfg)
    n, T = cfg["n_skus"], ranges["total_days"]
    if cfg["lead_max"] >= cfg["review_period"] or cfg["lead_min"] < 1:
        raise ValueError("Initial experiment requires every order to arrive before the next review")
    if cfg["gap_days"] < cfg["forecast_horizon"] or cfg["tail_days"] < cfg["forecast_horizon"]:
        raise ValueError("Gaps and tail must cover the complete label horizon")
    rng = np.random.default_rng(cfg["data_seed"])
    regime = np.arange(n) % 3
    vendor = np.arange(n) % 2
    mean = np.exp(rng.uniform(np.log(.5), np.log(12), n))
    phase = rng.integers(0, 7, n)
    rates = np.broadcast_to(mean[:, None], (n, T)).copy()
    weekly = regime == 1
    rates[weekly] *= 1 + .5 * np.sin(2*np.pi*(np.arange(T)[None, :] + phase[weekly, None])/7)
    demand = rng.poisson(rates).astype(np.float32)
    intermittent = regime == 2
    demand[intermittent] = (rng.random((intermittent.sum(), T)) < .25) * rng.poisson(rates[intermittent]/.25)
    # Vendor categories have disjoint short/long lead supports, both observable as category features.
    lead = rng.integers(1, 4, (n, T)).astype(np.int64) + 3*vendor[:, None]
    # All normalization information precedes even the earliest training decision.
    scale = np.maximum(demand[:, :cfg["history_days"]].mean(axis=1), .1).astype(np.float32)
    data = {"demand": demand, "lead": lead, "regime": regime, "vendor": vendor, "scale": scale}
    np.savez_compressed(output / "data.npz", **data)
    write_json(output / "data_manifest.json", {"kind": "synthetic_method_validation", "config": cfg,
               "splits_zero_based_half_open": ranges,
               "regimes": {"0": "Poisson, mean log-uniform(0.5,12)",
                           "1": "Poisson with weekly sinusoid amplitude 0.5 and random phase",
                           "2": "Bernoulli(0.25) * Poisson(mean/0.25)"},
               "lead_distribution": "vendor 0 uniform {1,2,3}; vendor 1 uniform {4,5,6}",
               "scale": "max(mean demand in the 180-day pre-training history, 0.1)",
               "not_features": ["latent mean", "latent weekly phase", "future demand", "unobserved lead realizations"]})
    return data


def features(data, cfg, day):
    """Only values strictly before day, and calendar/static information, are read."""
    H, L = cfg["forecast_horizon"], cfg["lookback"]
    if day < max(L, cfg["history_days"]):
        raise ValueError("Insufficient causal history")
    n, scale = len(data["regime"]), data["scale"]
    calendar = np.arange(day-L, day)
    sequence = np.stack([data["demand"][:, day-L:day]/scale[:, None],
                         np.broadcast_to(np.sin(2*np.pi*calendar/7), (n, L)),
                         np.broadcast_to(np.cos(2*np.pi*calendar/7), (n, L))], axis=-1).astype(np.float32)
    basic = np.column_stack([np.eye(3)[data["regime"]], np.eye(2)[data["vendor"]]]).astype(np.float32)
    # Virtual historical supplier orders are weekly. Excluding the preceding
    # lead_max days guarantees every observed lead is already realized.
    historical_orders = np.arange(0, day-cfg["lead_max"], cfg["review_period"])[-26:]
    observed_lead = data["lead"][:, historical_orders]
    vlt_mean, vlt_std = observed_lead.mean(axis=1), observed_lead.std(axis=1)
    vlt = np.column_stack([vlt_mean/6, vlt_std/6, np.eye(2)[data["vendor"]]]).astype(np.float32)
    future_days = np.arange(day, day+H)
    calendar_future = np.column_stack([np.sin(2*np.pi*future_days/7), np.cos(2*np.pi*future_days/7),
                                      np.arange(1, H+1)/H]).astype(np.float32)
    historical_demand = data["demand"][:, day-cfg["history_days"]:day]
    dm, ds = historical_demand.mean(axis=1), historical_demand.std(axis=1)
    # LightGBM receives summaries, never the flattened future or latent rate.
    tree = np.column_stack([dm/scale, ds/scale,
                            data["demand"][:, day-7:day].mean(axis=1)/scale,
                            data["demand"][:, day-14:day-7].mean(axis=1)/scale,
                            (data["demand"][:, day-7:day].mean(axis=1)-data["demand"][:, day-14:day-7].mean(axis=1))/scale,
                            vlt, basic, np.full(n, np.sin(2*np.pi*day/7)),
                            np.full(n, np.cos(2*np.pi*day/7))]).astype(np.float32)
    return {"seq": sequence, "basic": basic, "vlt": vlt,
            "calendar": np.broadcast_to(calendar_future, (n, H, 3)).copy(),
            "tree": tree, "demand_mean": dm, "demand_std": ds,
            "lead_mean": vlt_mean, "lead_std": vlt_std}


def training_arrays(data, cfg, ratio, split="train"):
    start, stop = split_ranges(cfg)[split]
    R, H = cfg["review_period"], cfg["forecast_horizon"]
    scale = data["scale"]
    chunks = []
    for ordinal, day in enumerate(range(start, stop, R)):
        f = features(data, cfg, day)
        # One state per SKU/review, cycling four observed-stock scenarios. This
        # controls data size while exposing positive and backordered states.
        multipliers = np.asarray(cfg["state_multipliers"])
        stock = multipliers[(np.arange(len(scale)) + ordinal) % len(multipliers)] * scale
        q = np.empty(len(scale), np.float32)
        for sku in range(len(scale)):
            arrival = day + int(data["lead"][sku, day])
            next_arrival = day + R + int(data["lead"][sku, day+R])
            at_arrival = stock[sku] - data["demand"][sku, day:arrival].sum()
            q[sku] = optimal_quantity(data["demand"][sku, arrival:next_arrival], at_arrival,
                                      cfg["holding_cost"], cfg["holding_cost"]*ratio)
        daily = data["demand"][:, day:day+H] / scale[:, None]
        f.update(stock=(stock/(scale*R)).astype(np.float32)[:, None],
                 target_q=(q/(scale*R))[:, None], target_lead=data["lead"][:, day:day+1].astype(np.float32)/6,
                 target_daily=daily.astype(np.float32), target_cumulative=(np.cumsum(daily, axis=1)/R).astype(np.float32),
                 decision_day=np.full(len(scale), day), label_last_day=np.full(len(scale), day+H-1))
        f["tree"] = np.column_stack([f["tree"], f["stock"]]).astype(np.float32)
        chunks.append(f)
    return {key: np.concatenate([chunk[key] for chunk in chunks]) for key in chunks[0]}
